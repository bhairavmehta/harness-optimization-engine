"""Tiny inline-markup parser shared by the DOCX and PPTX builders.

Supported inline markup:  **bold**  *italic*  _italic_  `code`
[link text](https://url)  ==highlight==  ^^superscript^^  ~~sub~~
Backslash escapes a markup character:  \\*not italic\\*
"""
from __future__ import annotations

import re
from dataclasses import dataclass, replace
from typing import List, Optional


@dataclass
class Run:
    text: str
    bold: bool = False
    italic: bool = False
    code: bool = False
    highlight: bool = False
    superscript: bool = False
    subscript: bool = False
    link: Optional[str] = None


_TOKEN = re.compile(
    r"(\\[*_`=\[\]^~\\])"            # escape
    r"|(\*\*|__)"                     # bold toggle
    r"|(\*|(?<![A-Za-z0-9])_(?=\S)|(?<=\S)_(?![A-Za-z0-9]))"  # italic toggle
    r"|(`[^`]+`)"                     # code span
    r"|(\[[^\]]+\]\([^)\s]+\))"       # link
    r"|(==)"                          # highlight toggle
    r"|(\^\^)"                        # superscript toggle
    r"|(~~)"                          # subscript toggle
)


def parse_inline(text) -> List[Run]:
    if text is None:
        return []
    text = str(text)
    runs: List[Run] = []
    state = Run("")
    buf: List[str] = []
    pos = 0

    def flush():
        if buf:
            runs.append(replace(state, text="".join(buf)))
            buf.clear()

    for m in _TOKEN.finditer(text):
        buf.append(text[pos:m.start()])
        pos = m.end()
        esc, bold, ital, code, link, hl, sup, sub = m.groups()
        if esc:
            buf.append(esc[1])
        elif bold:
            flush(); state = replace(state, bold=not state.bold)
        elif ital:
            flush(); state = replace(state, italic=not state.italic)
        elif code:
            flush(); runs.append(replace(state, text=code[1:-1], code=True))
        elif link:
            flush()
            lt, url = re.match(r"\[([^\]]+)\]\(([^)\s]+)\)", link).groups()
            runs.append(replace(state, text=lt, link=url))
        elif hl:
            flush(); state = replace(state, highlight=not state.highlight)
        elif sup:
            flush(); state = replace(state, superscript=not state.superscript)
        elif sub:
            flush(); state = replace(state, subscript=not state.subscript)
    buf.append(text[pos:])
    flush()
    return [r for r in runs if r.text]


def plain(text) -> str:
    return "".join(r.text for r in parse_inline(text))
