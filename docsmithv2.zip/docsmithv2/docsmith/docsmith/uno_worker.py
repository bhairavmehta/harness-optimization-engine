"""LibreOffice UNO worker.

Run with a Python interpreter that can ``import uno`` (system python3 with
python3-uno on Linux, or LibreOffice's bundled python on Windows/macOS).
It starts its own headless soffice with an isolated profile, opens the
document, refreshes indexes (TOC) and fields, then exports.

    python uno_worker.py --soffice /usr/bin/soffice --input a.docx --output a.pdf
"""
import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import uuid
from pathlib import Path

import uno  # noqa: F401  (must be importable)
from com.sun.star.beans import PropertyValue
from com.sun.star.connection import NoConnectException


def pv(name, value):
    p = PropertyValue()
    p.Name, p.Value = name, value
    return p


def file_url(path):
    return uno.systemPathToFileUrl(str(Path(path).resolve()))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--soffice", required=True)
    ap.add_argument("--input", required=True)
    ap.add_argument("--output", required=True)
    ap.add_argument("--pdfa", action="store_true")
    ap.add_argument("--no-update", action="store_true")
    ap.add_argument("--timeout", type=float, default=180)
    a = ap.parse_args()

    profile = Path(tempfile.mkdtemp(prefix="docsmith_lo_profile_"))
    pipe = "docsmith_" + uuid.uuid4().hex[:12]
    cmd = [a.soffice, f"-env:UserInstallation={file_url(profile)}", "--headless", "--invisible",
           "--nologo", "--norestore", "--nodefault", "--nolockcheck", "--nofirststartwizard",
           f"--accept=pipe,name={pipe};urp;StarOffice.ComponentContext"]
    kw = {"start_new_session": True} if os.name != "nt" else {"creationflags": 0x08000000}
    proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, **kw)
    status = {"ok": False, "indexes_updated": 0}
    try:
        local = uno.getComponentContext()
        resolver = local.ServiceManager.createInstanceWithContext("com.sun.star.bridge.UnoUrlResolver", local)
        ctx = None
        deadline = time.time() + 60
        while time.time() < deadline:
            try:
                ctx = resolver.resolve(f"uno:pipe,name={pipe};urp;StarOffice.ComponentContext")
                break
            except NoConnectException:
                if proc.poll() is not None:
                    raise RuntimeError(f"soffice exited early with code {proc.returncode}")
                time.sleep(0.4)
        if ctx is None:
            raise RuntimeError("Timed out connecting to LibreOffice")
        desktop = ctx.ServiceManager.createInstanceWithContext("com.sun.star.frame.Desktop", ctx)
        doc = desktop.loadComponentFromURL(file_url(a.input), "_blank", 0,
                                           (pv("Hidden", True), pv("UpdateDocMode", 0)))
        if doc is None:
            raise RuntimeError("LibreOffice could not open the input file")
        is_text = doc.supportsService("com.sun.star.text.TextDocument")
        is_impress = doc.supportsService("com.sun.star.presentation.PresentationDocument")
        if is_text and not a.no_update:
            # two passes: page numbers can shift once the TOC itself grows
            for _ in range(2):
                idx = doc.getDocumentIndexes()
                for i in range(idx.getCount()):
                    idx.getByIndex(i).update()
                status["indexes_updated"] = idx.getCount()
                doc.getTextFields().refresh()
                doc.refresh()
        out = Path(a.output)
        ext = out.suffix.lower()
        if ext == ".pdf":
            filt = "writer_pdf_Export" if is_text else ("impress_pdf_Export" if is_impress else "calc_pdf_Export")
            fd = [pv("ExportBookmarks", True), pv("UseTaggedPDF", True), pv("Quality", 92),
                  pv("ReduceImageResolution", False), pv("ExportNotes", False),
                  pv("EmbedStandardFonts", True), pv("ExportBookmarksToPDFDestination", True)]
            if a.pdfa:
                fd.append(pv("SelectPdfVersion", 2))  # PDF/A-2b
            if is_impress:
                fd.append(pv("ExportNotesPages", False))
            fdata = uno.Any("[]com.sun.star.beans.PropertyValue", tuple(fd))
            doc.storeToURL(file_url(out), (pv("FilterName", filt), pv("FilterData", fdata)))
        elif ext == ".docx":
            doc.storeToURL(file_url(out), (pv("FilterName", "MS Word 2007 XML"),))
        elif ext == ".pptx":
            doc.storeToURL(file_url(out), (pv("FilterName", "Impress MS PowerPoint 2007 XML"),))
        elif ext == ".odt":
            doc.storeToURL(file_url(out), (pv("FilterName", "writer8"),))
        elif ext == ".odp":
            doc.storeToURL(file_url(out), (pv("FilterName", "impress8"),))
        else:
            raise RuntimeError(f"Unsupported output extension {ext}")
        doc.close(True)
        status["ok"] = True
        try:
            desktop.terminate()
        except Exception:
            pass
    except Exception as e:  # report, never hang
        status["error"] = f"{type(e).__name__}: {e}"
    finally:
        try:
            proc.wait(timeout=15)
        except subprocess.TimeoutExpired:
            proc.kill()
        shutil.rmtree(profile, ignore_errors=True)
    print(json.dumps(status))
    sys.exit(0 if status["ok"] else 2)


if __name__ == "__main__":
    main()
