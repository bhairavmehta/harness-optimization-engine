"""Markdown -> docsmith spec.

Supported (document mode):
  YAML front matter (meta + options)      # / ## / ### / #### headings
  paragraphs (soft-wrapped lines join)    - / * bullets, nested by indent
  1. numbered lists                        > quotes
  > [!NOTE] / [!WARNING] / [!KEY] / [!SUCCESS] / [!DANGER] callouts
  ```lang code fences```                   | pipe | tables |
  ![caption](path.png){width=5}            <!-- pagebreak -->   [TOC]
  ```chart / ```kpis / ```table / ```block  -> YAML body parsed as that block

Slides mode: slides separated by a line containing only ``---``.  In each
slide the first ``#`` heading is the title, an optional ``##`` line right
after is the subtitle, ``<!-- layout: section -->`` picks a layout and
``<!-- notes: ... -->`` or a ``Notes:`` paragraph becomes speaker notes.
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Tuple

import yaml

_FM = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.S)
_LIST = re.compile(r"^(\s*)([-*+]|\d+[.)])\s+(.*)$")
_IMG = re.compile(r"^!\[([^\]]*)\]\(([^)\s]+)\)(\{[^}]*\})?\s*$")
_ALERT = re.compile(r"^\[!(NOTE|INFO|TIP|WARNING|CAUTION|KEY|IMPORTANT|SUCCESS|DANGER)\]\s*(.*)$", re.I)
_DIRECTIVE = re.compile(r"^<!--\s*(\w+)\s*:?\s*(.*?)\s*-->\s*$")

_ALERT_KIND = {"NOTE": "note", "INFO": "note", "TIP": "success", "WARNING": "warning",
               "CAUTION": "warning", "KEY": "key", "IMPORTANT": "key", "SUCCESS": "success",
               "DANGER": "danger"}


def _split_front_matter(text: str) -> Tuple[Dict[str, Any], str]:
    m = _FM.match(text)
    if not m:
        return {}, text
    return (yaml.safe_load(m.group(1)) or {}), text[m.end():]


def _parse_attrs(s: str | None) -> Dict[str, Any]:
    if not s:
        return {}
    out = {}
    for k, v in re.findall(r"(\w+)\s*=\s*([^\s}]+)", s):
        try:
            out[k] = float(v)
        except ValueError:
            out[k] = v.strip("\"'")
    return out


def _parse_table(lines: List[str]) -> Dict[str, Any]:
    rows = []
    align = None
    for ln in lines:
        cells = [c.strip() for c in ln.strip().strip("|").split("|")]
        if all(re.fullmatch(r":?-{2,}:?", c) for c in cells if c):
            align = ["right" if c.endswith(":") and not c.startswith(":") else
                     "center" if c.startswith(":") and c.endswith(":") else "left" for c in cells]
            continue
        rows.append(cells)
    t = {"type": "table", "columns": rows[0], "rows": rows[1:]}
    if align:
        t["align"] = align
    return t


def _parse_list(lines: List[str]) -> Dict[str, Any]:
    """Nested list -> items where a nested list follows its parent item."""
    ordered = bool(re.match(r"\s*\d", lines[0]))
    root: List[Any] = []
    stack: List[Tuple[Any, List[Any]]] = [(None, root)]
    for ln in lines:
        m = _LIST.match(ln)
        if not m:  # continuation of the previous item
            cur = stack[-1][1]
            if cur and isinstance(cur[-1], str):
                cur[-1] = f"{cur[-1]} {ln.strip()}"
            continue
        indent = len(m.group(1).replace("\t", "    "))
        text = m.group(3)
        if stack[-1][0] is None:
            stack[-1] = (indent, root)
        else:
            while len(stack) > 1 and indent < stack[-1][0]:
                stack.pop()
            if indent > stack[-1][0]:
                child: List[Any] = []
                stack[-1][1].append(child)
                stack.append((indent, child))
        stack[-1][1].append(text)
    return {"type": "numbered" if ordered else "bullets", "items": root}


def parse_blocks(text: str) -> List[Dict[str, Any]]:
    lines = text.replace("\r\n", "\n").split("\n")
    blocks: List[Dict[str, Any]] = []
    para: List[str] = []
    i = 0

    def flush_para():
        if para:
            blocks.append({"type": "paragraph", "text": " ".join(s.strip() for s in para)})
            para.clear()

    while i < len(lines):
        ln = lines[i]
        s = ln.strip()
        if not s:
            flush_para(); i += 1; continue
        if s.startswith("```"):
            flush_para()
            lang = s[3:].strip()
            body = []
            i += 1
            while i < len(lines) and not lines[i].strip().startswith("```"):
                body.append(lines[i]); i += 1
            i += 1
            raw = "\n".join(body)
            if lang in ("slide", "doc"):
                # ```slide: YAML merged into this slide (ignored in the document)
                # ```doc: YAML block(s) for the document only (ignored in slides)
                data = yaml.safe_load(raw) or {}
                blocks.append({"type": "_" + lang, "data": data})
            elif lang in ("chart", "kpis", "table", "block", "callout", "definitions", "signoff"):
                data = yaml.safe_load(raw) or {}
                if lang == "block":
                    blocks.append(data)
                elif lang == "kpis":
                    blocks.append({"type": "kpis", "items": data if isinstance(data, list) else data.get("items", [])})
                else:
                    if isinstance(data, list):
                        data = {"items": data}
                    blocks.append({"type": lang, **data})
            else:
                blocks.append({"type": "code", "text": raw, "language": lang})
            continue
        m = re.match(r"^(#{1,4})\s+(.*)$", s)
        if m:
            flush_para()
            blocks.append({"type": "heading", "level": len(m.group(1)), "text": m.group(2).strip()})
            i += 1; continue
        if re.fullmatch(r"-{3,}|\*{3,}", s):  # slide separator / horizontal rule
            flush_para(); i += 1; continue
        if s in ("[TOC]", "[[TOC]]"):
            flush_para(); blocks.append({"type": "toc"}); i += 1; continue
        d = _DIRECTIVE.match(s)
        if d and d.group(1).lower() in ("pagebreak", "newpage"):
            flush_para(); blocks.append({"type": "pagebreak"}); i += 1; continue
        if s in ("\\pagebreak", "\\newpage"):
            flush_para(); blocks.append({"type": "pagebreak"}); i += 1; continue
        if d:
            i += 1; continue  # other comments ignored in document mode
        im = _IMG.match(s)
        if im:
            flush_para()
            blk = {"type": "image", "path": im.group(2), "caption": im.group(1) or None}
            attrs = _parse_attrs(im.group(3))
            if "width" in attrs:
                blk["width_in"] = attrs["width"]
            blocks.append(blk); i += 1; continue
        if s.startswith("|"):
            flush_para()
            tl = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                tl.append(lines[i]); i += 1
            tbl = _parse_table(tl)
            # caption convention: a following line "Table: caption"
            if i < len(lines) and lines[i].strip().lower().startswith("table:"):
                tbl["caption"] = lines[i].strip()[6:].strip(); i += 1
            blocks.append(tbl); continue
        if s.startswith(">"):
            flush_para()
            ql = []
            while i < len(lines) and lines[i].strip().startswith(">"):
                ql.append(lines[i].strip()[1:].strip()); i += 1
            am = _ALERT.match(ql[0]) if ql else None
            if am:
                body = " ".join(x for x in ql[1:] if x)
                blocks.append({"type": "callout", "kind": _ALERT_KIND[am.group(1).upper()],
                               "title": am.group(2) or None, "text": body})
            else:
                attribution = None
                if ql and re.match(r"^(--|—)\s*", ql[-1]):
                    attribution = re.sub(r"^(--|—)\s*", "", ql.pop())
                blocks.append({"type": "quote", "text": " ".join(x for x in ql if x), "attribution": attribution})
            continue
        if _LIST.match(ln):
            flush_para()
            ll = []
            while i < len(lines) and lines[i].strip() and (_LIST.match(lines[i]) or lines[i].startswith("  ")):
                ll.append(lines[i]); i += 1
            blocks.append(_parse_list(ll))
            continue
        para.append(ln)
        i += 1
    flush_para()
    return blocks


def _slide_from_chunk(chunk: str, idx: int) -> Dict[str, Any]:
    slide: Dict[str, Any] = {}
    body_lines = []
    for ln in chunk.split("\n"):
        d = _DIRECTIVE.match(ln.strip())
        if d:
            key, val = d.group(1).lower(), d.group(2)
            if key == "notes":
                slide["notes"] = val
            else:
                try:
                    slide[key] = yaml.safe_load(val)
                except yaml.YAMLError:
                    slide[key] = val
            continue
        body_lines.append(ln)
    blocks = parse_blocks("\n".join(body_lines))
    if blocks and blocks[0]["type"] == "heading" and blocks[0]["level"] == 1:
        slide["title"] = blocks.pop(0)["text"]
    if blocks and blocks[0]["type"] == "heading" and blocks[0]["level"] == 2:
        slide["subtitle"] = blocks.pop(0)["text"]
    # Notes: paragraph
    for b in list(blocks):
        if b["type"] == "paragraph" and b["text"].lower().startswith("notes:"):
            slide["notes"] = b["text"][6:].strip(); blocks.remove(b)
    slide_extra: Dict[str, Any] = {}
    for b in list(blocks):
        if b["type"] == "_slide":
            slide_extra.update(b["data"] or {}); blocks.remove(b)
        elif b["type"] == "_doc":
            blocks.remove(b)
    for b in blocks:
        t = b["type"]
        if t in ("bullets", "numbered") and "bullets" not in slide:
            slide["bullets"] = b["items"]
            if t == "numbered":
                slide["numbered"] = True
        elif t == "table" and "table" not in slide:
            slide["table"] = {k: v for k, v in b.items() if k != "type"}
        elif t == "chart" and "chart" not in slide:
            slide["chart"] = {k: v for k, v in b.items() if k != "type"}
        elif t == "image" and "image" not in slide:
            slide["image"] = b["path"]; slide.setdefault("caption", b.get("caption"))
        elif t == "kpis":
            slide["kpis"] = b["items"]
        elif t == "quote":
            slide["quote"] = b["text"]; slide["attribution"] = b.get("attribution")
        elif t == "paragraph":
            slide.setdefault("text", [])
            slide["text"].append(b["text"])
        elif t == "callout":
            slide["takeaway"] = b.get("text")
    for k, v in slide_extra.items():  # ```slide wins; dicts merge (e.g. table options)
        if isinstance(v, dict) and isinstance(slide.get(k), dict):
            slide[k].update(v)
        else:
            slide[k] = v
    if isinstance(slide.get("text"), list):
        slide["text"] = "\n\n".join(slide["text"])
    if "layout" not in slide and idx == 0 and not any(k in slide for k in ("bullets", "table", "chart", "image", "kpis")):
        slide["layout"] = "title"
    if "layout" not in slide and "text" in slide and not any(k in slide for k in ("bullets", "table", "chart", "image", "kpis", "quote")):
        slide["layout"] = "text"
    return slide


def markdown_to_spec(text: str, mode: str = "auto") -> Dict[str, Any]:
    fm, body = _split_front_matter(text)
    meta = fm.get("meta") or {k: v for k, v in fm.items() if k not in ("mode", "document", "theme", "outputs")}
    if mode == "auto":
        mode = fm.get("mode", "document")
    spec: Dict[str, Any] = {"meta": meta}
    if "theme" in fm:
        spec["theme"] = fm["theme"]
    if "outputs" in fm:
        spec["outputs"] = fm["outputs"]
    if mode in ("document", "both"):
        doc_opts = dict(fm.get("document") or {})
        blocks = []
        for b in parse_blocks(body):
            if b["type"] == "_slide" or (b["type"] == "paragraph" and b["text"].lower().startswith("notes:")):
                continue
            if b["type"] == "_doc":
                d = b["data"]
                blocks.extend(d if isinstance(d, list) else [d])
                continue
            blocks.append(b)
        # a leading "# Title" / "## Subtitle" duplicates the cover page
        if blocks and blocks[0]["type"] == "heading" and blocks[0]["level"] == 1 \
                and blocks[0]["text"].strip() == str(meta.get("title", "")).strip():
            blocks.pop(0)
            if blocks and blocks[0]["type"] == "heading" and blocks[0]["level"] == 2 \
                    and blocks[0]["text"].strip() == str(meta.get("subtitle", "")).strip():
                blocks.pop(0)
        spec["document"] = {**doc_opts, "blocks": blocks}
    if mode in ("slides", "both"):
        chunks = [c.strip() for c in re.split(r"\n-{3,}\s*\n", "\n" + body + "\n") if c.strip()]
        spec["slides"] = [_slide_from_chunk(c, i) for i, c in enumerate(chunks)]
    return spec
