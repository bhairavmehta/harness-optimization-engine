"""docsmith command line.

  docsmith build SPEC [-o OUT] [-f docx,pptx,pdf] [--theme T] [--engine auto|libreoffice|msoffice]
                      [--pdfa] [--name STEM] [--mode document|slides|both] [--preview]
  docsmith convert FILE --to pdf|docx|pptx|odt|odp [-o OUT]
  docsmith preview FILE.pdf [-o DIR] [--pages N]
  docsmith new report|deck|markdown [-o FILE]
  docsmith theme [--theme T]          print the effective theme as YAML
  docsmith doctor                      check LibreOffice / UNO / fonts
"""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path

import yaml

from . import __version__
from .lo import ConversionError, export, find_soffice, find_uno_python
from .pipeline import build, render_preview
from .spec import SpecError
from .theme import load_theme

TEMPLATES = Path(__file__).with_name("templates")


def cmd_build(a):
    fmts = a.formats.split(",") if a.formats else None
    print(f"docsmith {__version__}: {a.spec}")
    m = build(a.spec, a.out, fmts, a.theme, a.engine, a.pdfa, a.name, a.mode, a.preview,
              logo=a.logo, logo_dark=a.logo_dark)
    if not m.get("logo") and not m.get("logo_dark"):
        print("  (no logo found: add assets/boeing-logo.png or pass --logo)")
    for o in m["outputs"]:
        print(f"  ✓ {o['format']:<5} {o['path']}")
    for w in m["warnings"]:
        print(f"  ! {w}")
    print(f"  done in {m['seconds']}s")
    if a.json:
        print(json.dumps(m, indent=2))


def cmd_convert(a):
    src = Path(a.file)
    out = Path(a.out) if a.out else src.with_suffix("." + a.to)
    if out.is_dir() or (a.out and not Path(a.out).suffix):
        out = Path(a.out) / f"{src.stem}.{a.to}"
    st = export(src, out, engine=a.engine)
    print(f"  ✓ {out}  ({st.get('engine')})")


def cmd_preview(a):
    files = render_preview(Path(a.file), Path(a.out), a.pages, a.dpi)
    if not files:
        print("pdftoppm (poppler) not found or produced nothing", file=sys.stderr)
        sys.exit(1)
    for f in files:
        print(f"  {f}")


def cmd_new(a):
    src = TEMPLATES / {"report": "report.yaml", "deck": "deck.yaml", "markdown": "template.md", "notes": "notes.md"}[a.kind]
    dst = Path(a.out or src.name)
    if dst.exists() and not a.force:
        print(f"{dst} exists (use --force)", file=sys.stderr)
        sys.exit(1)
    shutil.copy(src, dst)
    print(f"  wrote {dst}")


def cmd_theme(a):
    print(yaml.safe_dump(load_theme(a.theme).to_dict(), sort_keys=False))


def cmd_doctor(a):
    ok = True
    so = find_soffice()
    print(f"soffice        : {so or 'NOT FOUND'}")
    if so:
        r = subprocess.run([so, "--version"], capture_output=True, text=True, timeout=60)
        print(f"version        : {r.stdout.strip() or r.stderr.strip()}")
        py = find_uno_python(so)
        print(f"UNO python     : {py or 'not found (TOC page numbers will not be refreshed in PDFs)'}")
    else:
        ok = False
    print(f"pdftoppm       : {shutil.which('pdftoppm') or 'not found (preview disabled)'}")
    fc = shutil.which("fc-list")
    if fc:
        fonts = subprocess.run([fc, ":", "family"], capture_output=True, text=True).stdout
        for f in ("Arial", "Liberation Sans"):
            print(f"font {f:<10}: {'yes' if f in fonts else 'no'}")
    for mod in ("docx", "pptx", "matplotlib", "yaml", "PIL"):
        try:
            __import__(mod); print(f"python {mod:<8}: ok")
        except ImportError:
            print(f"python {mod:<8}: MISSING"); ok = False
    sys.exit(0 if ok else 1)


def main(argv=None):
    ap = argparse.ArgumentParser(prog="docsmith", description="Themed DOCX / PPTX / PDF generator (LibreOffice pipeline)")
    ap.add_argument("--version", action="version", version=__version__)
    sub = ap.add_subparsers(dest="cmd", required=True)

    b = sub.add_parser("build", help="build outputs from a YAML/JSON/Markdown spec")
    b.add_argument("spec")
    b.add_argument("-o", "--out", default="out")
    b.add_argument("-f", "--formats", help="comma list: docx,pptx,pdf (default: spec 'outputs' or all)")
    b.add_argument("--theme", help="built-in theme name or theme YAML path")
    b.add_argument("--engine", default="auto", choices=["auto", "libreoffice", "msoffice"])
    b.add_argument("--pdfa", action="store_true", help="export PDF/A-2b")
    b.add_argument("--name", help="output file stem")
    b.add_argument("--mode", default="auto", choices=["auto", "document", "slides", "both"],
                   help="for Markdown specs")
    b.add_argument("--logo", help="logo for light backgrounds (PNG or SVG)")
    b.add_argument("--logo-dark", dest="logo_dark", help="white/reversed logo for the blue title slides")
    b.add_argument("--preview", action="store_true", help="also render PNG page previews")
    b.add_argument("--json", action="store_true", help="print the manifest as JSON")
    b.set_defaults(fn=cmd_build)

    c = sub.add_parser("convert", help="convert any office file with LibreOffice")
    c.add_argument("file")
    c.add_argument("--to", required=True, choices=["pdf", "docx", "pptx", "odt", "odp"])
    c.add_argument("-o", "--out")
    c.add_argument("--engine", default="auto", choices=["auto", "libreoffice", "msoffice"])
    c.set_defaults(fn=cmd_convert)

    p = sub.add_parser("preview", help="render PDF pages to PNG")
    p.add_argument("file")
    p.add_argument("-o", "--out", default="preview")
    p.add_argument("--pages", type=int, default=0)
    p.add_argument("--dpi", type=int, default=80)
    p.set_defaults(fn=cmd_preview)

    n = sub.add_parser("new", help="scaffold a starter spec")
    n.add_argument("kind", choices=["report", "deck", "markdown", "notes"])
    n.add_argument("-o", "--out")
    n.add_argument("--force", action="store_true")
    n.set_defaults(fn=cmd_new)

    t = sub.add_parser("theme", help="print effective theme")
    t.add_argument("--theme")
    t.set_defaults(fn=cmd_theme)

    d = sub.add_parser("doctor", help="check environment")
    d.set_defaults(fn=cmd_doctor)

    a = ap.parse_args(argv)
    try:
        a.fn(a)
    except (SpecError, ConversionError, FileNotFoundError, ValueError) as e:
        print(f"error: {e}", file=sys.stderr)
        sys.exit(2)


if __name__ == "__main__":
    main()
