"""Themed static charts (PNG) for documents, rendered with matplotlib.

Slides use native, editable PowerPoint charts instead (see pptx_builder).

Chart spec:
    kind: bar | barh | stacked | stacked_barh | line | area | donut
    title, categories, series: [{name, values}] or {name: values}
    y_label, x_label, number_format ("{:,.0f}", "{:.1%}" ...)
    value_labels: true|false     reference: {value: 3.2, label: "Target"}
    width_in, height_in, caption, source
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.ticker import FuncFormatter  # noqa: E402

from .theme import Theme  # noqa: E402

_FONT_FALLBACK = ["Arial", "Liberation Sans", "Helvetica", "DejaVu Sans"]


def _fmt(spec: Dict[str, Any]):
    f = spec.get("number_format")
    if not f:
        return lambda v: f"{v:,.0f}" if abs(v) >= 100 or float(v).is_integer() else f"{v:,.1f}"
    return lambda v: f.format(v)


def render_chart(spec: Dict[str, Any], theme: Theme, out_path: Path, dpi: int = 220) -> Path:
    c = theme.colors
    kind = spec.get("kind", "bar")
    cats = [str(x) for x in spec["categories"]]
    series = spec["series"]
    palette = ["#" + h for h in c.chart]
    if spec.get("colors"):
        palette = ["#" + str(h).lstrip("#") for h in spec["colors"]]
    fmt = _fmt(spec)
    w = float(spec.get("width_in", 6.5))
    h = float(spec.get("height_in", 3.4 if kind != "donut" else 3.2))

    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": [theme.fonts.body] + _FONT_FALLBACK,
        "font.size": 9,
        "axes.edgecolor": "#" + c.rule,
        "axes.labelcolor": "#" + c.muted,
        "xtick.color": "#" + c.muted,
        "ytick.color": "#" + c.muted,
        "text.color": "#" + c.text,
    })
    fig, ax = plt.subplots(figsize=(w, h), dpi=dpi)
    fig.patch.set_facecolor("white")
    n = len(series)

    if kind in ("bar", "barh"):
        import numpy as np
        x = np.arange(len(cats))
        total_w = 0.72
        bw = total_w / n
        for i, s in enumerate(series):
            off = (i - (n - 1) / 2) * bw
            col = palette[i % len(palette)]
            if kind == "bar":
                bars = ax.bar(x + off, s["values"], bw, label=s["name"], color=col,
                              edgecolor="white", linewidth=1.2, zorder=3)
            else:
                bars = ax.barh(x + off, s["values"], bw, label=s["name"], color=col,
                               edgecolor="white", linewidth=1.2, zorder=3)
            if spec.get("value_labels", n == 1):
                ax.bar_label(bars, labels=[fmt(v) for v in s["values"]], padding=2,
                             fontsize=8, color="#" + c.text)
        if kind == "bar":
            ax.set_xticks(x, cats)
        else:
            ax.set_yticks(x, cats)
            ax.invert_yaxis()
    elif kind in ("stacked", "stacked_barh"):
        import numpy as np
        x = np.arange(len(cats))
        base = np.zeros(len(cats))
        for i, s in enumerate(series):
            col = palette[i % len(palette)]
            vals = np.array(s["values"], dtype=float)
            if kind == "stacked":
                ax.bar(x, vals, 0.6, bottom=base, label=s["name"], color=col,
                       edgecolor="white", linewidth=1.2, zorder=3)
            else:
                ax.barh(x, vals, 0.6, left=base, label=s["name"], color=col,
                        edgecolor="white", linewidth=1.2, zorder=3)
            base += vals
        if spec.get("value_labels", True):
            for xi, tot in zip(x, base):
                if kind == "stacked":
                    ax.text(xi, tot, fmt(tot), ha="center", va="bottom", fontsize=8)
                else:
                    ax.text(tot, xi, " " + fmt(tot), ha="left", va="center", fontsize=8)
        if kind == "stacked":
            ax.set_xticks(x, cats)
        else:
            ax.set_yticks(x, cats); ax.invert_yaxis()
    elif kind in ("line", "area"):
        for i, s in enumerate(series):
            col = palette[i % len(palette)]
            ax.plot(cats, s["values"], color=col, linewidth=2, marker="o", markersize=4.5,
                    markeredgecolor="white", markeredgewidth=1, label=s["name"], zorder=3)
            if kind == "area":
                ax.fill_between(range(len(cats)), s["values"], color=col, alpha=0.12, zorder=2)
            if spec.get("value_labels", False):
                v = s["values"][-1]
                ax.annotate(fmt(v), (len(cats) - 1, v), textcoords="offset points",
                            xytext=(6, 0), va="center", fontsize=8)
        if len(cats) > 12:
            step = max(1, len(cats) // 10)
            ax.set_xticks(range(0, len(cats), step), cats[::step])
    elif kind in ("donut", "pie"):
        s = series[0]
        wedges, _ = ax.pie(s["values"], colors=palette[:len(cats)], startangle=90,
                           counterclock=False,
                           wedgeprops={"width": 0.38 if kind == "donut" else 1,
                                       "edgecolor": "white", "linewidth": 2})
        total = sum(s["values"])
        if kind == "donut":
            ax.text(0, 0, fmt(total), ha="center", va="center", fontsize=16,
                    fontweight="bold", color="#" + c.text)
        ax.legend(wedges, [f"{cat}  {v / total:.0%}" for cat, v in zip(cats, s["values"])],
                  loc="center left", bbox_to_anchor=(1.0, 0.5), frameon=False, fontsize=8.5)
        ax.set_aspect("equal")
    else:
        raise ValueError(f"Unknown chart kind '{kind}'")

    if kind not in ("donut", "pie"):
        horizontal = kind in ("barh", "stacked_barh")
        ax.grid(axis="x" if horizontal else "y", color="#" + c.rule, linewidth=0.6, zorder=0)
        for side in ("top", "right"):
            ax.spines[side].set_visible(False)
        ax.spines["left" if not horizontal else "bottom"].set_visible(False)
        ax.tick_params(length=0)
        val_axis = ax.xaxis if horizontal else ax.yaxis
        val_axis.set_major_formatter(FuncFormatter(lambda v, _: fmt(v)))
        if spec.get("y_label"):
            ax.set_ylabel(spec["y_label"])
        if spec.get("x_label"):
            ax.set_xlabel(spec["x_label"])
        ref = spec.get("reference")
        if ref:
            if horizontal:
                ax.axvline(ref["value"], color="#" + c.text, linestyle=(0, (4, 3)), linewidth=1, zorder=4)
            else:
                ax.axhline(ref["value"], color="#" + c.text, linestyle=(0, (4, 3)), linewidth=1, zorder=4)
                ax.annotate(ref.get("label", ""), xy=(1, ref["value"]), xycoords=("axes fraction", "data"),
                            xytext=(0, 3), textcoords="offset points", ha="right", va="bottom",
                            fontsize=8, color="#" + c.text)
        if n > 1:
            ax.legend(frameon=False, fontsize=8.5, ncol=min(n, 4), loc="lower left",
                      bbox_to_anchor=(0, 1.0), handlelength=1.2, borderaxespad=0.2)
    if spec.get("title"):
        fig.suptitle(spec["title"], x=0.01, ha="left", fontsize=10.5, fontweight="bold",
                     color="#" + c.text, y=0.99)
    fig.tight_layout(rect=(0, 0, 1, 0.94 if spec.get("title") else 1))
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=dpi, facecolor="white")
    plt.close(fig)
    return out_path
