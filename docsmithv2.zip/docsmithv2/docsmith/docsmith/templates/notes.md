---
title: Weekly Analytics Update
subtitle: Week of November 9, 2026
author: Data Science & AI/ML
org: Boeing Commercial Airplanes
doc_number: BCA-DS-WK-46
marking: BOEING PROPRIETARY
mode: both          # document | slides | both
document:
  toc: false
---

# Weekly Analytics Update
## Week of November 9, 2026

---

# Highlights

- Sensor-family recalibration merged and validated
- Two new data contracts signed for hydraulics
  - Flight-data feed
  - Shop-findings feed
- Planner explanation cards in user testing

Notes: Lead with the recalibration result.

---

# Precision trend

```chart
kind: line
categories: [Aug, Sep, Oct, Nov]
series:
  Precision: [86, 88, 89, 90]
```

---

# Risks

| Risk | Owner | Status |
|------|-------|-------:|
| Hydraulics data latency | Data Eng. | Amber |
| Reviewer availability | PMO | Green |

> [!WARNING] Watch item
> Hydraulics feed latency is 36 h against a 24 h target.
