---
# ============================================================================
# docsmith Markdown template: one file -> Word report + slide deck + PDFs
#   docsmith build template.md -o out                 (uses `mode` below)
#   docsmith build template.md -o out --mode slides   (deck only)
#
# CHEAT SHEET
#   ---                       ends one slide and starts the next (ignored in the document)
#   # Title / ## Subtitle     slide title and subtitle; Heading 1 and 2 in the document
#   - bullet / 1. numbered    indent two spaces to nest
#   | table |                 add "Table: caption" on the line after the table
#   > [!NOTE] Title           callout (NOTE, KEY, WARNING, SUCCESS, DANGER)
#                             in slides it becomes the "Key takeaway" banner
#   > quote text              add a last line "> -- Name" for the attribution
#   ![Caption](img.png){width=5}   image, path relative to this file
#   ```chart / ```kpis        YAML chart or KPI cards (document AND slides)
#   ```slide                  YAML for this slide only (layout, columns, milestones...)
#   ```doc                    YAML blocks for the document only
#   Notes: ...                speaker notes (slides only)
#   <!-- pagebreak -->        page break in the document
#   **bold** *italic* `code` [link](https://...) ==highlight==
# ============================================================================
title: Project Title Goes Here
subtitle: One-line description of the decision or topic
short_title: Project Title             # used in running headers and footers
doc_type: Technical Report             # small label above the title on the cover
doc_number: BCA-XX-2026-000
revision: A
date: 2026-11-15
author: Your Name
org: Boeing Commercial Airplanes
division: Your Organization
audience: Review board / leadership
status: Draft for review
marking: BOEING PROPRIETARY
revisions:
  - {rev: A, date: 2026-11-15, description: Initial draft, author: Your Name}

mode: both                             # document | slides | both
outputs: [docx, pptx, pdf]
document:
  toc: true
  toc_depth: 2
  numbered_headings: true
---

# Project Title Goes Here
## One-line description of the decision or topic

Notes: Open with the decision you need from the audience.

---

```slide
layout: agenda
title: Agenda
items: [Executive summary, Background, Analysis, Options, Plan and risks, Recommendation]
```

---

# Executive Summary

State the purpose, the key finding and the decision you are asking for, in two or three sentences. Use **bold** for the single most important fact.

```kpis
- {label: Metric one, value: "38", delta: "+12", note: vs. baseline}
- {label: Metric two, value: "21 d", delta: "+6 d"}
- {label: Metric three, value: "4.2%", delta: "-1.9 pts", good: true}
- {label: Metric four, value: "9"}
```

> [!KEY] Recommendation
> One sentence stating what you recommend and why.

---

```slide
layout: section
title: Background
subtitle: Why this matters now
```

---

# Background

Describe the problem, its scope, and what has been done so far. This paragraph appears in the document; the slide shows the bullets below.

- First context point with a specific fact
- Second context point
  - Supporting detail
  - Another supporting detail
- Third context point

Notes: Keep this slide under a minute.

---

# Analysis
## Trend over time

Explain the method in one or two sentences (data window, holdout, assumptions).

```chart
kind: line                  # bar | barh | stacked | stacked_barh | line | area | donut
title: Metric by month (illustrative)
categories: [May, Jun, Jul, Aug, Sep, Oct]
series:
  Current approach: [81, 83, 82, 86, 88, 89]
  Baseline: [62, 61, 64, 63, 62, 63]
reference: {value: 85, label: Target}
caption: What the figure shows, in one sentence.
```

```slide
insights:
  - First insight from the chart
  - Second insight from the chart
takeaway: The one message the audience should remember from this chart.
```

---

# Results by category

| Category | Measure A | Measure B | Measure C |
|----------|----------:|----------:|----------:|
| Alpha    | 0.91      | 0.74      | 24        |
| Bravo    | 0.88      | 0.69      | 19        |
| Charlie  | 0.84      | 0.77      | 12        |
| Total    | 0.89      | 0.73      | 21        |
Table: Results by category (illustrative)

```slide
source: Name the data source and date
table: {total_row: true, first_col_bold: true, highlight_cells: {"2,1": warn}}
```

> [!WARNING] Watch item
> Charlie is below target on Measure A; a fix is scheduled.

---

# Options

```doc
- table:
    caption: Options considered
    columns: [Option, Cost, Benefit, Risk]
    rows:
      - [A - Hold, "$0", Status quo, Falls behind]
      - [B - Extend (recommended), "$1.4M", Covers priority scope, Moderate]
      - [C - Accelerate, "$2.6M", Full scope sooner, Staffing]
```

```slide
layout: comparison
columns:
  - {tag: Option A, title: Hold, value: "$0", bullets: [Status quo, Falls behind], status: risk}
  - {tag: Option B - recommended, title: Extend, value: "$1.4M", bullets: [Covers priority scope, Moderate risk], highlight: true}
  - {tag: Option C, title: Accelerate, value: "$2.6M", bullets: [Full scope sooner, Needs two more engineers], status: warn}
```

---

# Plan

1. Decision and funding
2. Build phase one
3. Pilot with users
4. Independent review

```slide
layout: timeline
milestones:
  - {date: Nov 2026, title: Decision, status: current}
  - {date: Jan 2027, title: Build phase one, text: Data contracts signed}
  - {date: Mar 2027, title: Pilot}
  - {date: May 2027, title: Independent review}
```

---

# Governance

```doc
- definitions:
    - {term: Validation, definition: Independent review before first use and after material change.}
    - {term: Monitoring, definition: Monthly drift and calibration checks with alerts on breach.}
    - {term: Change control, definition: Material changes are re-validated; others are logged.}
```

```slide
layout: two_column
left:
  title: Controls in place
  bullets: [Independent validation, Monthly monitoring, Full traceability]
right:
  title: Open items
  bullets: [Recalibration due December, Quarterly review cadence]
```

---

# Recommendation

1. Approve Option B
2. Name a business sponsor
3. Endorse the quarterly review

```slide
callout: {title: The ask, value: "$1.4M", text: "Option B, over three quarters."}
```

---

> A short quote that captures the principle behind the recommendation.
> -- Source or role

---

```doc
- h1: Appendix
  unnumbered: true
- code: |
    # example request
    POST /v1/score {"id": "ABC123", "asof": "2026-11-15"}
  caption: Example (illustrative)
- signoff:
    - {role: Author, name: Your Name}
    - {role: Technical Reviewer, name: ""}
    - {role: Approver, name: ""}
```

```slide
layout: closing
title: Questions
contacts: [Your Name · Your Organization]
```
