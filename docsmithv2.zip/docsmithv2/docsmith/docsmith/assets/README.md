Logo files used automatically by docsmith (replace them to change the logo):

  boeing-logo.png        full-colour logo on white: document cover, running header, slide footers
  boeing-logo-white.png  white/reversed logo: blue title and closing slides

SVG is fine too (boeing-logo.svg / boeing-logo-white.svg). docsmith also looks in an
`assets/` folder next to your spec and in ./assets, or you can pass --logo / --logo-dark.
Use a transparent-background PNG, at least 600 px wide.
