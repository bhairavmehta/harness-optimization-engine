"""Re-order WordprocessingML property children into schema order.

LibreOffice is forgiving about element order; Microsoft Word is not and
reports "unreadable content".  Builders append properties freely, then this
pass sorts pPr / rPr / tcPr / tblPr / trPr / sectPr children before saving.
"""
from docx.oxml.ns import qn

_ORDER = {
    "w:pPr": ["pStyle", "keepNext", "keepLines", "pageBreakBefore", "framePr", "widowControl", "numPr",
              "suppressLineNumbers", "pBdr", "shd", "tabs", "suppressAutoHyphens", "kinsoku", "wordWrap",
              "overflowPunct", "topLinePunct", "autoSpaceDE", "autoSpaceDN", "bidi", "adjustRightInd",
              "snapToGrid", "spacing", "ind", "contextualSpacing", "mirrorIndents", "suppressOverlap", "jc",
              "textDirection", "textAlignment", "textboxTightWrap", "outlineLvl", "divId", "cnfStyle", "rPr",
              "sectPr", "pPrChange"],
    "w:rPr": ["rStyle", "rFonts", "b", "bCs", "i", "iCs", "caps", "smallCaps", "strike", "dstrike", "outline",
              "shadow", "emboss", "imprint", "noProof", "snapToGrid", "vanish", "webHidden", "color", "spacing",
              "w", "kern", "position", "sz", "szCs", "highlight", "u", "effect", "bdr", "shd", "fitText",
              "vertAlign", "rtl", "cs", "em", "lang", "eastAsianLayout", "specVanish", "oMath"],
    "w:tcPr": ["cnfStyle", "tcW", "gridSpan", "hMerge", "vMerge", "tcBorders", "shd", "noWrap", "tcMar",
               "textDirection", "tcFitText", "vAlign", "hideMark"],
    "w:tblPr": ["tblStyle", "tblpPr", "tblOverlap", "bidiVisual", "tblStyleRowBandSize", "tblStyleColBandSize",
                "tblW", "jc", "tblCellSpacing", "tblInd", "tblBorders", "shd", "tblLayout", "tblCellMar",
                "tblLook", "tblCaption", "tblDescription"],
    "w:trPr": ["cnfStyle", "divId", "gridBefore", "gridAfter", "wBefore", "wAfter", "cantSplit", "trHeight",
               "tblHeader", "tblCellSpacing", "jc", "hidden"],
}
_RANK = {qn(k): {qn("w:" + t): i for i, t in enumerate(v)} for k, v in _ORDER.items()}


def _sort(el):
    rank = _RANK[el.tag]
    kids = list(el)
    if len(kids) < 2:
        return
    ordered = sorted(enumerate(kids), key=lambda ik: (rank.get(ik[1].tag, 999), ik[0]))
    if [k for _, k in ordered] != kids:
        for k in kids:
            el.remove(k)
        for _, k in ordered:
            el.append(k)
    # tcBorders / pBdr children have their own order too
    for sub, order in ((qn("w:tcBorders"), ["top", "start", "left", "bottom", "end", "right", "insideH", "insideV", "tl2br", "tr2bl"]),
                       (qn("w:pBdr"), ["top", "left", "bottom", "right", "between", "bar"])):
        for b in el.findall(sub):
            r = {qn("w:" + t): i for i, t in enumerate(order)}
            bk = list(b)
            # drop duplicate edges, keeping the last one written
            seen = {}
            for k in bk:
                seen[k.tag] = k
            for k in bk:
                b.remove(k)
            for k in sorted(seen.values(), key=lambda e: r.get(e.tag, 99)):
                b.append(k)


def fix_order(root) -> None:
    for tag in _RANK:
        for el in root.iter(tag):
            _sort(el)


def insert_update_fields(settings_el) -> None:
    upd = settings_el.find(qn("w:updateFields"))
    if upd is None:
        from docx.oxml import OxmlElement
        upd = OxmlElement("w:updateFields")
        upd.set(qn("w:val"), "true")
    else:
        settings_el.remove(upd)
    after = ["hdrShapeDefaults", "footnotePr", "endnotePr", "compat", "docVars", "rsids", "attachedSchema",
             "themeFontLang", "clrSchemeMapping", "doNotIncludeSubdocsInStats", "doNotAutoCompressPictures",
             "forceUpgrade", "captions", "readModeInkLockDown", "smartTagType", "schemaLibrary", "shapeDefaults",
             "doNotEmbedSmartTags", "decimalSymbol", "listSeparator"]
    tags = {qn("w:" + t) for t in after} | {"{http://schemas.openxmlformats.org/officeDocument/2006/math}mathPr"}
    for child in settings_el:
        if child.tag in tags:
            child.addprevious(upd)
            return
    settings_el.append(upd)
