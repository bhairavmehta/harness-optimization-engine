"""Conversion engines.

* ``libreoffice`` (default): headless soffice.  PDF export goes through the
  UNO worker so the table of contents and fields are refreshed first; if UNO
  is unavailable it falls back to ``soffice --convert-to``.
* ``msoffice`` (Windows only, optional): Word/PowerPoint via COM (pywin32),
  for machines where LibreOffice can't be installed.
* ``auto``: LibreOffice if found, otherwise MS Office on Windows.

Each LibreOffice call uses a throw-away user profile, so parallel runs and a
running desktop LibreOffice never collide.
"""
from __future__ import annotations

import json
import os
import platform
import shutil
import signal
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Optional

WORKER = Path(__file__).with_name("uno_worker.py")


class ConversionError(RuntimeError):
    pass


def find_soffice() -> Optional[str]:
    env = os.environ.get("DOCSMITH_SOFFICE")
    if env and Path(env).exists():
        return env
    for name in ("soffice", "libreoffice", "soffice.exe"):
        p = shutil.which(name)
        if p:
            return p
    candidates = []
    if platform.system() == "Windows":
        for base in (os.environ.get("ProgramFiles", r"C:\Program Files"),
                     os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
                     os.environ.get("LOCALAPPDATA", "")):
            if base:
                candidates.append(Path(base) / "LibreOffice" / "program" / "soffice.exe")
                candidates.append(Path(base) / "Programs" / "LibreOffice" / "program" / "soffice.exe")
    elif platform.system() == "Darwin":
        candidates.append(Path("/Applications/LibreOffice.app/Contents/MacOS/soffice"))
    else:
        candidates += [Path("/usr/bin/soffice"), Path("/usr/lib/libreoffice/program/soffice"),
                       Path("/opt/libreoffice/program/soffice"), Path("/snap/bin/libreoffice")]
    for c in candidates:
        if c.exists():
            return str(c)
    return None


def find_uno_python(soffice: str) -> Optional[str]:
    env = os.environ.get("DOCSMITH_UNO_PYTHON")
    if env:
        return env
    try:
        import uno  # noqa: F401
        return sys.executable
    except ImportError:
        pass
    prog = Path(soffice).resolve().parent
    for name in ("python.exe", "python", "python3"):
        p = prog / name
        if p.exists():
            return str(p)
    if platform.system() == "Darwin":
        p = prog.parent / "Resources" / "python"
        if p.exists():
            return str(p)
    for cand in ("/usr/bin/python3",):  # Debian/Ubuntu python3-uno
        if Path(cand).exists():
            r = subprocess.run([cand, "-c", "import uno"], capture_output=True)
            if r.returncode == 0:
                return cand
    return None


def _run(cmd, timeout: float, env=None) -> subprocess.CompletedProcess:
    kw = {}
    if os.name != "nt":
        kw["start_new_session"] = True
    else:
        kw["creationflags"] = 0x08000000  # CREATE_NO_WINDOW
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env, **kw)
    try:
        out, err = proc.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        if os.name != "nt":
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        else:
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc.pid)], capture_output=True)
        proc.communicate()
        raise ConversionError(f"Timed out after {timeout:.0f}s: {' '.join(map(str, cmd[:3]))} ...")
    return subprocess.CompletedProcess(cmd, proc.returncode, out.decode(errors="replace"), err.decode(errors="replace"))


def lo_convert(src: Path, out_dir: Path, target: str = "pdf", soffice: Optional[str] = None,
               timeout: float = 180, retries: int = 1) -> Path:
    """Plain ``soffice --convert-to``.  ``target`` can include a filter, e.g.
    'pdf:writer_pdf_Export' or 'docx:"MS Word 2007 XML"'."""
    soffice = soffice or find_soffice()
    if not soffice:
        raise ConversionError("LibreOffice (soffice) not found. Install it or set DOCSMITH_SOFFICE.")
    src = Path(src).resolve()
    out_dir = Path(out_dir).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    ext = target.split(":")[0]
    expected = out_dir / f"{src.stem}.{ext}"
    last_err = ""
    for attempt in range(retries + 1):
        profile = Path(tempfile.mkdtemp(prefix="docsmith_lo_profile_"))
        try:
            cmd = [soffice, f"-env:UserInstallation={profile.as_uri()}", "--headless", "--invisible",
                   "--nologo", "--norestore", "--nolockcheck", "--nodefault",
                   "--convert-to", target, "--outdir", str(out_dir), str(src)]
            if expected.exists():
                expected.unlink()
            r = _run(cmd, timeout)
            if expected.exists() and expected.stat().st_size > 0:
                return expected
            last_err = (r.stderr or r.stdout).strip()[-800:]
        except ConversionError as e:
            last_err = str(e)
        finally:
            shutil.rmtree(profile, ignore_errors=True)
        time.sleep(1.0 + attempt)
    raise ConversionError(f"LibreOffice failed to convert {src.name} -> {ext}: {last_err or 'no output produced'}")


def lo_export(src: Path, dst: Path, soffice: Optional[str] = None, pdfa: bool = False,
              update_indexes: bool = True, timeout: float = 240) -> dict:
    """High-quality export through UNO (refreshes TOC/fields).  Falls back to
    plain --convert-to when UNO is unavailable.  Returns a status dict."""
    soffice = soffice or find_soffice()
    if not soffice:
        raise ConversionError("LibreOffice (soffice) not found. Install it or set DOCSMITH_SOFFICE.")
    src, dst = Path(src).resolve(), Path(dst).resolve()
    dst.parent.mkdir(parents=True, exist_ok=True)
    py = find_uno_python(soffice)
    if py:
        cmd = [py, str(WORKER), "--soffice", soffice, "--input", str(src), "--output", str(dst),
               "--timeout", str(timeout)]
        if pdfa:
            cmd.append("--pdfa")
        if not update_indexes:
            cmd.append("--no-update")
        env = dict(os.environ)
        if py != sys.executable:  # LibreOffice's bundled python must not see our venv
            env.pop("PYTHONHOME", None)
            env.pop("PYTHONPATH", None)
        try:
            r = _run(cmd, timeout + 30, env=env)
            line = (r.stdout.strip().splitlines() or ["{}"])[-1]
            try:
                status = json.loads(line)
            except json.JSONDecodeError:
                status = {"ok": False, "error": (r.stderr or r.stdout)[-500:]}
            if status.get("ok") and dst.exists():
                status["engine"] = "libreoffice-uno"
                return status
            uno_err = status.get("error")
        except ConversionError as e:
            uno_err = str(e)
    else:
        uno_err = "no UNO-capable python found"
    # fallback
    tmp_out = Path(tempfile.mkdtemp(prefix="docsmith_out_"))
    try:
        produced = lo_convert(src, tmp_out, dst.suffix.lstrip("."), soffice, timeout)
        shutil.move(str(produced), str(dst))
    finally:
        shutil.rmtree(tmp_out, ignore_errors=True)
    return {"ok": True, "engine": "libreoffice-convert", "note": f"UNO path skipped ({uno_err}); TOC page numbers may be stale"}


def msoffice_export(src: Path, dst: Path) -> dict:
    """Export via Microsoft Word / PowerPoint COM automation (Windows + pywin32)."""
    if platform.system() != "Windows":
        raise ConversionError("The msoffice engine only runs on Windows")
    try:
        import win32com.client  # type: ignore
        import pythoncom  # type: ignore
    except ImportError:
        raise ConversionError("pywin32 is required for the msoffice engine: pip install pywin32")
    src, dst = Path(src).resolve(), Path(dst).resolve()
    pythoncom.CoInitialize()
    try:
        if src.suffix.lower() in (".docx", ".doc", ".odt", ".rtf"):
            app = win32com.client.DispatchEx("Word.Application")
            app.Visible = False
            app.DisplayAlerts = 0
            doc = app.Documents.Open(str(src), ReadOnly=False, AddToRecentFiles=False)
            try:
                for toc in doc.TablesOfContents:
                    toc.Update()
                doc.Fields.Update()
                if dst.suffix.lower() == ".pdf":
                    doc.ExportAsFixedFormat(str(dst), 17, OptimizeFor=0, CreateBookmarks=1, DocStructureTags=True)
                else:
                    doc.SaveAs2(str(dst))
            finally:
                doc.Close(False)
                app.Quit()
        elif src.suffix.lower() in (".pptx", ".ppt", ".odp"):
            app = win32com.client.DispatchEx("PowerPoint.Application")
            pres = app.Presentations.Open(str(src), ReadOnly=True, Untitled=False, WithWindow=False)
            try:
                pres.SaveAs(str(dst), 32)  # ppSaveAsPDF
            finally:
                pres.Close()
                app.Quit()
        else:
            raise ConversionError(f"msoffice engine can't convert {src.suffix}")
    finally:
        pythoncom.CoUninitialize()
    return {"ok": True, "engine": "msoffice"}


def export(src: Path, dst: Path, engine: str = "auto", **kw) -> dict:
    engine = engine.lower()
    if engine == "auto":
        if find_soffice():
            engine = "libreoffice"
        elif platform.system() == "Windows":
            engine = "msoffice"
        else:
            raise ConversionError("No conversion engine: install LibreOffice (or set DOCSMITH_SOFFICE).")
    if engine == "libreoffice":
        return lo_export(src, dst, **kw)
    if engine == "msoffice":
        return msoffice_export(src, dst)
    raise ConversionError(f"Unknown engine '{engine}'")
