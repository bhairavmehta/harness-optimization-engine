"""docsmith: themed document, slide and PDF generation on a LibreOffice pipeline."""
__version__ = "1.0.0"

from .pipeline import build  # noqa: E402,F401
from .theme import Theme, load_theme  # noqa: E402,F401
