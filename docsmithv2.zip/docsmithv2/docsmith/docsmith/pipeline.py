"""End-to-end build pipeline: spec -> DOCX / PPTX -> PDF (LibreOffice)."""
from __future__ import annotations

import json
import re
import shutil
import subprocess
import tempfile
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

from .docx_builder import build_docx
from .lo import export, ConversionError
from .pptx_builder import build_pptx
from .richtext import plain
from .spec import load_spec
from .theme import load_theme, apply_logos, PACKAGE_ASSETS


def slugify(s: str) -> str:
    s = re.sub(r"[^\w\s-]", "", plain(s)).strip().lower()
    return re.sub(r"[\s_-]+", "-", s)[:80] or "document"


def _resolve_theme(spec: Dict[str, Any], theme_arg: Optional[str]):
    st = spec.get("theme")
    if theme_arg:
        return load_theme(theme_arg, st if isinstance(st, dict) else None)
    if isinstance(st, str):
        p = Path(spec["_base_dir"]) / st
        return load_theme(str(p) if p.exists() else st)
    if isinstance(st, dict):
        return load_theme(st.get("extends"), {k: v for k, v in st.items() if k != "extends"})
    return load_theme()


def render_preview(pdf: Path, out_dir: Path, pages: int = 0, dpi: int = 70) -> List[Path]:
    """PNG thumbnails of PDF pages (needs poppler's pdftoppm)."""
    exe = shutil.which("pdftoppm")
    if not exe:
        return []
    out_dir.mkdir(parents=True, exist_ok=True)
    cmd = [exe, "-png", "-r", str(dpi)]
    if pages:
        cmd += ["-l", str(pages)]
    cmd += [str(pdf), str(out_dir / pdf.stem)]
    subprocess.run(cmd, capture_output=True, timeout=180)
    return sorted(out_dir.glob(f"{pdf.stem}*.png"))


def build(spec_path: str | Path, out_dir: str | Path = "out", formats: Optional[Iterable[str]] = None,
          theme: Optional[str] = None, engine: str = "auto", pdfa: bool = False, name: Optional[str] = None,
          mode: str = "auto", preview: bool = False, log=print, logo: Optional[str] = None,
          logo_dark: Optional[str] = None) -> Dict[str, Any]:
    t0 = time.time()
    spec = load_spec(spec_path, mode=mode)
    th = _resolve_theme(spec, theme)
    sd = Path(spec["_base_dir"])
    th = apply_logos(th, [sd / "assets", sd, Path.cwd() / "assets", PACKAGE_ASSETS], logo, logo_dark)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = name or spec["meta"].get("filename") or slugify(spec["meta"].get("title", "document"))
    fmts = {f.strip().lower().lstrip(".") for f in (formats or spec.get("outputs") or ["docx", "pptx", "pdf"])}
    bad = fmts - {"docx", "pptx", "pdf"}
    if bad:
        raise ValueError(f"Unsupported output format(s): {sorted(bad)}")
    work = Path(tempfile.mkdtemp(prefix="docsmith_work_"))
    manifest: Dict[str, Any] = {"spec": str(Path(spec_path).resolve()), "theme": th.name,
                                "logo": th.logo, "logo_dark": th.logo_dark, "outputs": [],
                                "warnings": []}
    has_doc, has_slides = spec.get("document") is not None, spec.get("slides") is not None
    try:
        if has_doc and ({"docx", "pdf"} & fmts):
            docx_path = (out_dir if "docx" in fmts else work) / f"{stem}.docx"
            log(f"  building document  -> {docx_path.name}")
            p, warns = build_docx(spec, th, docx_path, workdir=work)
            manifest["warnings"] += warns
            if "docx" in fmts:
                manifest["outputs"].append({"kind": "document", "format": "docx", "path": str(p.resolve())})
            if "pdf" in fmts:
                pdf = out_dir / f"{stem}.pdf"
                log(f"  exporting PDF      -> {pdf.name}")
                st = export(p, pdf, engine=engine, **({"pdfa": pdfa} if engine != "msoffice" else {}))
                if st.get("note"):
                    manifest["warnings"].append(st["note"])
                manifest["outputs"].append({"kind": "document", "format": "pdf", "path": str(pdf.resolve()),
                                            "engine": st.get("engine")})
        if has_slides and ({"pptx", "pdf"} & fmts):
            sstem = f"{stem}-slides" if has_doc else stem
            pptx_path = (out_dir if "pptx" in fmts else work) / f"{sstem}.pptx"
            log(f"  building slides    -> {pptx_path.name}")
            p, warns = build_pptx(spec, th, pptx_path)
            manifest["warnings"] += warns
            if "pptx" in fmts:
                manifest["outputs"].append({"kind": "slides", "format": "pptx", "path": str(p.resolve())})
            if "pdf" in fmts:
                pdf = out_dir / f"{sstem}.pdf"
                log(f"  exporting PDF      -> {pdf.name}")
                st = export(p, pdf, engine=engine, **({"pdfa": pdfa, "update_indexes": False} if engine != "msoffice" else {}))
                manifest["outputs"].append({"kind": "slides", "format": "pdf", "path": str(pdf.resolve()),
                                            "engine": st.get("engine")})
        if preview:
            for o in manifest["outputs"]:
                if o["format"] == "pdf":
                    o["preview"] = [str(x) for x in render_preview(Path(o["path"]), out_dir / "preview")]
    finally:
        shutil.rmtree(work, ignore_errors=True)
    manifest["seconds"] = round(time.time() - t0, 1)
    (out_dir / f"{stem}.manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest
