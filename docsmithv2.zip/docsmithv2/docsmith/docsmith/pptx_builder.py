"""Themed 16:9 slide-deck (.pptx) builder.

Every slide is drawn on the blank layout so the look is identical in
PowerPoint and LibreOffice Impress.  Charts are native (editable) charts.

Layouts: title, agenda, section, bullets, text, two_column, comparison,
table, chart, image, kpis, quote, timeline, closing.

Common slide keys: title, subtitle, kicker (small label above the title),
takeaway (key-message banner at the bottom), notes (speaker notes),
source (footnote).
"""
from __future__ import annotations

import math
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from lxml import etree
from pptx import Presentation
from pptx.chart.data import CategoryChartData
from pptx.dml.color import RGBColor
from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION, XL_LABEL_POSITION
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.oxml.ns import qn
from pptx.util import Emu, Inches, Pt

from .richtext import parse_inline, plain
from .theme import Theme, tint

SW, SH = 13.333, 7.5
MX = 0.6                    # side margin
CT_TOP, CT_BOTTOM = 1.62, 6.72


def _rgb(h: str) -> RGBColor:
    return RGBColor.from_string(h.upper())


def fit_size(lines: List[Tuple[int, str]], w_in: float, h_in: float, max_pt: float, min_pt: float = 11,
             spacing: float = 1.25, para_gap_pt: float = 8) -> float:
    """Largest font size (pt) at which the given (level, text) lines fit the box."""
    size = max_pt
    while size > min_pt:
        total = 0.0
        for lvl, text in lines:
            avail = (w_in - 0.35 * (lvl + 1)) * 72
            chars_per_line = max(8, avail / (size * 0.5))
            n = max(1, math.ceil(len(text) / chars_per_line))
            total += n * size * spacing + para_gap_pt * (size / max_pt)
        if total <= h_in * 72 * 0.95:
            return size
        size -= 1
    return min_pt


class PptxBuilder:
    def __init__(self, spec: Dict[str, Any], theme: Theme):
        self.spec = spec
        self.meta = spec["meta"]
        self.slides_spec = spec["slides"]
        self.opts = spec.get("slide_options") or {}
        self.theme = theme
        self.c = theme.colors
        self.f = theme.fonts
        self.base = Path(spec.get("_base_dir", "."))
        self.prs = Presentation()
        self.prs.slide_width = Inches(SW)
        self.prs.slide_height = Inches(SH)
        self.blank = self.prs.slide_layouts[6]
        self.page = 0
        self.section_n = 0
        self.warnings: List[str] = []

    # ------------------------------------------------------------------ prims
    def rect(self, slide, x, y, w, h, fill, line=None, shape=MSO_SHAPE.RECTANGLE):
        s = slide.shapes.add_shape(shape, Inches(x), Inches(y), Inches(w), Inches(h))
        s.shadow.inherit = False
        if fill:
            s.fill.solid(); s.fill.fore_color.rgb = _rgb(fill)
        else:
            s.fill.background()
        if line:
            s.line.color.rgb = _rgb(line); s.line.width = Pt(0.75)
        else:
            s.line.fill.background()
        return s

    def line(self, slide, x1, y1, x2, y2, color, width_pt=0.75):
        ln = slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, Inches(x1), Inches(y1), Inches(x2), Inches(y2))
        ln.line.color.rgb = _rgb(color)
        ln.line.width = Pt(width_pt)
        return ln

    def tb(self, slide, x, y, w, h, anchor="top", margin=0.0):
        box = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
        tf = box.text_frame
        tf.word_wrap = True
        tf.auto_size = None
        for side in ("margin_left", "margin_right", "margin_top", "margin_bottom"):
            setattr(tf, side, Inches(margin))
        tf.vertical_anchor = {"top": MSO_ANCHOR.TOP, "middle": MSO_ANCHOR.MIDDLE,
                              "bottom": MSO_ANCHOR.BOTTOM}[anchor]
        return box, tf

    def runs(self, p, text, size, color=None, bold=None, italic=None, font=None):
        for r in parse_inline(text):
            run = p.add_run()
            run.text = r.text
            f = run.font
            f.size = Pt(size)
            f.name = font or (self.f.mono if r.code else self.f.body)
            f.bold = True if r.bold else bold
            f.italic = True if r.italic else italic
            col = self.c.accent if r.link else color
            if col:
                f.color.rgb = _rgb(col)
            if r.link:
                run.hyperlink.address = r.link
            if r.superscript or r.subscript:
                rPr = run._r.get_or_add_rPr()
                rPr.set("baseline", "30000" if r.superscript else "-25000")
        return p

    def _p(self, tf, idx):
        return tf.paragraphs[0] if idx == 0 else tf.add_paragraph()

    def bullet(self, p, level=0, char="▪", color=None, numbered=False, size=18):
        pPr = p._p.get_or_add_pPr()
        indent = int(Pt(size * 1.1))
        pPr.set("marL", str(int(Inches(0.05)) + indent * (level + 1) + int(Inches(0.28)) * level))
        pPr.set("indent", str(-indent))
        for tag in ("a:buClr", "a:buSzPct", "a:buFont", "a:buChar", "a:buAutoNum", "a:buNone"):
            for e in pPr.findall(qn(tag)):
                pPr.remove(e)
        buClr = etree.SubElement(pPr, qn("a:buClr"))
        clr = etree.SubElement(buClr, qn("a:srgbClr")); clr.set("val", color or self.c.accent)
        sz = etree.SubElement(pPr, qn("a:buSzPct")); sz.set("val", "100000" if numbered else "90000")
        if numbered:
            fnt = etree.SubElement(pPr, qn("a:buFont")); fnt.set("typeface", "+mj-lt")
            an = etree.SubElement(pPr, qn("a:buAutoNum")); an.set("type", "arabicPeriod")
        else:
            fnt = etree.SubElement(pPr, qn("a:buFont")); fnt.set("typeface", "Arial")
            ch = etree.SubElement(pPr, qn("a:buChar")); ch.set("char", char if level == 0 else "–")

    def notes(self, slide, s):
        if s.get("notes"):
            slide.notes_slide.notes_text_frame.text = plain(s["notes"])

    def picture_fit(self, slide, path: Path, x, y, w, h, align="center"):
        from PIL import Image
        with Image.open(path) as im:
            iw, ih = im.size
        ar = iw / ih
        if w / h > ar:
            ph, pw = h, h * ar
        else:
            pw, ph = w, w / ar
        px = x + (w - pw) / 2 if align == "center" else x
        py = y + (h - ph) / 2
        return slide.shapes.add_picture(str(path), Inches(px), Inches(py), Inches(pw), Inches(ph))

    def picture_cover(self, slide, path: Path, x, y, w, h):
        """Fill the box, cropping the image (like CSS object-fit: cover)."""
        from PIL import Image
        with Image.open(path) as im:
            iw, ih = im.size
        pic = slide.shapes.add_picture(str(path), Inches(x), Inches(y), Inches(w), Inches(h))
        box_ar, img_ar = w / h, iw / ih
        if img_ar > box_ar:
            crop = (1 - box_ar / img_ar) / 2
            pic.crop_left = pic.crop_right = crop
        else:
            crop = (1 - img_ar / box_ar) / 2
            pic.crop_top = pic.crop_bottom = crop
        return pic

    def _resolve(self, p) -> Optional[Path]:
        if not p:
            return None
        path = Path(p)
        if not path.is_absolute():
            path = self.base / path
        if not path.exists():
            self.warnings.append(f"Image not found: {path}")
            return None
        return path

    # ------------------------------------------------------------- chrome
    def marking(self):
        return self.meta.get("marking", self.theme.marking) or ""

    def chrome(self, slide, s, dark=False):
        """Title, accent bar, footer, page number."""
        self.page += 1
        title = s.get("title", "")
        y = 0.42
        if s.get("kicker"):
            _, tf = self.tb(slide, MX, 0.3, SW - 2 * MX, 0.3)
            self.runs(tf.paragraphs[0], str(s["kicker"]).upper(), 10, self.c.accent, bold=True)
            y = 0.58
        _, tf = self.tb(slide, MX, y, SW - 2 * MX, 0.85, anchor="top")
        size = self.f.slide_title if len(plain(title)) <= 60 else self.f.slide_title - 4
        p = tf.paragraphs[0]
        p.line_spacing = 0.95
        self.runs(p, title, size, self.c.primary, bold=True, font=self.f.heading)
        top = y + (0.62 if len(plain(title)) * size * 0.5 / 72 < (SW - 2 * MX) else 1.05)
        if s.get("subtitle"):
            _, tf2 = self.tb(slide, MX, top, SW - 2 * MX, 0.4)
            self.runs(tf2.paragraphs[0], s["subtitle"], 15, self.c.muted)
            top += 0.42
        self.rect(slide, MX, top + 0.08, 0.7, 0.055, self.c.accent)
        self._content_top = max(CT_TOP, top + 0.35)

        # footer
        fy = 7.02
        self.line(slide, MX, fy - 0.08, SW - MX, fy - 0.08, self.c.rule, 0.5)
        _, tf = self.tb(slide, MX, fy, 4.5, 0.3, anchor="middle")
        if self.marking():
            self.runs(tf.paragraphs[0], self.marking(), 8, self.c.primary, bold=True)
        _, tf = self.tb(slide, 4.2, fy, SW - 8.4, 0.3, anchor="middle")
        tf.paragraphs[0].alignment = PP_ALIGN.CENTER
        self.runs(tf.paragraphs[0], self.meta.get("short_title") or self.meta["title"], 8, self.c.muted)
        rx = SW - MX - 0.6
        if self.theme.logo and Path(self.theme.logo).exists():
            self.picture_fit(slide, Path(self.theme.logo), SW - MX - 1.6, fy - 0.02, 0.9, 0.3, align="left")
        _, tf = self.tb(slide, rx, fy, 0.6, 0.3, anchor="middle")
        tf.paragraphs[0].alignment = PP_ALIGN.RIGHT
        self.runs(tf.paragraphs[0], str(self.page), 9, self.c.text, bold=True)

        bottom = CT_BOTTOM
        if s.get("source"):
            _, tf = self.tb(slide, MX, 6.58, SW - 2 * MX, 0.25, anchor="bottom")
            self.runs(tf.paragraphs[0], f"Source: {s['source']}", 8.5, self.c.muted, italic=True)
            bottom = 6.5
        if s.get("takeaway"):
            h = 0.62
            ty = bottom - h
            self.rect(slide, MX, ty, SW - 2 * MX, h, tint(self.c.primary, 0.9))
            self.rect(slide, MX, ty, 0.09, h, self.c.primary)
            _, tf = self.tb(slide, MX + 0.3, ty, SW - 2 * MX - 0.45, h, anchor="middle")
            p = tf.paragraphs[0]
            self.runs(p, "Key takeaway  ", 12, self.c.primary, bold=True)
            self.runs(p, s["takeaway"], 14, self.c.primary_dark)
            bottom = ty - 0.2
        self._content_bottom = bottom
        self.notes(slide, s)

    @property
    def area(self):
        return MX, self._content_top, SW - 2 * MX, self._content_bottom - self._content_top

    # ------------------------------------------------------------- layouts
    def l_title(self, slide, s, closing=False):
        self.page += 1
        m = self.meta
        self.rect(slide, 0, 0, SW, SH, self.c.primary_dark)
        img = self._resolve(s.get("image"))
        px = 8.9
        if img:
            self.picture_cover(slide, img, px, 0, SW - px, SH)
            self.rect(slide, px - 0.06, 0, 0.06, SH, self.c.accent)
        else:
            self.rect(slide, px, 0, SW - px, SH, self.c.primary)
            # restrained "contrail" lines
            for k, yy in enumerate((2.2, 2.55, 2.9)):
                self.rect(slide, px, yy + k * 0.04, SW - px, 0.03 + 0.012 * k, tint(self.c.primary, 0.25 + 0.15 * k))
            self.rect(slide, px - 0.06, 0, 0.06, SH, self.c.accent)
        # org line / logo
        logo_dark, logo = self.theme.logo_dark, self.theme.logo
        if logo_dark and Path(logo_dark).exists():
            self.picture_fit(slide, Path(logo_dark), MX, 0.45, 2.6, 0.65, align="left")
        elif logo and Path(logo).exists():
            # only a light-background logo: sit it on a white badge
            self.rect(slide, MX - 0.15, 0.32, 3.0, 0.9, self.c.white)
            self.picture_fit(slide, Path(logo), MX, 0.42, 2.7, 0.7, align="left")
        else:
            _, tf = self.tb(slide, MX, 0.55, 7.5, 0.4)
            self.runs(tf.paragraphs[0], (m.get("org") or self.theme.org).upper(), 11, self.c.accent_light, bold=True)
            tf.paragraphs[0].runs[0].font._rPr.set("spc", "300")
        title = s.get("title") or (("Thank you" if closing else m["title"]))
        subtitle = s.get("subtitle") if s.get("subtitle") is not None else ("" if closing else m.get("subtitle", ""))
        ty = 2.45
        self.rect(slide, MX, ty + 0.08, 0.09, 2.1, self.c.accent)
        _, tf = self.tb(slide, MX + 0.35, ty, px - MX - 0.8, 2.3, anchor="top")
        size = fit_size([(0, plain(title))], px - MX - 0.8, 1.6, self.f.slide_cover_title, 26, spacing=1.05)
        p = tf.paragraphs[0]; p.line_spacing = 0.95
        self.runs(p, title, size, self.c.white, bold=True, font=self.f.heading)
        if subtitle:
            p2 = tf.add_paragraph(); p2.space_before = Pt(14)
            self.runs(p2, subtitle, 18, self.c.accent_light)
        # meta line
        if closing:
            lines = s.get("contacts") or [x for x in [m.get("author"), m.get("email")] if x]
        else:
            lines = [" · ".join(x for x in [m.get("author"), m.get("org") if m.get("author") else None] if x),
                     " · ".join(x for x in [m.get("date"), m.get("doc_number"),
                                                  f"Rev {m['revision']}" if m.get("revision") else None] if x)]
        _, tf = self.tb(slide, MX + 0.35, 5.35, px - MX - 0.8, 0.9)
        for i, ln in enumerate(x for x in lines if x):
            p = self._p(tf, i)
            self.runs(p, ln, 13 if i == 0 else 11.5, self.c.white if i == 0 else self.c.accent_light)
        if self.marking():
            _, tf = self.tb(slide, MX, 6.85, px - MX - 0.5, 0.4, anchor="middle")
            self.runs(tf.paragraphs[0], self.marking(), 8.5, self.c.accent_light, bold=True)
        self.notes(slide, s)

    def l_closing(self, slide, s):
        self.l_title(slide, s, closing=True)

    def l_section(self, slide, s):
        self.page += 1
        self.section_n += 1
        num = s.get("number", f"{self.section_n:02d}")
        self.rect(slide, 0, 0, SW, SH, self.c.white)
        self.rect(slide, 0, 0, 4.7, SH, self.c.primary_dark)
        self.rect(slide, 4.7, 0, 0.07, SH, self.c.accent)
        _, tf = self.tb(slide, 0.7, 2.3, 3.6, 2.2, anchor="middle")
        self.runs(tf.paragraphs[0], str(num), 96, self.c.accent_light, bold=True, font=self.f.heading)
        _, tf = self.tb(slide, 5.4, 2.4, 7.3, 2.6, anchor="top")
        p = tf.paragraphs[0]
        self.runs(p, s.get("title", ""), 36, self.c.primary, bold=True, font=self.f.heading)
        if s.get("subtitle"):
            p2 = tf.add_paragraph(); p2.space_before = Pt(12)
            self.runs(p2, s["subtitle"], 18, self.c.muted)
        if self.marking():
            _, tf = self.tb(slide, 5.4, 6.85, 6, 0.4, anchor="middle")
            self.runs(tf.paragraphs[0], self.marking(), 8, self.c.primary, bold=True)
        _, tf = self.tb(slide, SW - MX - 0.6, 6.85, 0.6, 0.4, anchor="middle")
        tf.paragraphs[0].alignment = PP_ALIGN.RIGHT
        self.runs(tf.paragraphs[0], str(self.page), 9, self.c.text, bold=True)
        self.notes(slide, s)

    def _flatten(self, items, level=0):
        for it in items or []:
            if isinstance(it, list):
                yield from self._flatten(it, level + 1)
            elif isinstance(it, dict):
                yield level, it.get("text", "")
                yield from self._flatten(it.get("items") or it.get("children"), level + 1)
            else:
                yield level, str(it)

    def bullets_box(self, slide, items, x, y, w, h, max_pt=None, numbered=False, color=None, anchor="top"):
        lines = list(self._flatten(items))
        if not lines:
            return
        size = fit_size([(l, plain(t)) for l, t in lines], w, h, max_pt or self.f.slide_body + 2, 11)
        _, tf = self.tb(slide, x, y, w, h, anchor=anchor)
        for i, (lvl, text) in enumerate(lines):
            p = self._p(tf, i)
            sz = size if lvl == 0 else max(size - 3, 10)
            p.space_before = Pt(0 if i == 0 else (size * 0.55 if lvl == 0 else 3))
            p.line_spacing = 1.08
            self.bullet(p, lvl, numbered=numbered and lvl == 0, size=sz,
                        color=self.c.primary if numbered else None)
            self.runs(p, text, sz, color or (self.c.text if lvl == 0 else self.c.muted))
        return size

    def text_box(self, slide, text, x, y, w, h, max_pt=20, color=None, anchor="top"):
        paras = [t for t in str(text).split("\n\n") if t.strip()]
        size = fit_size([(0, plain(t)) for t in paras], w, h, max_pt, 11, spacing=1.3, para_gap_pt=12)
        _, tf = self.tb(slide, x, y, w, h, anchor=anchor)
        for i, t in enumerate(paras):
            p = self._p(tf, i)
            p.space_before = Pt(0 if i == 0 else 12)
            p.line_spacing = 1.15
            self.runs(p, t.replace("\n", " "), size, color or self.c.text)

    def l_bullets(self, slide, s):
        self.chrome(slide, s)
        x, y, w, h = self.area
        side = s.get("callout") or s.get("side")
        img = self._resolve(s.get("image")) if s.get("image") else None
        if side or img:
            lw = w * 0.6
            self.bullets_box(slide, s.get("bullets") or [], x, y + 0.1, lw - 0.3, h - 0.1, numbered=s.get("numbered"))
            if img:
                self.picture_fit(slide, img, x + lw, y, w - lw, h)
            else:
                self._side_panel(slide, side, x + lw, y, w - lw, h)
        else:
            self.bullets_box(slide, s.get("bullets") or [], x, y + 0.1, w * 0.9, h - 0.1, numbered=s.get("numbered"))

    def _side_panel(self, slide, side, x, y, w, h):
        if isinstance(side, str):
            side = {"text": side}
        self.rect(slide, x, y, w, h, self.c.surface)
        self.rect(slide, x, y, w, 0.07, self.c.primary)
        _, tf = self.tb(slide, x + 0.3, y + 0.3, w - 0.6, 0.5)
        self.runs(tf.paragraphs[0], (side.get("title") or "Why it matters").upper(), 11, self.c.primary, bold=True)
        if side.get("value"):
            _, tf = self.tb(slide, x + 0.3, y + 0.75, w - 0.6, 1.0)
            self.runs(tf.paragraphs[0], side["value"], 44, self.c.primary, bold=True, font=self.f.heading)
            y2 = y + 1.8
        else:
            y2 = y + 0.8
        if side.get("bullets"):
            self.bullets_box(slide, side["bullets"], x + 0.3, y2, w - 0.6, y + h - y2 - 0.2, max_pt=15)
        elif side.get("text"):
            self.text_box(slide, side["text"], x + 0.3, y2, w - 0.6, y + h - y2 - 0.2, max_pt=16)

    def l_text(self, slide, s):
        self.chrome(slide, s)
        x, y, w, h = self.area
        self.text_box(slide, s.get("text", ""), x, y + 0.1, w * 0.85, h - 0.1, max_pt=22)

    def l_agenda(self, slide, s):
        s = dict(s); s.setdefault("title", "Agenda")
        self.chrome(slide, s)
        x, y, w, h = self.area
        items = [plain(t) if not isinstance(t, dict) else t for t in (s.get("items") or s.get("bullets") or [])]
        n = len(items)
        cols = 2 if n > 6 else 1
        per = math.ceil(n / cols)
        rowh = min(0.8, (h - 0.1) / max(per, 1))
        cw = (w - 0.4) / cols
        for i, it in enumerate(items):
            col, row = divmod(i, per)
            cx, cy = x + col * (cw + 0.4), y + 0.15 + row * rowh
            active = isinstance(it, dict) and it.get("active")
            text = it.get("text") if isinstance(it, dict) else it
            circ = self.rect(slide, cx, cy + (rowh - 0.5) / 2, 0.5, 0.5, self.c.primary if not active else self.c.accent,
                             shape=MSO_SHAPE.OVAL)
            tf = circ.text_frame
            tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
            tf.paragraphs[0].alignment = PP_ALIGN.CENTER
            tf.vertical_anchor = MSO_ANCHOR.MIDDLE
            self.runs(tf.paragraphs[0], str(i + 1), 14, self.c.white, bold=True)
            _, t2 = self.tb(slide, cx + 0.75, cy, cw - 0.9, rowh, anchor="middle")
            self.runs(t2.paragraphs[0], text, 20 if cols == 1 else 17, self.c.text, bold=bool(active))
            if row < per - 1 and i < n - 1:
                self.line(slide, cx + 0.75, cy + rowh, cx + cw - 0.2, cy + rowh, self.c.rule, 0.5)

    def _column_content(self, slide, content, x, y, w, h, heading_color=None):
        if isinstance(content, str):
            content = {"text": content}
        elif isinstance(content, list):
            content = {"bullets": content}
        yy = y
        if content.get("title"):
            _, tf = self.tb(slide, x, yy, w, 0.45)
            self.runs(tf.paragraphs[0], content["title"], 18, heading_color or self.c.primary, bold=True)
            self.line(slide, x, yy + 0.5, x + w, yy + 0.5, self.c.rule, 0.75)
            yy += 0.65
        if content.get("chart"):
            self._native_chart(slide, content["chart"], x, yy, w, y + h - yy)
        elif content.get("image"):
            img = self._resolve(content["image"])
            if img:
                self.picture_fit(slide, img, x, yy, w, y + h - yy)
        elif content.get("bullets"):
            self.bullets_box(slide, content["bullets"], x, yy, w, y + h - yy, max_pt=18)
        elif content.get("text"):
            self.text_box(slide, content["text"], x, yy, w, y + h - yy, max_pt=18)

    def l_two_column(self, slide, s):
        self.chrome(slide, s)
        x, y, w, h = self.area
        gap = 0.6
        ratio = float(s.get("ratio", 0.5))
        lw = (w - gap) * ratio
        left = s.get("left", {})
        right = s.get("right", {})
        if s.get("left_title") and isinstance(left, (list, str)):
            left = {"title": s["left_title"], ("bullets" if isinstance(left, list) else "text"): left}
        if s.get("right_title") and isinstance(right, (list, str)):
            right = {"title": s["right_title"], ("bullets" if isinstance(right, list) else "text"): right}
        self._column_content(slide, left, x, y + 0.05, lw, h - 0.05)
        self.line(slide, x + lw + gap / 2, y + 0.1, x + lw + gap / 2, y + h - 0.1, self.c.rule, 0.75)
        self._column_content(slide, right, x + lw + gap, y + 0.05, w - lw - gap, h - 0.05)

    _STATUS = {"good": "success", "done": "success", "green": "success", "warn": "warning", "amber": "warning",
               "risk": "warning", "bad": "danger", "red": "danger", "info": "accent", "current": "accent"}

    def l_comparison(self, slide, s):
        self.chrome(slide, s)
        x, y, w, h = self.area
        cols = s.get("columns") or []
        n = max(1, len(cols))
        gap = 0.3
        cw = (w - gap * (n - 1)) / n
        for i, col in enumerate(cols):
            cx = x + i * (cw + gap)
            status = col.get("status")
            top_color = getattr(self.c, self._STATUS.get(status, ""), None) if status else None
            top_color = top_color or (self.c.primary if not col.get("highlight") else self.c.accent)
            self.rect(slide, cx, y + 0.05, cw, h - 0.05, self.c.surface if not col.get("highlight") else tint(self.c.accent, 0.88))
            self.rect(slide, cx, y + 0.05, cw, 0.08, top_color)
            yy = y + 0.35
            if col.get("tag"):
                _, tf = self.tb(slide, cx + 0.25, yy, cw - 0.5, 0.3)
                self.runs(tf.paragraphs[0], str(col["tag"]).upper(), 10, top_color, bold=True)
                yy += 0.35
            _, tf = self.tb(slide, cx + 0.25, yy, cw - 0.5, 0.6)
            self.runs(tf.paragraphs[0], col.get("title", ""), 19 if n <= 3 else 16, self.c.primary_dark, bold=True)
            yy += 0.7
            if col.get("value"):
                _, tf = self.tb(slide, cx + 0.25, yy, cw - 0.5, 0.7)
                self.runs(tf.paragraphs[0], col["value"], 30, self.c.primary, bold=True)
                yy += 0.8
            if col.get("bullets"):
                self.bullets_box(slide, col["bullets"], cx + 0.25, yy, cw - 0.5, y + h - yy - 0.2, max_pt=15)
            elif col.get("text"):
                self.text_box(slide, col["text"], cx + 0.25, yy, cw - 0.5, y + h - yy - 0.2, max_pt=15)

    def l_table(self, slide, s):
        self.chrome(slide, s)
        x, y, w, h = self.area
        t = s["table"]
        cols = [str(c) for c in t["columns"]]
        rows = t["rows"]
        nr, nc = len(rows) + 1, len(cols)
        rh = min(0.5, (h - 0.1) / nr)
        fs = t.get("font_size") or max(10, min(15, int(rh * 72 * 0.42)))
        widths = t.get("widths")
        if widths:
            sc = w / sum(widths); widths = [v * sc for v in widths]
        else:
            lens = [min(max([len(plain(cols[j]))] + [len(plain(r[j])) for r in rows if j < len(r)] + [4]), 40) for j in range(nc)]
            widths = [w * l / sum(lens) for l in lens]
        gf = slide.shapes.add_table(nr, nc, Inches(x), Inches(y + 0.05), Inches(w), Inches(rh * nr))
        tbl = gf.table
        # strip the default table style for a clean look
        tblPr = tbl._tbl.tblPr
        tblPr.set("firstRow", "1"); tblPr.set("bandRow", "0")
        sid = tblPr.find(qn("a:tableStyleId"))
        if sid is None:
            sid = etree.SubElement(tblPr, qn("a:tableStyleId"))
        sid.text = "{5940675A-B579-460E-94D1-54222C63F5DA}"  # "No Style, Table Grid"
        for j, wv in enumerate(widths):
            tbl.columns[j].width = Inches(wv)
        align = t.get("align") or []

        def isnum(v):
            try:
                float(plain(v).replace(",", "").replace("%", "").replace("$", "").replace("+", "")); return True
            except ValueError:
                return False
        numeric = [bool(rows) and all(isnum(r[j]) for r in rows if j < len(r) and plain(r[j]).strip()) for j in range(nc)]
        hl = t.get("highlight_cells", {})
        for i in range(nr):
            tbl.rows[i].height = Inches(rh)
            for j in range(nc):
                cell = tbl.cell(i, j)
                val = cols[j] if i == 0 else (rows[i - 1][j] if j < len(rows[i - 1]) else "")
                cell.margin_left = cell.margin_right = Inches(0.1)
                cell.margin_top = cell.margin_bottom = Inches(0.03)
                cell.vertical_anchor = MSO_ANCHOR.MIDDLE
                fill = self.c.primary if i == 0 else (self.c.surface if i % 2 == 0 else self.c.white)
                key = f"{i - 1},{j}"
                if i and key in hl:
                    fill = {"good": tint(self.c.success, 0.78), "warn": tint(self.c.warning, 0.7),
                            "bad": tint(self.c.danger, 0.78)}.get(hl[key], hl[key])
                if i and t.get("total_row") and i == nr - 1:
                    fill = tint(self.c.primary, 0.85)
                cell.fill.solid(); cell.fill.fore_color.rgb = _rgb(fill)
                tf = cell.text_frame
                tf.word_wrap = True
                p = tf.paragraphs[0]
                a = align[j] if j < len(align) else ("right" if numeric[j] else "left")
                p.alignment = {"right": PP_ALIGN.RIGHT, "center": PP_ALIGN.CENTER}.get(a, PP_ALIGN.LEFT)
                bold = i == 0 or (t.get("first_col_bold") and j == 0) or (t.get("total_row") and i == nr - 1)
                self.runs(p, str(val), fs, self.c.white if i == 0 else self.c.text, bold=bold or None)
                # thin horizontal rules only
                tcPr = cell._tc.get_or_add_tcPr()
                for edge, show in (("a:lnL", False), ("a:lnR", False), ("a:lnT", False), ("a:lnB", True)):
                    ln = etree.SubElement(tcPr, qn(edge))
                    if show:
                        ln.set("w", str(int(Pt(0.75 if i < nr - 1 else 1.5))))
                        sf = etree.SubElement(ln, qn("a:solidFill"))
                        clr = etree.SubElement(sf, qn("a:srgbClr"))
                        clr.set("val", self.c.rule if i < nr - 1 else self.c.primary)
                    else:
                        ln.set("w", "0")
                        etree.SubElement(ln, qn("a:noFill"))
                # tcPr children must precede the fill already set; move fill last for schema order
                fills = [e for e in tcPr if e.tag in (qn("a:solidFill"), qn("a:noFill")) and e.getparent() is tcPr]
                for fe in fills:
                    tcPr.remove(fe); tcPr.append(fe)

    _CHART = {
        "bar": XL_CHART_TYPE.COLUMN_CLUSTERED, "column": XL_CHART_TYPE.COLUMN_CLUSTERED,
        "barh": XL_CHART_TYPE.BAR_CLUSTERED, "stacked": XL_CHART_TYPE.COLUMN_STACKED,
        "stacked_barh": XL_CHART_TYPE.BAR_STACKED, "line": XL_CHART_TYPE.LINE_MARKERS,
        "area": XL_CHART_TYPE.AREA, "donut": XL_CHART_TYPE.DOUGHNUT, "pie": XL_CHART_TYPE.PIE,
    }

    def _native_chart(self, slide, ch, x, y, w, h):
        kind = ch.get("kind", "bar")
        cd = CategoryChartData()
        cd.categories = [str(c) for c in ch["categories"]]
        for s in ch["series"]:
            cd.add_series(s["name"], [float(v) for v in s["values"]])
        gf = slide.shapes.add_chart(self._CHART[kind], Inches(x), Inches(y), Inches(w), Inches(h), cd)
        chart = gf.chart
        palette = [str(c).lstrip("#") for c in (ch.get("colors") or self.c.chart)]
        chart.font.size = Pt(12)
        chart.font.name = self.f.body
        chart.font.color.rgb = _rgb(self.c.muted)
        n = len(ch["series"])
        if ch.get("title"):
            chart.has_title = True
            chart.chart_title.text_frame.text = plain(ch["title"])
            tp = chart.chart_title.text_frame.paragraphs[0]
            tp.runs[0].font.size = Pt(14); tp.runs[0].font.bold = True
            tp.runs[0].font.color.rgb = _rgb(self.c.text)
        else:
            chart.has_title = False
        plot = chart.plots[0]
        if kind in ("donut", "pie"):
            pts = plot.series[0].points
            for i in range(len(ch["categories"])):
                pts[i].format.fill.solid(); pts[i].format.fill.fore_color.rgb = _rgb(palette[i % len(palette)])
                pts[i].format.line.color.rgb = _rgb(self.c.white); pts[i].format.line.width = Pt(2)
            chart.has_legend = True
            chart.legend.position = XL_LEGEND_POSITION.RIGHT
            chart.legend.include_in_layout = False
            chart.legend.font.size = Pt(13)
            plot.has_data_labels = True
            dl = plot.data_labels
            dl.number_format = "0%"; dl.number_format_is_linked = False
            dl.show_percentage = True; dl.show_value = False
            dl.font.size = Pt(12); dl.font.bold = True; dl.font.color.rgb = _rgb(self.c.white)
            if kind == "donut":
                hole = plot._element.find(qn("c:holeSize"))
                if hole is None:
                    hole = etree.SubElement(plot._element, qn("c:holeSize"))
                hole.set("val", "55")
            return chart
        for i, sr in enumerate(plot.series):
            col = _rgb(palette[i % len(palette)])
            if kind == "line":
                sr.format.line.color.rgb = col
                sr.format.line.width = Pt(2.5)
                sr.smooth = False
                sr.marker.size = 7
                sr.marker.format.fill.solid(); sr.marker.format.fill.fore_color.rgb = col
                sr.marker.format.line.color.rgb = _rgb(self.c.white)
            else:
                sr.format.fill.solid(); sr.format.fill.fore_color.rgb = col
                if kind != "area":
                    sr.format.line.color.rgb = _rgb(self.c.white); sr.format.line.width = Pt(1)
        if kind in ("bar", "column", "barh"):
            plot.gap_width = 60 if n > 1 else 80
            plot.overlap = -5 if n > 1 else 0
        elif kind in ("stacked", "stacked_barh"):
            plot.gap_width = 55; plot.overlap = 100
        if kind in ("barh", "stacked_barh"):
            chart.category_axis.reverse_order = True
        va = chart.value_axis
        va.has_major_gridlines = True
        va.major_gridlines.format.line.color.rgb = _rgb(self.c.rule)
        va.major_gridlines.format.line.width = Pt(0.5)
        va.format.line.fill.background()
        va.tick_labels.font.size = Pt(11)
        fmt = ch.get("excel_format")
        if fmt:
            va.tick_labels.number_format = fmt; va.tick_labels.number_format_is_linked = False
        if ch.get("y_min") is not None:
            va.minimum_scale = ch["y_min"]
        if ch.get("y_max") is not None:
            va.maximum_scale = ch["y_max"]
        ca = chart.category_axis
        ca.format.line.color.rgb = _rgb(self.c.rule)
        ca.tick_labels.font.size = Pt(12)
        ca.has_major_gridlines = False
        if n > 1:
            chart.has_legend = True
            chart.legend.position = XL_LEGEND_POSITION.TOP
            chart.legend.include_in_layout = False
            chart.legend.font.size = Pt(12)
        else:
            chart.has_legend = False
        if ch.get("value_labels", n == 1 and kind != "line"):
            plot.has_data_labels = True
            dl = plot.data_labels
            dl.font.size = Pt(11); dl.font.color.rgb = _rgb(self.c.text)
            if fmt:
                dl.number_format = fmt; dl.number_format_is_linked = False
            if kind in ("bar", "column", "barh"):
                dl.position = XL_LABEL_POSITION.OUTSIDE_END
        return chart

    def l_chart(self, slide, s):
        self.chrome(slide, s)
        x, y, w, h = self.area
        side = s.get("bullets") or s.get("callout") or s.get("insights")
        if side:
            cw = w * 0.64
            self._native_chart(slide, s["chart"], x, y, cw, h)
            if isinstance(side, list):
                side = {"title": s.get("insights_title", "Insights"), "bullets": side}
            self._side_panel(slide, side, x + cw + 0.3, y + 0.05, w - cw - 0.3, h - 0.05)
        else:
            self._native_chart(slide, s["chart"], x, y, w, h)

    def l_image(self, slide, s):
        self.chrome(slide, s)
        x, y, w, h = self.area
        img = self._resolve(s.get("image"))
        cap_h = 0.35 if s.get("caption") else 0
        if img:
            self.picture_fit(slide, img, x, y, w, h - cap_h)
        else:
            self.rect(slide, x, y, w, h - cap_h, self.c.surface, line=self.c.rule)
            _, tf = self.tb(slide, x, y, w, h - cap_h, anchor="middle")
            tf.paragraphs[0].alignment = PP_ALIGN.CENTER
            self.runs(tf.paragraphs[0], f"Image not found: {s.get('image')}", 14, self.c.muted)
        if cap_h:
            _, tf = self.tb(slide, x, y + h - cap_h + 0.05, w, cap_h)
            tf.paragraphs[0].alignment = PP_ALIGN.CENTER
            self.runs(tf.paragraphs[0], s["caption"], 11, self.c.muted, italic=True)

    def l_kpis(self, slide, s):
        self.chrome(slide, s)
        x, y, w, h = self.area
        items = s.get("kpis") or []
        n = len(items)
        per_row = n if n <= 4 else math.ceil(n / 2)
        rows = math.ceil(n / per_row)
        gap = 0.3
        has_bullets = bool(s.get("bullets"))
        kh_total = h * (0.55 if has_bullets else 1.0)
        cw = (w - gap * (per_row - 1)) / per_row
        ch = min(2.6, (kh_total - gap * (rows - 1)) / rows)
        for i, k in enumerate(items):
            r, cidx = divmod(i, per_row)
            cx, cy = x + cidx * (cw + gap), y + 0.05 + r * (ch + gap)
            self.rect(slide, cx, cy, cw, ch, self.c.surface)
            self.rect(slide, cx, cy, cw, 0.07, self.c.primary)
            _, tf = self.tb(slide, cx + 0.3, cy + 0.3, cw - 0.6, 0.35)
            self.runs(tf.paragraphs[0], str(k.get("label", "")).upper(), 11, self.c.muted, bold=True)
            vs = 44 if len(str(k.get("value", ""))) <= 6 else 34
            _, tf = self.tb(slide, cx + 0.3, cy + 0.7, cw - 0.6, 0.9, anchor="middle")
            self.runs(tf.paragraphs[0], str(k.get("value", "")), vs, self.c.primary, bold=True, font=self.f.heading)
            parts = []
            if k.get("delta") is not None:
                d = str(k["delta"])
                neg = d.strip().startswith(("-", "−"))
                good = k.get("good", not neg)
                parts.append((("▼ " if neg else "▲ ") + d.lstrip("+"), self.c.success if good else self.c.danger, True))
            if k.get("note"):
                parts.append((("   " if parts else "") + k["note"], self.c.muted, False))
            if parts:
                _, tf = self.tb(slide, cx + 0.3, cy + 1.65, cw - 0.6, ch - 1.8)
                for text, col, bold in parts:
                    self.runs(tf.paragraphs[0], text, 13, col, bold=bold)
        if has_bullets:
            by = y + kh_total + 0.35
            self.bullets_box(slide, s["bullets"], x, by, w, y + h - by, max_pt=17)

    def l_quote(self, slide, s):
        self.chrome(slide, s) if s.get("title") else self._bare(slide, s)
        x, y, w, h = self.area if s.get("title") else (1.2, 1.2, SW - 2.4, 4.8)
        _, tf = self.tb(slide, x, y, 1.2, 1.3)
        self.runs(tf.paragraphs[0], "“", 120, self.c.accent, bold=True, font="Georgia")
        q = s.get("quote") or s.get("text", "")
        size = fit_size([(0, plain(q))], w - 1.2, h - 1.0, 30, 16, spacing=1.25)
        _, tf = self.tb(slide, x + 1.0, y + 0.55, w - 1.4, h - 1.3, anchor="middle")
        p = tf.paragraphs[0]; p.line_spacing = 1.15
        self.runs(p, q, size, self.c.primary_dark, italic=True)
        if s.get("attribution"):
            p2 = tf.add_paragraph(); p2.space_before = Pt(18)
            self.runs(p2, "— " + s["attribution"], 15, self.c.muted, bold=True)

    def _bare(self, slide, s):
        self.page += 1
        if self.marking():
            _, tf = self.tb(slide, MX, 7.02, 6, 0.3, anchor="middle")
            self.runs(tf.paragraphs[0], self.marking(), 8, self.c.primary, bold=True)
        _, tf = self.tb(slide, SW - MX - 0.6, 7.02, 0.6, 0.3, anchor="middle")
        tf.paragraphs[0].alignment = PP_ALIGN.RIGHT
        self.runs(tf.paragraphs[0], str(self.page), 9, self.c.text, bold=True)
        self.notes(slide, s)

    def l_timeline(self, slide, s):
        self.chrome(slide, s)
        x, y, w, h = self.area
        ms = s.get("milestones") or []
        n = max(1, len(ms))
        ly = y + h * 0.36
        self.rect(slide, x, ly - 0.03, w, 0.06, self.c.rule)
        step = w / n
        reached = [i for i, m in enumerate(ms) if m.get("status") in ("done", "current")]
        if reached:
            self.rect(slide, x, ly - 0.03, step * max(reached) + step / 2, 0.06, self.c.primary)
        for i, m in enumerate(ms):
            cx = x + step * i + step / 2
            status = m.get("status", "planned")
            col = {"done": self.c.primary, "current": self.c.accent, "risk": self.c.warning,
                   "late": self.c.danger}.get(status, self.c.white)
            d = 0.34 if status != "current" else 0.44
            dot = self.rect(slide, cx - d / 2, ly - d / 2, d, d, col, shape=MSO_SHAPE.OVAL)
            dot.line.color.rgb = _rgb(self.c.primary if status == "planned" else self.c.white)
            dot.line.width = Pt(2)
            _, tf = self.tb(slide, cx - step / 2 + 0.08, ly - 0.95, step - 0.16, 0.6, anchor="bottom")
            tf.paragraphs[0].alignment = PP_ALIGN.CENTER
            self.runs(tf.paragraphs[0], str(m.get("date", "")), 13, self.c.accent if status == "current" else self.c.muted, bold=True)
            _, tf = self.tb(slide, cx - step / 2 + 0.08, ly + 0.4, step - 0.16, h - (ly - y) - 0.4)
            p = tf.paragraphs[0]; p.alignment = PP_ALIGN.CENTER
            self.runs(p, m.get("title", ""), 15 if n <= 5 else 13, self.c.primary_dark, bold=True)
            if m.get("text"):
                p2 = tf.add_paragraph(); p2.alignment = PP_ALIGN.CENTER; p2.space_before = Pt(6)
                self.runs(p2, m["text"], 12 if n <= 5 else 11, self.c.muted)

    # ------------------------------------------------------------- build
    def build(self, out_path: Path) -> Path:
        for s in self.slides_spec:
            slide = self.prs.slides.add_slide(self.blank)
            fn = getattr(self, f"l_{s['layout']}")
            fn(slide, s)
        cp = self.prs.core_properties
        cp.title = plain(self.meta.get("title", ""))
        cp.author = self.meta.get("author", "")
        cp.subject = plain(self.meta.get("subtitle", ""))
        cp.comments = "Generated by docsmith"
        out_path.parent.mkdir(parents=True, exist_ok=True)
        self.prs.save(str(out_path))
        return out_path


def build_pptx(spec, theme, out_path: Path):
    b = PptxBuilder(spec, theme)
    path = b.build(Path(out_path))
    return path, b.warnings
