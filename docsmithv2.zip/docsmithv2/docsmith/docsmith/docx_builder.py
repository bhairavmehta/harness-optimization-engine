"""Detailed, themed Word (.docx) document builder.

Produces: cover page, revision history, approvals, table of contents
(a real Word TOC field, refreshed by LibreOffice before PDF export and by
Word on open), numbered headings, captioned figures and tables, callouts,
KPI strips, code blocks, definitions, two-column regions, and running
headers/footers carrying the document number, proprietary marking and
"Page X of Y".
"""
from __future__ import annotations

import copy
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional

from docx import Document
from docx.enum.section import WD_ORIENT
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK, WD_TAB_ALIGNMENT, WD_COLOR_INDEX
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor, Emu

from .charts import render_chart
from .ooxml_order import fix_order, insert_update_fields
from .richtext import parse_inline, plain
from .theme import Theme, tint

# ----------------------------------------------------------------------------
# low-level OOXML helpers
# ----------------------------------------------------------------------------

def _rgb(h: str) -> RGBColor:
    return RGBColor.from_string(h.upper())


def _el(tag: str, **attrs) -> OxmlElement:
    e = OxmlElement(tag)
    for k, v in attrs.items():
        e.set(qn(k), str(v))
    return e


def shade_cell(cell, fill: str) -> None:
    tcPr = cell._tc.get_or_add_tcPr()
    for old in tcPr.findall(qn("w:shd")):
        tcPr.remove(old)
    tcPr.append(_el("w:shd", **{"w:val": "clear", "w:color": "auto", "w:fill": fill}))


def cell_borders(cell, **edges) -> None:
    """edges: top/left/bottom/right = (size_eighths, color) or None for nil."""
    tcPr = cell._tc.get_or_add_tcPr()
    b = tcPr.find(qn("w:tcBorders"))
    if b is None:
        b = _el("w:tcBorders")
        tcPr.append(b)
    for edge in ("top", "left", "bottom", "right"):
        if edge not in edges:
            continue
        for old in b.findall(qn(f"w:{edge}")):
            b.remove(old)
        val = edges[edge]
        if val is None:
            b.append(_el(f"w:{edge}", **{"w:val": "nil"}))
        else:
            sz, color = val
            b.append(_el(f"w:{edge}", **{"w:val": "single", "w:sz": sz, "w:space": 0, "w:color": color}))


def cell_margins(cell, top=80, bottom=80, left=110, right=110) -> None:
    tcPr = cell._tc.get_or_add_tcPr()
    m = _el("w:tcMar")
    for k, v in (("top", top), ("left", left), ("bottom", bottom), ("right", right)):
        m.append(_el(f"w:{k}", **{"w:w": v, "w:type": "dxa"}))
    tcPr.append(m)


def table_borders(table, color: str, size: int = 4, inside_v: bool = True, outer: bool = True) -> None:
    tblPr = table._tbl.tblPr
    for old in tblPr.findall(qn("w:tblBorders")):
        tblPr.remove(old)
    b = _el("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        if (edge == "insideV" and not inside_v) or (edge in ("top", "left", "bottom", "right") and not outer):
            b.append(_el(f"w:{edge}", **{"w:val": "nil"}))
        else:
            b.append(_el(f"w:{edge}", **{"w:val": "single", "w:sz": size, "w:space": 0, "w:color": color}))
    tblPr.append(b)


def no_borders(table) -> None:
    tblPr = table._tbl.tblPr
    for old in tblPr.findall(qn("w:tblBorders")):
        tblPr.remove(old)
    b = _el("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        b.append(_el(f"w:{edge}", **{"w:val": "nil"}))
    tblPr.append(b)


def set_col_widths(table, widths_in: List[float]) -> None:
    table.autofit = False
    tblPr = table._tbl.tblPr
    for old in tblPr.findall(qn("w:tblW")):
        tblPr.remove(old)
    tblPr.append(_el("w:tblW", **{"w:w": int(sum(widths_in) * 1440), "w:type": "dxa"}))
    for old in tblPr.findall(qn("w:tblLayout")):
        tblPr.remove(old)
    tblPr.append(_el("w:tblLayout", **{"w:type": "fixed"}))
    grid = table._tbl.tblGrid
    cols = grid.findall(qn("w:gridCol"))
    for gc, w in zip(cols, widths_in):
        gc.set(qn("w:w"), str(int(w * 1440)))
    for row in table.rows:
        for cell, w in zip(row.cells, widths_in):
            cell.width = Inches(w)


def repeat_header(row) -> None:
    trPr = row._tr.get_or_add_trPr()
    trPr.append(_el("w:tblHeader", **{"w:val": "true"}))


def cant_split(row) -> None:
    trPr = row._tr.get_or_add_trPr()
    trPr.append(_el("w:cantSplit", **{"w:val": "true"}))


def para_border(paragraph_or_style_pPr, edge: str, color: str, size: int = 8, space: int = 4) -> None:
    pPr = paragraph_or_style_pPr
    bdr = pPr.find(qn("w:pBdr"))
    if bdr is None:
        bdr = _el("w:pBdr")
        pPr.append(bdr)
    bdr.append(_el(f"w:{edge}", **{"w:val": "single", "w:sz": size, "w:space": space, "w:color": color}))


def para_shading(paragraph, fill: str) -> None:
    pPr = paragraph._p.get_or_add_pPr()
    pPr.append(_el("w:shd", **{"w:val": "clear", "w:color": "auto", "w:fill": fill}))


def add_field(paragraph, instr: str, placeholder: str = "1", font_size: Optional[float] = None, color=None, bold=False):
    def r():
        run = paragraph.add_run()
        if font_size:
            run.font.size = Pt(font_size)
        if color:
            run.font.color.rgb = _rgb(color)
        run.bold = bold
        return run
    r()._r.append(_el("w:fldChar", **{"w:fldCharType": "begin"}))
    it = _el("w:instrText", **{"xml:space": "preserve"})
    it.text = f" {instr} "
    r()._r.append(it)
    r()._r.append(_el("w:fldChar", **{"w:fldCharType": "separate"}))
    ph = r()
    ph.text = placeholder
    r()._r.append(_el("w:fldChar", **{"w:fldCharType": "end"}))


def add_hyperlink(paragraph, url: str, text: str, color: str, size: Optional[float] = None):
    part = paragraph.part
    r_id = part.relate_to(url, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink",
                          is_external=True)
    h = _el("w:hyperlink", **{"r:id": r_id})
    r = _el("w:r")
    rPr = _el("w:rPr")
    rPr.append(_el("w:color", **{"w:val": color}))
    rPr.append(_el("w:u", **{"w:val": "single"}))
    if size:
        rPr.append(_el("w:sz", **{"w:val": int(size * 2)}))
    r.append(rPr)
    t = _el("w:t", **{"xml:space": "preserve"})
    t.text = text
    r.append(t)
    h.append(r)
    paragraph._p.append(h)


def keep_with_next(paragraph, on=True):
    paragraph.paragraph_format.keep_with_next = on


# ----------------------------------------------------------------------------
# builder
# ----------------------------------------------------------------------------

class DocxBuilder:
    def __init__(self, spec: Dict[str, Any], theme: Theme, workdir: Optional[Path] = None):
        self.spec = spec
        self.meta = spec["meta"]
        self.docspec = spec["document"]
        self.theme = theme
        self.c = theme.colors
        self.f = theme.fonts
        self.base = Path(spec.get("_base_dir", "."))
        self.work = Path(workdir or tempfile.mkdtemp(prefix="docsmith_"))
        self.doc = Document()
        self.fig_n = 0
        self.tab_n = 0
        self.h_counters = [0, 0, 0, 0]
        self.numbered = self.docspec.get("numbered_headings", theme.numbered_headings)
        self.warnings: List[str] = []

    # --- geometry ---------------------------------------------------------
    @property
    def content_w(self) -> float:
        s = self.doc.sections[0]
        return (s.page_width - s.left_margin - s.right_margin) / 914400

    # --- runs -------------------------------------------------------------
    def runs(self, p, text, size=None, color=None, bold=None, italic=None, font=None):
        for r in parse_inline(text):
            if r.link:
                add_hyperlink(p, r.link, r.text, self.c.accent, size)
                continue
            run = p.add_run(r.text)
            run.bold = True if r.bold else bold
            run.italic = True if r.italic else italic
            if size:
                run.font.size = Pt(size)
            if color:
                run.font.color.rgb = _rgb(color)
            if font:
                run.font.name = font
            if r.code:
                run.font.name = self.f.mono
                run.font.size = Pt((size or self.f.doc_body) - 1)
                rPr = run._r.get_or_add_rPr()
                rPr.append(_el("w:shd", **{"w:val": "clear", "w:color": "auto", "w:fill": self.c.surface}))
            if r.highlight:
                run.font.highlight_color = WD_COLOR_INDEX.YELLOW
            if r.superscript:
                run.font.superscript = True
            if r.subscript:
                run.font.subscript = True
        return p

    # --- styles -------------------------------------------------------------
    def _style_font(self, style, name, size, color=None, bold=None, italic=None):
        style.font.name = name
        rPr = style.element.get_or_add_rPr()
        rf = rPr.find(qn("w:rFonts"))
        if rf is None:
            rf = _el("w:rFonts"); rPr.append(rf)
        for a in ("w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"):
            rf.set(qn(a), name)
        for a in ("w:asciiTheme", "w:hAnsiTheme", "w:cstheme", "w:eastAsiaTheme"):
            if rf.get(qn(a)) is not None:
                del rf.attrib[qn(a)]
        style.font.size = Pt(size)
        if color:
            style.font.color.rgb = _rgb(color)
        if bold is not None:
            style.font.bold = bold
        if italic is not None:
            style.font.italic = italic

    def _ensure_style(self, name: str, style_id: str, base="Normal"):
        try:
            return self.doc.styles[name]
        except KeyError:
            st = self.doc.styles.add_style(name, WD_STYLE_TYPE.PARAGRAPH)
            st.base_style = self.doc.styles[base]
            st.element.set(qn("w:styleId"), style_id)
            return st

    def setup(self):
        d = self.doc
        sec = d.sections[0]
        if self.theme.page_size.lower() == "a4":
            sec.page_width, sec.page_height = Inches(8.27), Inches(11.69)
        else:
            sec.page_width, sec.page_height = Inches(8.5), Inches(11)
        if self.docspec.get("landscape"):
            sec.orientation = WD_ORIENT.LANDSCAPE
            sec.page_width, sec.page_height = sec.page_height, sec.page_width
        m = self.docspec.get("margins_in", 1.0)
        sec.left_margin = sec.right_margin = Inches(m)
        sec.top_margin = Inches(1.0)
        sec.bottom_margin = Inches(0.9)
        sec.header_distance = Inches(0.45)
        sec.footer_distance = Inches(0.4)

        st = d.styles
        self._style_font(st["Normal"], self.f.body, self.f.doc_body, self.c.text)
        pf = st["Normal"].paragraph_format
        pf.space_after = Pt(6)
        pf.line_spacing = 1.15

        sizes = {1: self.f.doc_h1, 2: self.f.doc_h2, 3: self.f.doc_h3, 4: self.f.doc_body + 0.5}
        colors = {1: self.c.primary, 2: self.c.primary, 3: self.c.primary_dark, 4: self.c.text}
        for lvl in (1, 2, 3, 4):
            hs = st[f"Heading {lvl}"]
            self._style_font(hs, self.f.heading, sizes[lvl], colors[lvl], bold=True, italic=False)
            hpf = hs.paragraph_format
            hpf.space_before = Pt({1: 18, 2: 14, 3: 10, 4: 8}[lvl])
            hpf.space_after = Pt({1: 8, 2: 6, 3: 4, 4: 3}[lvl])
            hpf.keep_with_next = True
            hpf.line_spacing = 1.0
            if lvl == 1:
                para_border(hs.element.get_or_add_pPr(), "bottom", self.c.primary, size=8, space=4)

        cap = st["Caption"]
        self._style_font(cap, self.f.body, self.f.doc_caption, self.c.muted, bold=False, italic=False)
        cap.paragraph_format.space_before = Pt(4)
        cap.paragraph_format.space_after = Pt(10)

        th = st["TOC Heading"]
        self._style_font(th, self.f.heading, self.f.doc_h1, self.c.primary, bold=True)
        th.paragraph_format.space_after = Pt(12)
        th.paragraph_format.space_before = Pt(0)

        for lvl in (1, 2, 3):
            ts = self._ensure_style(f"toc {lvl}", f"TOC{lvl}")
            self._style_font(ts, self.f.body, self.f.doc_body if lvl > 1 else self.f.doc_body + 0.5,
                             self.c.text, bold=(lvl == 1))
            tpf = ts.paragraph_format
            tpf.left_indent = Inches(0.25 * (lvl - 1))
            tpf.space_before = Pt(6 if lvl == 1 else 1)
            tpf.space_after = Pt(1)
            tpf.tab_stops.add_tab_stop(Inches(self.content_w), WD_TAB_ALIGNMENT.RIGHT, 1)  # dot leader

        for name in ("List Bullet", "List Bullet 2", "List Bullet 3", "List Number", "List Number 2"):
            ls = st[name]
            self._style_font(ls, self.f.body, self.f.doc_body, self.c.text)
            ls.paragraph_format.space_after = Pt(3)

        for hf in ("Header", "Footer"):
            try:
                pPr = st[hf].element.get_or_add_pPr()
                for tabs in pPr.findall(qn("w:tabs")):
                    pPr.remove(tabs)
            except KeyError:
                pass

        q = st["Quote"]
        self._style_font(q, self.f.body, self.f.doc_body + 1, self.c.primary_dark, italic=True)

        # document properties
        cp = d.core_properties
        cp.title = plain(self.meta.get("title", ""))
        cp.subject = plain(self.meta.get("subtitle", ""))
        cp.author = self.meta.get("author", "")
        cp.keywords = ", ".join(self.meta.get("keywords", []))
        cp.category = self.meta.get("doc_number", "")
        cp.comments = "Generated by docsmith"

    # --- header / footer -------------------------------------------------------
    def _marking(self) -> str:
        return self.meta.get("marking", self.theme.marking) or ""

    def _notice(self) -> str:
        year = str(self.meta.get("year") or self.meta["date"][-4:])
        return (self.meta.get("marking_notice") or self.theme.marking_notice).replace("{year}", year)

    def header_footer(self):
        sec = self.doc.sections[0]
        sec.different_first_page_header_footer = True
        W = Inches(self.content_w)

        # cover page: marking only, top & bottom
        for hf in (sec.first_page_header, sec.first_page_footer):
            p = hf.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            if self._marking():
                self.runs(p, self._marking(), size=8, color=self.c.muted, bold=True)

        # running header: title (left) | doc number (right), rule underneath
        p = sec.header.paragraphs[0]
        p.paragraph_format.tab_stops.add_tab_stop(W, WD_TAB_ALIGNMENT.RIGHT)
        logo = self.theme.logo
        if logo and Path(logo).exists() and self.docspec.get("header_logo", True):
            p.add_run().add_picture(str(logo), height=Inches(float(self.docspec.get("header_logo_in", 0.22))))
            p.add_run("   ")
        self.runs(p, plain(self.meta.get("short_title") or self.meta["title"]), size=8, color=self.c.muted)
        right = " · ".join(x for x in [self.meta.get("doc_number"),
                                            f"Rev {self.meta['revision']}" if self.meta.get("revision") else None] if x)
        if right:
            p.add_run("\t")
            self.runs(p, right, size=8, color=self.c.muted)
        para_border(p._p.get_or_add_pPr(), "bottom", self.c.rule, size=4, space=4)
        if self._marking():
            p0 = sec.header.add_paragraph()
            p0._p.getparent().remove(p0._p)
            p._p.addprevious(p0._p)
            p0.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p0.paragraph_format.space_after = Pt(2)
            self.runs(p0, self._marking(), size=7.5, color=self.c.primary, bold=True)

        # running footer: marking/notice (left) | Page X of Y (right)
        f = sec.footer.paragraphs[0]
        f.paragraph_format.tab_stops.add_tab_stop(W, WD_TAB_ALIGNMENT.RIGHT)
        para_border(f._p.get_or_add_pPr(), "top", self.c.rule, size=4, space=4)
        self.runs(f, self.meta.get("footer_left") or self.theme.org, size=7.5, color=self.c.muted)
        f.add_run("\t")
        r = f.add_run("Page "); r.font.size = Pt(7.5); r.font.color.rgb = _rgb(self.c.muted)
        add_field(f, "PAGE", "1", 7.5, self.c.text, bold=True)
        r = f.add_run(" of "); r.font.size = Pt(7.5); r.font.color.rgb = _rgb(self.c.muted)
        add_field(f, "NUMPAGES", "1", 7.5, self.c.muted)
        if self._marking():
            f2 = sec.footer.add_paragraph()
            f2.alignment = WD_ALIGN_PARAGRAPH.CENTER
            f2.paragraph_format.space_before = Pt(2)
            self.runs(f2, self._marking(), size=7.5, color=self.c.primary, bold=True)

    # --- cover --------------------------------------------------------------
    def cover(self):
        d = self.doc
        W = self.content_w
        m = self.meta
        logo = self.theme.logo
        top = d.paragraphs[0] if d.paragraphs else d.add_paragraph()
        if logo and Path(logo).exists():
            top.add_run().add_picture(str(logo), height=Inches(float(self.docspec.get("cover_logo_in", 0.6))))
        else:
            self.runs(top, (m.get("org") or self.theme.org).upper(), size=10, color=self.c.primary, bold=True)
            r = top.runs[-1]
            rPr = r._r.get_or_add_rPr(); rPr.append(_el("w:spacing", **{"w:val": 40}))
        if m.get("division"):
            p = d.add_paragraph()
            self.runs(p, m["division"], size=9, color=self.c.muted)
        sp = d.add_paragraph(); sp.paragraph_format.space_after = Pt(int(self.docspec.get("cover_offset_pt", 84)))

        # title band
        band = d.add_table(rows=1, cols=1)
        band.alignment = WD_TABLE_ALIGNMENT.CENTER
        no_borders(band)
        set_col_widths(band, [W])
        cell = band.cell(0, 0)
        shade_cell(cell, self.c.primary_dark)
        cell_margins(cell, top=360, bottom=360, left=360, right=360)
        cell_borders(cell, left=(48, self.c.accent))
        p = cell.paragraphs[0]
        if m.get("doc_type"):
            self.runs(p, m["doc_type"].upper(), size=9, color=self.c.accent_light, bold=True)
            p.paragraph_format.space_after = Pt(10)
            p = cell.add_paragraph()
        p.paragraph_format.line_spacing = 1.0
        p.paragraph_format.space_after = Pt(8)
        self.runs(p, m["title"], size=self.f.doc_title, color=self.c.white, bold=True, font=self.f.heading)
        if m.get("subtitle"):
            p2 = cell.add_paragraph()
            p2.paragraph_format.space_after = Pt(0)
            self.runs(p2, m["subtitle"], size=13, color=self.c.accent_light)

        d.add_paragraph().paragraph_format.space_after = Pt(18)

        # metadata grid
        rows = [(k, m.get(key)) for k, key in (
            ("Document No.", "doc_number"), ("Revision", "revision"), ("Date", "date"),
            ("Prepared by", "author"), ("Organization", "org"), ("Prepared for", "audience"),
            ("Status", "status"))]
        rows += [(k, v) for k, v in (m.get("extra_fields") or {}).items()]
        rows = [(k, v) for k, v in rows if v]
        if rows:
            t = d.add_table(rows=len(rows), cols=2)
            no_borders(t)
            set_col_widths(t, [1.6, W - 1.6])
            for i, (k, v) in enumerate(rows):
                a, b = t.cell(i, 0), t.cell(i, 1)
                for cl in (a, b):
                    cell_borders(cl, bottom=(4, self.c.rule))
                    cell_margins(cl, top=70, bottom=70, left=0, right=80)
                self.runs(a.paragraphs[0], k.upper(), size=8, color=self.c.muted, bold=True)
                self.runs(b.paragraphs[0], str(v), size=10, color=self.c.text)
                for cl in (a, b):
                    cl.paragraphs[0].paragraph_format.space_after = Pt(0)

        # notice at the bottom of the cover
        notice_lines = [self._notice()] + list(m.get("cover_notices") or [])
        p = d.add_paragraph()
        p.paragraph_format.space_before = Pt(int(self.docspec.get("notice_offset_pt", 90)))
        for i, line in enumerate(x for x in notice_lines if x):
            if i:
                p.add_run().add_break()
            self.runs(p, line, size=7.5, color=self.c.muted)
        # break inside the last cover paragraph so it can never spill a blank page
        p.add_run().add_break(WD_BREAK.PAGE)

    # --- front matter --------------------------------------------------------
    def revision_history(self):
        revs = self.meta.get("revisions")
        if not revs:
            return
        p = self.doc.add_paragraph(style="TOC Heading")
        self.runs(p, "Revision History")
        self._table({"columns": ["Rev", "Date", "Description", "Author"],
                     "rows": [[r.get("rev", ""), r.get("date", ""), r.get("description", ""), r.get("author", "")]
                              for r in revs],
                     "widths": [0.6, 1.2, self.content_w - 3.4, 1.6], "number": False}, self.doc)

    def approvals(self):
        ap = self.meta.get("approvals")
        if not ap:
            return
        p = self.doc.add_paragraph(style="TOC Heading")
        p.paragraph_format.space_before = Pt(18)
        self.runs(p, "Approvals")
        self._signoff({"items": ap}, self.doc)

    def _heading_texts(self) -> List[tuple]:
        """Pre-compute numbered heading labels so the TOC can be pre-filled."""
        out = []
        counters = [0, 0, 0, 0]
        for b in self._walk(self.docspec["blocks"]):
            if b["type"] == "heading" and not b.get("unnumbered"):
                lvl = int(b.get("level", 1))
                counters[lvl - 1] += 1
                for j in range(lvl, 4):
                    counters[j] = 0
                label = ".".join(str(x) for x in counters[:lvl]) if self.numbered and lvl <= 3 else ""
                if lvl <= 3:
                    out.append((lvl, label, plain(b["text"])))
            elif b["type"] == "heading" and int(b.get("level", 1)) <= 3:
                out.append((int(b.get("level", 1)), "", plain(b["text"])))
        return out

    def _walk(self, blocks):
        for b in blocks:
            yield b
            if b["type"] == "two_column":
                yield from self._walk(b["left"])
                yield from self._walk(b["right"])

    def toc(self):
        d = self.doc
        p = d.add_paragraph(style="TOC Heading")
        self.runs(p, self.docspec.get("toc_title", "Contents"))
        depth = int(self.docspec.get("toc_depth", 3))
        entries = [e for e in self._heading_texts() if e[0] <= depth]
        # Multi-paragraph TOC field with pre-filled (page-less) entries.
        first = d.add_paragraph(style="toc 1")
        r = first.add_run(); r._r.append(_el("w:fldChar", **{"w:fldCharType": "begin"}))
        r = first.add_run()
        it = _el("w:instrText", **{"xml:space": "preserve"})
        it.text = f' TOC \\o "1-{depth}" \\h \\z \\u '
        r._r.append(it)
        r = first.add_run(); r._r.append(_el("w:fldChar", **{"w:fldCharType": "separate"}))
        last = first
        for i, (lvl, label, text) in enumerate(entries):
            para = first if i == 0 else d.add_paragraph(style=f"toc {lvl}")
            if i == 0 and lvl != 1:
                para.style = d.styles[f"toc {lvl}"]
            para.add_run(f"{label}  {text}" if label else text)
            para.add_run("\t")
            last = para
        if not entries:
            first.add_run("Right-click and choose Update Field to build the table of contents.")
        r = last.add_run(); r._r.append(_el("w:fldChar", **{"w:fldCharType": "end"}))
        bp = d.add_paragraph()
        bp.add_run().add_break(WD_BREAK.PAGE)

    # --- block dispatch ------------------------------------------------------
    def render_blocks(self, blocks, container):
        for i, b in enumerate(blocks):
            fn = getattr(self, f"_{b['type']}", None)
            if fn is None:
                raise ValueError(f"No renderer for block type {b['type']}")
            fn(b, container)

    def _heading(self, b, ct):
        lvl = max(1, min(4, int(b.get("level", 1))))
        label = ""
        if not b.get("unnumbered"):
            self.h_counters[lvl - 1] += 1
            for j in range(lvl, 4):
                self.h_counters[j] = 0
            if self.numbered and lvl <= 3:
                label = ".".join(str(x) for x in self.h_counters[:lvl])
        if lvl == 1 and b.get("new_page", self.docspec.get("h1_new_page", False)) and self._has_body:
            ct.add_paragraph().add_run().add_break(WD_BREAK.PAGE)
        p = ct.add_paragraph(style=f"Heading {lvl}")
        if label:
            r = p.add_run(label + "  ")
            r.font.color.rgb = _rgb(self.c.accent if lvl == 1 else self.c.primary)
        self.runs(p, b["text"])
        self._has_body = True

    def _paragraph(self, b, ct):
        p = ct.add_paragraph()
        style = b.get("style")
        size = None
        color = None
        if style == "lead":
            size = self.f.doc_body + 2; color = self.c.primary_dark
            p.paragraph_format.space_after = Pt(10)
        elif style == "small":
            size = self.f.doc_body - 1.5; color = self.c.muted
        al = b.get("align")
        if al:
            p.alignment = {"center": WD_ALIGN_PARAGRAPH.CENTER, "right": WD_ALIGN_PARAGRAPH.RIGHT,
                           "justify": WD_ALIGN_PARAGRAPH.JUSTIFY}.get(al, WD_ALIGN_PARAGRAPH.LEFT)
        self.runs(p, b.get("text", ""), size=size, color=color)
        self._has_body = True

    def _iter_items(self, items, level=0):
        for it in items:
            if isinstance(it, list):
                yield from self._iter_items(it, level + 1)
            elif isinstance(it, dict):
                yield level, it.get("text", "")
                kids = it.get("items") or it.get("children")
                if kids:
                    yield from self._iter_items(kids, level + 1)
            else:
                yield level, it

    def _new_numbering(self, style_name: str) -> int:
        numbering = self.doc.part.numbering_part.element
        style = self.doc.styles[style_name]
        num_id = style.element.pPr.numPr.numId.val
        abstract = numbering.num_having_numId(num_id).abstractNumId.val
        num = numbering.add_num(abstract)
        num.add_lvlOverride(ilvl=0).add_startOverride(1)
        return num.numId

    def _bullets(self, b, ct, ordered=False):
        num_id = self._new_numbering("List Number") if ordered else None
        for lvl, text in self._iter_items(b.get("items") or []):
            lvl = min(lvl, 2)
            if ordered and lvl == 0:
                p = ct.add_paragraph(style="List Number")
                pPr = p._p.get_or_add_pPr()
                numPr = _el("w:numPr")
                numPr.append(_el("w:ilvl", **{"w:val": 0}))
                numPr.append(_el("w:numId", **{"w:val": num_id}))
                pPr.append(numPr)
            else:
                name = "List Bullet" if lvl == 0 else f"List Bullet {lvl + 1}"
                p = ct.add_paragraph(style=name)
            self.runs(p, text)
        self._has_body = True

    def _numbered(self, b, ct):
        self._bullets(b, ct, ordered=True)

    def _caption(self, ct, kind: str, n: int, text: str, source: Optional[str] = None, above=False):
        p = ct.add_paragraph(style="Caption")
        if above:
            p.paragraph_format.space_before = Pt(8)
            p.paragraph_format.space_after = Pt(4)
            keep_with_next(p)
        r = p.add_run(f"{kind} ")
        r.bold = True; r.font.color.rgb = _rgb(self.c.primary)
        add_field(p, f"SEQ {kind} \\* ARABIC", str(n), self.f.doc_caption, self.c.primary, bold=True)
        r3 = p.add_run(".  "); r3.bold = True; r3.font.color.rgb = _rgb(self.c.primary)
        self.runs(p, text)
        if source:
            self.runs(p, f"  Source: {source}", color=self.c.muted, italic=True)
        return p

    def _table(self, b, ct):
        cols = [str(x) for x in b["columns"]]
        rows = b["rows"]
        n = len(cols)
        numbered = b.get("number", True)
        if b.get("caption") and numbered:
            self.tab_n += 1
            self._caption(ct, "Table", self.tab_n, b["caption"], above=True)
        t = ct.add_table(rows=1 + len(rows), cols=n)
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
        table_borders(t, self.c.rule, size=4, inside_v=b.get("vertical_lines", False), outer=False)
        avail = self._avail_w(ct)
        widths = b.get("widths")
        if not widths:
            # proportional to content length, clamped
            lens = [max([len(plain(cols[j]))] + [len(plain(r[j])) if j < len(r) else 0 for r in rows]) for j in range(n)]
            lens = [min(max(l, 4), 40) for l in lens]
            tot = sum(lens)
            widths = [avail * l / tot for l in lens]
        else:
            scale = avail / sum(widths) if sum(widths) > avail else 1
            widths = [w * scale for w in widths]
        set_col_widths(t, widths)
        fs = float(b.get("font_size", self.f.doc_body - 1))
        align = b.get("align") or []

        def is_num(v):
            s = plain(v).replace(",", "").replace("%", "").replace("$", "").replace("+", "").replace("−", "-").strip()
            try:
                float(s); return True
            except ValueError:
                return False

        col_numeric = [all(is_num(r[j]) for r in rows if j < len(r) and plain(r[j]).strip()) and rows for j in range(n)]
        hdr = t.rows[0]
        repeat_header(hdr)
        for j, h in enumerate(cols):
            cell = hdr.cells[j]
            shade_cell(cell, self.c.primary)
            cell_margins(cell, top=70, bottom=70)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            p = cell.paragraphs[0]
            p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.line_spacing = 1.0
            self.runs(p, h, size=fs, color=self.c.white, bold=True)
            a = align[j] if j < len(align) else ("right" if col_numeric[j] else "left")
            if a == "right": p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
            elif a == "center": p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        total_row = b.get("total_row", False)
        for i, row in enumerate(rows):
            tr = t.rows[i + 1]
            cant_split(tr)
            last = total_row and i == len(rows) - 1
            for j in range(n):
                v = row[j] if j < len(row) else ""
                cell = tr.cells[j]
                cell_margins(cell, top=60, bottom=60)
                if b.get("zebra", True) and i % 2 == 1 and not last:
                    shade_cell(cell, self.c.surface)
                if last:
                    shade_cell(cell, tint(self.c.primary, 0.88))
                    cell_borders(cell, top=(8, self.c.primary))
                p = cell.paragraphs[0]
                p.paragraph_format.space_after = Pt(0)
                p.paragraph_format.line_spacing = 1.0
                bold = last or (b.get("first_col_bold") and j == 0)
                hl = b.get("highlight_cells", {})
                color = None
                key = f"{i},{j}"
                if key in hl:
                    shade_cell(cell, {"good": tint(self.c.success, 0.8), "warn": tint(self.c.warning, 0.75),
                                      "bad": tint(self.c.danger, 0.8)}.get(hl[key], hl[key]))
                self.runs(p, v if v is not None else "", size=fs, bold=bold or None, color=color)
                a = align[j] if j < len(align) else ("right" if col_numeric[j] else "left")
                if a == "right": p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
                elif a == "center": p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        if len(rows) <= int(b.get("keep_together_max_rows", 15)):
            for tr in t.rows[:-1]:
                for cell in tr.cells:
                    for cp in cell.paragraphs:
                        keep_with_next(cp)
        # bottom rule in primary
        for cell in t.rows[-1].cells:
            cell_borders(cell, bottom=(8, self.c.primary))
        sp = ct.add_paragraph()
        sp.paragraph_format.space_after = Pt(4)
        if b.get("source") or b.get("notes"):
            self.runs(sp, " ".join(x for x in [f"Source: {b['source']}" if b.get("source") else "",
                                                  b.get("notes", "")] if x),
                      size=self.f.doc_caption - 0.5, color=self.c.muted, italic=True)
            sp.paragraph_format.space_after = Pt(10)
        self._has_body = True

    def _avail_w(self, ct) -> float:
        if hasattr(ct, "width") and ct.width:
            return ct.width / 914400 - 0.15
        return self.content_w

    def _figure(self, path: Path, ct, caption, width_in=None, source=None):
        avail = self._avail_w(ct)
        w = min(float(width_in or avail), avail)
        p = ct.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_after = Pt(2)
        keep_with_next(p)
        p.add_run().add_picture(str(path), width=Inches(w))
        if caption:
            self.fig_n += 1
            cp = self._caption(ct, "Figure", self.fig_n, caption, source)
            cp.alignment = WD_ALIGN_PARAGRAPH.CENTER
        self._has_body = True

    def _chart(self, b, ct):
        avail = self._avail_w(ct)
        spec = dict(b)
        spec.setdefault("width_in", min(float(b.get("width_in", avail)), avail))
        out = self.work / f"chart_{id(b)}.png"
        render_chart(spec, self.theme, out)
        self._figure(out, ct, b.get("caption") or b.get("title"), spec["width_in"], b.get("source"))

    def _image(self, b, ct):
        p = Path(b["path"])
        if not p.is_absolute():
            p = self.base / p
        if not p.exists():
            self.warnings.append(f"Image not found: {p}")
            self._callout({"kind": "warning", "title": "Missing image", "text": str(b['path'])}, ct)
            return
        self._figure(p, ct, b.get("caption"), b.get("width_in"), b.get("source"))

    _KIND = {"note": ("accent", "Note"), "key": ("primary", "Key point"), "warning": ("warning", "Caution"),
             "success": ("success", "Result"), "danger": ("danger", "Warning")}

    def _callout(self, b, ct):
        color_key, default_title = self._KIND.get(b.get("kind", "note"), ("accent", "Note"))
        col = getattr(self.c, color_key)
        t = ct.add_table(rows=1, cols=1)
        no_borders(t)
        set_col_widths(t, [self._avail_w(ct)])
        cant_split(t.rows[0])
        cell = t.cell(0, 0)
        shade_cell(cell, tint(col, 0.9))
        cell_borders(cell, left=(36, col))
        cell_margins(cell, top=120, bottom=120, left=200, right=200)
        p = cell.paragraphs[0]
        p.paragraph_format.space_after = Pt(2)
        title = b.get("title", default_title)
        if title:
            self.runs(p, title, size=self.f.doc_body, color=col if color_key != "warning" else self.c.text, bold=True)
            p = cell.add_paragraph()
        p.paragraph_format.space_after = Pt(0)
        texts = b.get("text", "")
        if isinstance(texts, list):
            for k, tx in enumerate(texts):
                if k:
                    p = cell.add_paragraph(); p.paragraph_format.space_after = Pt(0)
                self.runs(p, "•  " + tx)
        else:
            self.runs(p, texts)
        ct.add_paragraph().paragraph_format.space_after = Pt(2)
        self._has_body = True

    def _quote(self, b, ct):
        p = ct.add_paragraph(style="Quote")
        p.paragraph_format.left_indent = Inches(0.4)
        p.paragraph_format.right_indent = Inches(0.4)
        para_border(p._p.get_or_add_pPr(), "left", self.c.accent, size=24, space=10)
        self.runs(p, f"“{b['text']}”")
        if b.get("attribution"):
            a = ct.add_paragraph()
            a.paragraph_format.left_indent = Inches(0.4)
            self.runs(a, f"— {b['attribution']}", size=self.f.doc_body - 1, color=self.c.muted)

    def _code(self, b, ct):
        t = ct.add_table(rows=1, cols=1)
        no_borders(t)
        set_col_widths(t, [self._avail_w(ct)])
        cant_split(t.rows[0])
        cell = t.cell(0, 0)
        shade_cell(cell, self.c.surface)
        cell_borders(cell, left=(12, self.c.rule))
        cell_margins(cell, top=100, bottom=100, left=160, right=160)
        p = cell.paragraphs[0]
        p.paragraph_format.space_after = Pt(0)
        p.paragraph_format.line_spacing = 1.0
        lines = str(b.get("text", "")).rstrip("\n").split("\n")
        for k, ln in enumerate(lines):
            if k:
                p.add_run().add_break()
            r = p.add_run(ln)
            r.font.name = self.f.mono
            r.font.size = Pt(8.5)
            rPr = r._r.get_or_add_rPr()
            rf = rPr.find(qn("w:rFonts"))
            rf.set(qn("w:hAnsi"), self.f.mono); rf.set(qn("w:cs"), self.f.mono)
        cap = ct.add_paragraph(style="Caption") if b.get("caption") else ct.add_paragraph()
        if b.get("caption"):
            self.runs(cap, b["caption"])
        cap.paragraph_format.space_after = Pt(6)

    def _kpis(self, b, ct):
        items = b.get("items") or []
        if not items:
            return
        n = len(items)
        t = ct.add_table(rows=1, cols=n)
        no_borders(t)
        avail = self._avail_w(ct)
        set_col_widths(t, [avail / n] * n)
        for j, k in enumerate(items):
            cell = t.cell(0, j)
            shade_cell(cell, self.c.surface)
            cell_borders(cell, top=(24, self.c.primary), left=(12, self.c.white) if j else None,
                         right=(12, self.c.white) if j < n - 1 else None)
            cell_margins(cell, top=120, bottom=120, left=160, right=120)
            p = cell.paragraphs[0]; p.paragraph_format.space_after = Pt(0)
            self.runs(p, str(k.get("label", "")).upper(), size=7.5, color=self.c.muted, bold=True)
            p = cell.add_paragraph(); p.paragraph_format.space_after = Pt(0); p.paragraph_format.line_spacing = 1.0
            self.runs(p, str(k.get("value", "")), size=20, color=self.c.primary, bold=True, font=self.f.heading)
            if k.get("delta") is not None or k.get("note"):
                p = cell.add_paragraph(); p.paragraph_format.space_after = Pt(0)
                if k.get("delta") is not None:
                    d = str(k["delta"])
                    good = k.get("good")
                    if good is None:
                        good = not d.strip().startswith(("-", "−", "▼"))
                    arrow = "▲ " if not d.strip().startswith(("-", "−")) else "▼ "
                    self.runs(p, arrow + d.lstrip("+"), size=8.5, color=self.c.success if good else self.c.danger, bold=True)
                    if k.get("note"):
                        p.add_run("  ")
                if k.get("note"):
                    self.runs(p, k["note"], size=8, color=self.c.muted)
        ct.add_paragraph().paragraph_format.space_after = Pt(4)
        self._has_body = True

    def _definitions(self, b, ct):
        items = b.get("items") or []
        if isinstance(items, dict):
            items = [{"term": k, "definition": v} for k, v in items.items()]
        rows = [[i.get("term", ""), i.get("definition", "")] for i in items]
        avail = self._avail_w(ct)
        self._table({"columns": b.get("columns", ["Term", "Definition"]), "rows": rows,
                     "widths": [1.7, avail - 1.7], "first_col_bold": True,
                     "caption": b.get("caption"), "number": bool(b.get("caption"))}, ct)

    def _signoff(self, b, ct):
        items = b.get("items") or []
        avail = self._avail_w(ct)
        rows = [[i.get("role", ""), i.get("name", ""), "", i.get("date", "")] for i in items]
        t = ct.add_table(rows=1 + len(rows), cols=4)
        table_borders(t, self.c.rule, 4, inside_v=True)
        set_col_widths(t, [avail * 0.26, avail * 0.26, avail * 0.30, avail * 0.18])
        for j, h in enumerate(["Role", "Name", "Signature", "Date"]):
            c = t.cell(0, j); shade_cell(c, self.c.primary); cell_margins(c)
            c.paragraphs[0].paragraph_format.space_after = Pt(0)
            self.runs(c.paragraphs[0], h, size=9, color=self.c.white, bold=True)
        for i, r in enumerate(rows):
            t.rows[i + 1].height = Inches(0.45)
            for j, v in enumerate(r):
                c = t.cell(i + 1, j); cell_margins(c)
                c.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
                c.paragraphs[0].paragraph_format.space_after = Pt(0)
                self.runs(c.paragraphs[0], v, size=9.5)
        ct.add_paragraph()

    def _two_column(self, b, ct):
        t = ct.add_table(rows=1, cols=2)
        no_borders(t)
        avail = self._avail_w(ct)
        ratio = float(b.get("ratio", 0.5))
        gap = 0.25
        set_col_widths(t, [(avail - gap) * ratio + gap / 2, (avail - gap) * (1 - ratio) + gap / 2])
        for j, side in enumerate(("left", "right")):
            cell = t.cell(0, j)
            cell_margins(cell, top=0, bottom=0, left=0 if j == 0 else 180, right=180 if j == 0 else 0)
            first = cell.paragraphs[0]
            self.render_blocks(b[side], cell)
            if len(cell.paragraphs) > 1 and not first.text and not first.runs:
                first._p.getparent().remove(first._p)
        ct.add_paragraph().paragraph_format.space_after = Pt(2)

    def _pagebreak(self, b, ct):
        ct.add_paragraph().add_run().add_break(WD_BREAK.PAGE)

    def _spacer(self, b, ct):
        ct.add_paragraph().paragraph_format.space_after = Pt(float(b.get("pt", 12)))

    def _toc(self, b, ct):
        pass  # handled up-front (position fixed after cover); kept for spec compatibility

    def _trim_tail(self):
        """Remove trailing empty paragraphs; shrink a required final one so it
        can never push a blank page."""
        body = self.doc.element.body
        while True:
            kids = [k for k in body if k.tag != qn("w:sectPr")]
            last = kids[-1] if kids else None
            if last is None or last.tag != qn("w:p") or "".join(last.itertext()).strip() \
                    or last.findall(".//" + qn("w:drawing")) or last.findall(".//" + qn("w:br")):
                break
            prev = kids[-2] if len(kids) > 1 else None
            if prev is not None and prev.tag == qn("w:tbl"):
                from docx.text.paragraph import Paragraph
                para = Paragraph(last, self.doc._body)
                para.paragraph_format.space_before = Pt(0)
                para.paragraph_format.space_after = Pt(0)
                para.paragraph_format.line_spacing = Pt(1)
                break
            body.remove(last)

    # --- main ----------------------------------------------------------------
    def build(self, out_path: Path, update_fields_on_open: bool = True) -> Path:
        self._has_body = False
        self.setup()
        self.header_footer()
        if self.docspec.get("cover", True):
            self.cover()
        else:
            self.doc.sections[0].different_first_page_header_footer = False
            # remove the empty initial paragraph
        front = False
        if self.meta.get("revisions"):
            self.revision_history(); front = True
        if self.meta.get("approvals"):
            self.approvals(); front = True
        if front:
            self.doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)
        if self.docspec.get("toc", True):
            self.toc()
        self.render_blocks(self.docspec["blocks"], self.doc)
        self._trim_tail()
        if update_fields_on_open:
            insert_update_fields(self.doc.settings.element)
        fix_order(self.doc.element)
        fix_order(self.doc.styles.element)
        for sec in self.doc.sections:
            for hf in (sec.header, sec.footer, sec.first_page_header, sec.first_page_footer):
                fix_order(hf._element)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        self.doc.save(str(out_path))
        return out_path


def build_docx(spec, theme, out_path: Path, workdir: Optional[Path] = None, update_fields_on_open=True):
    b = DocxBuilder(spec, theme, workdir)
    path = b.build(Path(out_path), update_fields_on_open)
    return path, b.warnings
