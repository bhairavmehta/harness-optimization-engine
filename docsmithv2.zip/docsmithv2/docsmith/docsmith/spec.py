"""Load and normalise docsmith specs (YAML, JSON or Markdown).

A spec has up to three top-level sections:

    meta:      title, subtitle, author, date, doc_number, revision, marking ...
    document:  {toc: true, blocks: [...]}         -> DOCX (+ PDF)
    slides:    [...]                              -> PPTX (+ PDF)

Blocks may be written in shorthand (``- h1: Introduction``) or long form
(``- type: heading, level: 1, text: Introduction``).  Everything is
normalised to the long form here so the builders only see one shape.
"""
from __future__ import annotations

import datetime as _dt
import json
from pathlib import Path
from typing import Any, Dict, List

import yaml

from . import markdown as md


class SpecError(ValueError):
    pass


BLOCK_TYPES = {
    "heading", "paragraph", "bullets", "numbered", "table", "chart", "image",
    "callout", "quote", "code", "kpis", "pagebreak", "toc", "spacer",
    "definitions", "signoff", "two_column",
}

SLIDE_LAYOUTS = {
    "title", "agenda", "section", "bullets", "two_column", "table", "chart",
    "image", "kpis", "quote", "timeline", "closing", "comparison", "text",
}

_SHORTHAND = {
    "h1": ("heading", {"level": 1}), "h2": ("heading", {"level": 2}),
    "h3": ("heading", {"level": 3}), "h4": ("heading", {"level": 4}),
    "p": ("paragraph", {}), "text": ("paragraph", {}), "paragraph": ("paragraph", {}),
    "bullets": ("bullets", {}), "ul": ("bullets", {}),
    "numbered": ("numbered", {}), "ol": ("numbered", {}),
    "quote": ("quote", {}), "code": ("code", {}),
    "note": ("callout", {"kind": "note"}), "info": ("callout", {"kind": "note"}),
    "warning": ("callout", {"kind": "warning"}), "caution": ("callout", {"kind": "warning"}),
    "key": ("callout", {"kind": "key"}), "success": ("callout", {"kind": "success"}),
    "danger": ("callout", {"kind": "danger"}),
}


def _norm_block(b: Any, where: str) -> Dict[str, Any]:
    if isinstance(b, str):
        if b.strip().lower() in ("pagebreak", "page_break", "---"):
            return {"type": "pagebreak"}
        if b.strip().lower() == "toc":
            return {"type": "toc"}
        return {"type": "paragraph", "text": b}
    if not isinstance(b, dict):
        raise SpecError(f"{where}: block must be a mapping or string, got {type(b).__name__}")
    if "type" in b:
        t = b["type"]
        if t not in BLOCK_TYPES:
            raise SpecError(f"{where}: unknown block type '{t}'. Valid: {sorted(BLOCK_TYPES)}")
        out = dict(b)
    else:
        keys = [k for k in b if k in _SHORTHAND or k in BLOCK_TYPES]
        if not keys:
            raise SpecError(f"{where}: can't tell block type from keys {list(b)}")
        k = keys[0]
        val = b[k]
        if k in _SHORTHAND:
            t, extra = _SHORTHAND[k]
        else:
            t, extra = k, {}
        out = {"type": t, **extra, **{kk: vv for kk, vv in b.items() if kk != k}}
        if isinstance(val, dict):
            out.update(val)
        elif t in ("bullets", "numbered"):
            out["items"] = val
        elif t == "callout" and isinstance(val, str):
            out["text"] = val
        elif t in ("pagebreak", "toc", "spacer"):
            pass
        elif t == "kpis":
            out["items"] = val
        elif t in ("definitions", "signoff"):
            out["items"] = val
        else:
            out["text"] = val
    t = out["type"]
    if t == "two_column":
        out["left"] = [_norm_block(x, f"{where}.left[{i}]") for i, x in enumerate(out.get("left", []))]
        out["right"] = [_norm_block(x, f"{where}.right[{i}]") for i, x in enumerate(out.get("right", []))]
    if t == "table":
        if "rows" not in out:
            raise SpecError(f"{where}: table needs 'rows'")
        if out.get("columns") is None and out["rows"]:
            out["columns"] = out["rows"][0]
            out["rows"] = out["rows"][1:]
    if t == "chart":
        _check_chart(out, where)
    if t == "image" and "path" not in out and "text" in out:
        out["path"] = out.pop("text")
    return out


def _check_chart(c: Dict[str, Any], where: str) -> None:
    if "categories" not in c or "series" not in c:
        raise SpecError(f"{where}: chart needs 'categories' and 'series'")
    series = c["series"]
    if isinstance(series, dict):
        c["series"] = [{"name": k, "values": v} for k, v in series.items()]
    for s in c["series"]:
        if len(s["values"]) != len(c["categories"]):
            raise SpecError(
                f"{where}: series '{s['name']}' has {len(s['values'])} values "
                f"but there are {len(c['categories'])} categories")
    c.setdefault("kind", c.pop("chart_type", "bar"))


def _norm_slide(s: Any, i: int) -> Dict[str, Any]:
    where = f"slides[{i}]"
    if not isinstance(s, dict):
        raise SpecError(f"{where}: slide must be a mapping")
    s = dict(s)
    layout = s.get("layout")
    if not layout:
        # infer a sensible layout
        if "kpis" in s: layout = "kpis"
        elif "chart" in s: layout = "chart"
        elif "table" in s: layout = "table"
        elif "image" in s: layout = "image"
        elif "left" in s and "right" in s: layout = "two_column"
        elif "milestones" in s: layout = "timeline"
        elif "quote" in s: layout = "quote"
        elif i == 0: layout = "title"
        else: layout = "bullets"
        s["layout"] = layout
    if layout not in SLIDE_LAYOUTS:
        raise SpecError(f"{where}: unknown layout '{layout}'. Valid: {sorted(SLIDE_LAYOUTS)}")
    if layout == "chart":
        ch = s.get("chart")
        if not isinstance(ch, dict):
            raise SpecError(f"{where}: chart layout needs a 'chart' mapping")
        _check_chart(ch, where + ".chart")
    if layout == "table":
        tb = s.get("table")
        if not isinstance(tb, dict) or "rows" not in tb:
            raise SpecError(f"{where}: table layout needs 'table: {{columns, rows}}'")
        if tb.get("columns") is None:
            tb["columns"], tb["rows"] = tb["rows"][0], tb["rows"][1:]
    return s


def normalise(spec: Dict[str, Any], base_dir: Path) -> Dict[str, Any]:
    spec = dict(spec or {})
    meta = dict(spec.get("meta") or {})
    meta.setdefault("title", "Untitled")
    d = meta.get("date")
    if d is None:
        meta["date"] = _dt.date.today().strftime("%B %d, %Y").replace(" 0", " ")
    elif isinstance(d, (_dt.date, _dt.datetime)):
        meta["date"] = d.strftime("%B %d, %Y").replace(" 0", " ")
    spec["meta"] = meta
    spec["_base_dir"] = str(base_dir)

    doc = spec.get("document")
    if doc is not None:
        if isinstance(doc, list):
            doc = {"blocks": doc}
        doc = dict(doc)
        doc["blocks"] = [_norm_block(b, f"document.blocks[{i}]") for i, b in enumerate(doc.get("blocks") or [])]
        doc.setdefault("toc", True)
        doc.setdefault("cover", True)
        spec["document"] = doc

    slides = spec.get("slides")
    if slides is not None:
        if isinstance(slides, dict):  # {options..., slides: [...]}
            opts = {k: v for k, v in slides.items() if k != "items"}
            items = slides.get("items") or []
        else:
            opts, items = {}, slides
        spec["slides"] = [_norm_slide(s, i) for i, s in enumerate(items)]
        spec["slide_options"] = opts

    if spec.get("document") is None and spec.get("slides") is None:
        raise SpecError("Spec has neither 'document' nor 'slides'")
    return spec


def load_spec(path: str | Path, mode: str = "auto") -> Dict[str, Any]:
    """Load a spec file.  ``mode`` matters only for Markdown:
    'document', 'slides', 'both' or 'auto' (uses front-matter ``mode``)."""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(p)
    txt = p.read_text(encoding="utf-8")
    suffix = p.suffix.lower()
    if suffix in (".yaml", ".yml"):
        raw = yaml.safe_load(txt)
    elif suffix == ".json":
        raw = json.loads(txt)
    elif suffix in (".md", ".markdown"):
        raw = md.markdown_to_spec(txt, mode=mode)
    else:
        raise SpecError(f"Unsupported spec type '{suffix}' (use .yaml, .json or .md)")
    return normalise(raw, p.parent.resolve())
