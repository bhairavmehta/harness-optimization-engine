"""Theme definitions for docsmith.

The built-in ``boeing`` theme uses an approximation of Boeing corporate
colors.  If your brand team gives you exact values, override them in a
theme YAML file (see ``themes/boeing.yaml``) instead of editing code:

    docsmith build spec.yaml --theme my_theme.yaml
"""
from __future__ import annotations

import copy
from dataclasses import dataclass, field, fields, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml


def hex_to_rgb(h: str) -> tuple:
    h = h.lstrip("#")
    if len(h) != 6:
        raise ValueError(f"Bad hex color: {h!r}")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def tint(h: str, amount: float) -> str:
    """Blend a hex color toward white (amount 0..1)."""
    r, g, b = hex_to_rgb(h)
    r = int(r + (255 - r) * amount)
    g = int(g + (255 - g) * amount)
    b = int(b + (255 - b) * amount)
    return f"{r:02X}{g:02X}{b:02X}"


@dataclass
class Colors:
    primary: str = "0033A1"       # Boeing Blue (approximation)
    primary_dark: str = "001E62"  # deep navy for title bands
    accent: str = "1D8FE1"        # sky blue accent
    accent_light: str = "9CC8F0"
    text: str = "1F2833"          # body text
    muted: str = "5F6B7A"         # captions, footers
    rule: str = "C9D1DC"          # hairlines / table borders
    surface: str = "F2F5F9"       # zebra rows, callout fills
    white: str = "FFFFFF"
    success: str = "2E8540"
    warning: str = "E8A317"
    danger: str = "C8102E"
    # Categorical chart palette, blue-led, in fixed order.  Validated for
    # lightness band, chroma, colour-vision-deficiency separation and
    # normal-vision separation on white.  Amber/sky sit below 3:1 contrast,
    # so charts always ship with a legend (and optional value labels).
    chart: List[str] = field(default_factory=lambda: [
        "2D6CDF", "D98E04", "14A08A", "8E5BD6", "D9534F", "4FA3E8",
    ])


@dataclass
class Fonts:
    heading: str = "Arial"        # LibreOffice substitutes Liberation Sans (metric-compatible)
    body: str = "Arial"
    mono: str = "Courier New"
    # document sizes (pt)
    doc_body: float = 10.5
    doc_h1: float = 18
    doc_h2: float = 14
    doc_h3: float = 12
    doc_caption: float = 9
    doc_title: float = 30
    # slide sizes (pt)
    slide_title: float = 28
    slide_body: float = 18
    slide_cover_title: float = 40


@dataclass
class Theme:
    name: str = "boeing"
    org: str = "The Boeing Company"
    colors: Colors = field(default_factory=Colors)
    fonts: Fonts = field(default_factory=Fonts)
    logo: Optional[str] = None            # path to PNG/SVG-rasterized logo you are licensed to use
    logo_dark: Optional[str] = None       # variant for dark (blue) backgrounds
    marking: str = "BOEING PROPRIETARY"   # default classification banner
    marking_notice: str = (
        "Copyright © {year} Boeing. Unpublished Work. All rights reserved."
    )
    page_size: str = "letter"             # letter | a4
    numbered_headings: bool = True

    # ------------------------------------------------------------------
    def merged(self, overrides: Dict[str, Any]) -> "Theme":
        """Return a copy with nested dict overrides applied."""
        t = copy.deepcopy(self)
        for key, val in (overrides or {}).items():
            if key == "colors" and isinstance(val, dict):
                for k, v in val.items():
                    if not hasattr(t.colors, k):
                        raise ValueError(f"Unknown theme color '{k}'")
                    setattr(t.colors, k, [str(x).lstrip("#") for x in v] if isinstance(v, list) else str(v).lstrip("#"))
            elif key == "fonts" and isinstance(val, dict):
                for k, v in val.items():
                    if not hasattr(t.fonts, k):
                        raise ValueError(f"Unknown theme font setting '{k}'")
                    setattr(t.fonts, k, v)
            elif hasattr(t, key):
                setattr(t, key, val)
            else:
                raise ValueError(f"Unknown theme key '{key}'")
        return t

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


BUILTIN = {
    "boeing": Theme(),
}


LOGO_NAMES = {
    "logo": ["boeing-logo.png", "logo.png", "boeing-logo.svg", "logo.svg"],
    "logo_dark": ["boeing-logo-white.png", "logo-white.png", "logo_dark.png",
                  "boeing-logo-white.svg", "logo-white.svg"],
}
PACKAGE_ASSETS = Path(__file__).with_name("assets")


def rasterize(path: str, workdir: Optional[Path] = None) -> str:
    """python-docx / python-pptx need raster images: convert SVG to PNG."""
    p = Path(path)
    if p.suffix.lower() != ".svg":
        return str(p)
    import tempfile
    out_dir = Path(workdir or tempfile.mkdtemp(prefix="docsmith_logo_"))
    out = out_dir / (p.stem + ".png")
    try:
        import cairosvg  # type: ignore
        cairosvg.svg2png(url=str(p), write_to=str(out), output_height=600)
        return str(out)
    except ImportError:
        from .lo import lo_convert
        return str(lo_convert(p, out_dir, "png"))


def apply_logos(theme: "Theme", search_dirs: List[Path], logo: Optional[str] = None,
                logo_dark: Optional[str] = None) -> "Theme":
    """Fill theme.logo / logo_dark from (in priority order): explicit args,
    env DOCSMITH_LOGO / DOCSMITH_LOGO_DARK, the theme file, then well-known
    file names in search_dirs (e.g. <spec dir>/assets, ./assets, package assets)."""
    import os
    explicit = {"logo": logo or os.environ.get("DOCSMITH_LOGO"),
                "logo_dark": logo_dark or os.environ.get("DOCSMITH_LOGO_DARK")}
    for attr, names in LOGO_NAMES.items():
        val = explicit[attr] or getattr(theme, attr)
        if val and not Path(val).exists():
            raise FileNotFoundError(f"{attr} file not found: {val}")
        if not val:
            for d in search_dirs:
                hit = next((d / n for n in names if (d / n).exists()), None)
                if hit:
                    val = str(hit)
                    break
        if val:
            setattr(theme, attr, rasterize(val))
    return theme


def load_theme(name_or_path: Optional[str] = None, overrides: Optional[Dict[str, Any]] = None) -> Theme:
    base = BUILTIN["boeing"]
    if name_or_path:
        if name_or_path in BUILTIN:
            base = BUILTIN[name_or_path]
        else:
            p = Path(name_or_path)
            if not p.exists():
                raise FileNotFoundError(f"Theme not found: {name_or_path}")
            data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
            parent = data.pop("extends", "boeing")
            base = BUILTIN.get(parent, BUILTIN["boeing"]).merged(data)
            # resolve logo paths relative to the theme file
            for attr in ("logo", "logo_dark"):
                val = getattr(base, attr)
                if val and not Path(val).is_absolute():
                    setattr(base, attr, str((p.parent / val).resolve()))
    if overrides:
        base = base.merged(overrides)
    return base
