# docsmith

docsmith turns one spec file into Boeing-themed Word documents, PowerPoint decks and PDFs. The spec can be YAML, JSON or Markdown. It builds the DOCX and PPTX files directly in Python, then uses headless LibreOffice to refresh the table of contents and fields and export the PDFs.

```
spec.yaml / spec.md ──► DocxBuilder ──► report.docx ─┐
                    └─► PptxBuilder ──► deck.pptx  ──┴─► LibreOffice (UNO) ──► report.pdf, deck.pdf
                                                         TOC + fields refresh, tagged PDF, PDF/A-2b option
```

## Install

```bash
pip install -e .                 # python-docx, python-pptx, matplotlib, PyYAML, Pillow, lxml
# plus LibreOffice 7.4+  (Linux: apt install libreoffice python3-uno; Windows/macOS: libreoffice.org)
docsmith doctor                  # checks soffice, UNO python, fonts, libs
```

Without LibreOffice you can still produce DOCX and PPTX. On Windows, `--engine msoffice` uses Word and PowerPoint through COM to make the PDFs (`pip install pywin32`). `--engine auto` falls back to it when LibreOffice isn't found.

## Use

```bash
docsmith new report -o report.yaml        # starter specs: report | deck | markdown
docsmith build report.yaml -o out         # -> out/<title>.docx + .pdf
docsmith build deck.yaml -o out           # -> out/<title>.pptx + .pdf
docsmith build notes.md --mode both       # Markdown -> document AND slides
docsmith build spec.yaml -f pdf --pdfa --preview --json   # PDF/A, PNG previews, JSON manifest
docsmith convert anything.docx --to pdf   # straight LibreOffice conversion
docsmith theme > my_theme.yaml            # dump the effective theme
```

Each build writes `<name>.manifest.json` listing the output paths, the engine used and any warnings, which makes it easy to orchestrate from Kiro or CI. Python API: `from docsmith import build; build("spec.yaml", "out", formats=["pdf"])`.

## Spec

```yaml
meta:      {title, subtitle, short_title, doc_type, doc_number, revision, date, author,
            org, division, audience, status, marking, marking_notice, cover_notices,
            revisions: [{rev, date, description, author}], extra_fields: {k: v}}
outputs:   [docx, pptx, pdf]
theme:     themes/boeing.yaml          # or inline overrides {colors: {...}}
document:  {toc: true, toc_depth: 3, cover: true, numbered_headings: true,
            h1_new_page: false, landscape: false, blocks: [...]}
slides:    [...]
```

**Document blocks**: `h1`–`h4` (`unnumbered: true`), `p` (`style: lead|small`), `bullets` / `numbered` (nest by following an item with a list), `table` (`caption, widths, align, total_row, first_col_bold, highlight_cells {"row,col": good|warn|bad}, source, notes`), `chart` (`kind: bar|barh|stacked|stacked_barh|line|area|donut`, `categories`, `series`, `reference`, `number_format`, `caption`), `image` (`path, width_in, caption`), `note` / `key` / `warning` / `success` / `danger` callouts, `quote`, `code`, `kpis` (`label, value, delta, note, good`), `definitions`, `signoff`, `two_column` (`left`/`right` block lists, `ratio`), `pagebreak`, `spacer`.

Inline markup: `**bold**`, `*italic*`, `` `code` ``, `[link](url)`, `==highlight==`, `^^sup^^`, `~~sub~~`.

**Slide layouts**: `title`, `agenda`, `section`, `bullets` (+ `callout` side panel or `image`), `text`, `two_column`, `comparison` (option cards with `status` and `highlight`), `table`, `chart` (native, editable; + `insights`), `image`, `kpis` (+ `bullets`), `quote`, `timeline` (`milestones` with `status: done|current|risk|late`), `closing`. Every content slide also accepts `kicker`, `subtitle`, `takeaway` (a key-message banner), `source` and `notes` (speaker notes). If you leave out `layout`, docsmith infers it from the keys.

**Markdown**: YAML front matter for `meta`; `#`/`##` headings, lists, pipe tables (with a `Table: caption` line), `> [!NOTE]` / `[!WARNING]` callouts, `![caption](img.png){width=5}`, and fenced `chart`, `kpis` or `table` blocks containing YAML. In slides mode, put a `---` line between slides; the first `#` is the title, and `<!-- layout: section -->` or `Notes:` set per-slide options. A fenced ```` ```slide ```` YAML block applies to that slide only (layout, columns, milestones, takeaway, and so on), and a fenced ```` ```doc ```` YAML block goes into the document only. `docsmith new markdown` writes the full template.

## Theme

The built-in `boeing` theme uses Boeing Blue `#0033A1` and navy `#001E62` with a sky accent, Arial (LibreOffice substitutes the metric-compatible Liberation Sans), and a **BOEING PROPRIETARY** marking on every page and slide. The chart palette was validated for colour-blind separation. Brand values are approximations: put the exact values from your brand portal, and any logo you're licensed to use, in `themes/boeing.yaml`. No logo ships with docsmith.

## Logo

The Boeing logo is not bundled; use the official files from Boeing's brand portal. Drop them into an
`assets/` folder next to your spec (or `./assets`, or `docsmith/assets/`):

| File | Used on |
|---|---|
| `boeing-logo.png` | document cover + running header, slide footers (and on a white badge on the title slide if no white version) |
| `boeing-logo-white.png` | blue title and closing slides |

SVG works too. Or pass them per build: `docsmith build deck.yaml --logo path/logo.png --logo-dark path/logo-white.png`,
set `DOCSMITH_LOGO` / `DOCSMITH_LOGO_DARK`, or set `logo:` / `logo_dark:` in a theme file. Sizes are tunable in the spec:
`document: {cover_logo_in: 0.6, header_logo_in: 0.22, header_logo: true}`.

## How the PDF step stays robust

- Each LibreOffice run gets its own throw-away profile, so parallel builds and an open LibreOffice window never collide.
- Timeouts kill the whole process tree, and conversions are retried once.
- The UNO worker updates indexes twice (the TOC can move page numbers), refreshes fields, and exports a tagged PDF with bookmarks.
- If UNO isn't available, docsmith falls back to `soffice --convert-to` and adds a warning to the manifest.
- DOCX files carry `updateFields`, so Word fills in the TOC page numbers when the file is opened, and property elements are written in schema order so Word opens them cleanly.

## Tests

`python -m pytest -q tests`. The PDF tests are skipped when LibreOffice isn't installed.
