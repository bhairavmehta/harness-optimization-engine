"""Smoke tests: python -m pytest -q tests  (PDF tests skip without LibreOffice)."""
from pathlib import Path

import pytest

from docsmith import build
from docsmith.lo import find_soffice
from docsmith.markdown import markdown_to_spec
from docsmith.richtext import parse_inline
from docsmith.spec import SpecError, normalise

T = Path(__file__).resolve().parents[1] / "docsmith" / "templates"
HAS_LO = find_soffice() is not None


def test_inline():
    runs = parse_inline("a **b** *c* `d` [e](https://x.y)")
    assert [r.text for r in runs] == ["a ", "b", " ", "c", " ", "d", " ", "e"]
    assert runs[1].bold and runs[3].italic and runs[5].code and runs[7].link == "https://x.y"


def test_snake_case_is_not_italic():
    assert [r.text for r in parse_inline("use model_id here")] == ["use model_id here"]


def test_markdown_nested_list():
    spec = markdown_to_spec("- a\n  - a1\n  - a2\n- b\n")
    assert spec["document"]["blocks"][0]["items"] == ["a", ["a1", "a2"], "b"]


def test_bad_chart_rejected():
    with pytest.raises(SpecError):
        normalise({"document": [{"chart": {"categories": [1, 2], "series": {"x": [1]}}}]}, Path("."))


@pytest.mark.parametrize("name", ["report.yaml", "deck.yaml", "notes.md"])
def test_build_office(tmp_path, name):
    m = build(T / name, tmp_path, formats=["docx", "pptx"], log=lambda *_: None)
    assert m["outputs"] and all(Path(o["path"]).stat().st_size > 5000 for o in m["outputs"])


@pytest.mark.skipif(not HAS_LO, reason="LibreOffice not installed")
@pytest.mark.parametrize("name", ["report.yaml", "deck.yaml"])
def test_build_pdf(tmp_path, name):
    m = build(T / name, tmp_path, formats=["pdf"], log=lambda *_: None)
    pdfs = [o for o in m["outputs"] if o["format"] == "pdf"]
    assert pdfs and Path(pdfs[0]["path"]).read_bytes()[:4] == b"%PDF"
