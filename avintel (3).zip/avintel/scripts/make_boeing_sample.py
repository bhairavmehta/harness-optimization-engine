"""FICTIONAL Boeing 737 / 777 / 787 test events in NTSB-CSV, AvHerald-HTML and ASN-HTML form.

Every operator, registration, flight number and event below is invented to exercise the
feature pipeline. Nothing here describes a real occurrence. Replace with real NTSB data
(avall.mdb export or report PDFs) for analysis.

python scripts/make_boeing_sample.py boeing_sample
"""
import sys
from pathlib import Path

import pandas as pd

root = Path(sys.argv[1] if len(sys.argv) > 1 else "boeing_sample")
for d in ("ntsb_csv", "avh_html", "asn_html"):
    (root / d).mkdir(parents=True, exist_ok=True)

E = [  # (id, date, city, state, model, reg, damage, injury, wx, light, narrative, cause, [(occurrence, defining)], avh, asn)
 ("2016041201", "2016-04-12", "Denver", "CO", "737-800", "N734QZ", "SUBS", "NONE", "VMC", "DAYL",
  "The Summit Air Boeing 737-800, flight SU-221, was climbing through 2,300 feet after takeoff from runway 34L at KDEN when it struck a flock of geese. The crew reported a loud bang and vibration from the left engine. The first officer was the pilot flying. The crew declared an emergency, shut down the left engine and returned to Denver, landing about 18 minutes after departure. There were 162 passengers and 6 crew aboard. Examination found fan blade damage and bird remains in the engine. METAR KDEN 121653Z 33009KT 10SM FEW080 14/M03.",
  "The airplane's encounter with a flock of geese during initial climb, which resulted in damage to the left engine.",
  [("Initial climb-Birdstrike", 1), ("Initial climb-Loss of engine power (partial)", 0)],
  ("Incident: Summit B738 at Denver on Apr 12th 2016, bird strike", "A Summit Air Boeing 737-800, registration N734QZ performing flight SU-221 from Denver, was climbing out of runway 34L when the aircraft struck a flock of geese. The crew stopped the climb, shut the left engine down and returned to Denver for a safe landing about 18 minutes after departure."), None),
 ("2019081502", "2019-08-15", "Phoenix", "AZ", "737 MAX 8", "N38MQZ", "SUBS", "NONE", "VMC", "DAYL",
  "During initial climb from runway 26 at KPHX, the Boeing 737 MAX 8 operated by Meridian Pacific as flight MP-80 struck several birds at about 1,100 feet above ground level. The crew received an engine vibration indication on the right engine, declared an emergency and returned for an overweight landing. Post-flight inspection found damage to the right engine fan and the radome. The captain had 14,200 hours total flight experience.",
  "A bird strike during initial climb that damaged the right engine fan.",
  [("Initial climb-Birdstrike", 1)], None, None),
 ("2017030303", "2017-03-03", "Anchorage", "AK", "777-300ER", "N773QZ", "SUBS", "NONE", "VMC", "DUSK",
  "The Boeing 777-300ER, operated by Northline as flight NL-9, was departing runway 7R at PANC. During rotation the airplane's tail contacted the runway. The crew had entered a takeoff weight that was 100,000 pounds lower than the actual weight, which resulted in rotation speeds that were too low. The crew did not perform the required cross-check of the takeoff performance data. The airplane continued to its destination; maintenance found abrasion damage to the aft fuselage skin and tail skid.",
  "The flight crew's entry of an incorrect takeoff weight and their failure to cross-check the takeoff performance data, which resulted in a tailstrike.",
  [("Takeoff-Tailstrike", 1)],
  ("Incident: Northline B77W at Anchorage on Mar 3rd 2017, tail strike on departure", "A Northline Boeing 777-300ER, registration N773QZ performing flight NL-9, suffered a tail strike while departing Anchorage's runway 7R. The aircraft continued to destination. The airline reported an incorrect takeoff weight had been entered."), None),
 ("2022112204", "2022-11-22", "Chicago", "IL", "737 MAX 9", "N39MQZ", "SUBS", "NONE", "IMC", "NITE",
  "During the landing flare on runway 10C at KORD the Boeing 737 MAX 9 bounced and touched down hard, resulting in a tail strike. Recorded vertical acceleration reached 2.3 G. The approach was unstabilized: the airplane was 12 knots above target speed at 500 feet with a sink rate of 1,200 feet per minute. The first officer, who had 310 hours in type, was the pilot flying. The crew did not call a go-around. METAR KORD 230151Z 28016G24KT 4SM -SN OVC009.",
  "The first officer's improper flare technique during an unstabilized approach and the crew's failure to go around.",
  [("Landing-flare/touchdown-Hard landing", 1), ("Landing-flare/touchdown-Tailstrike", 0)],
  ("Incident: Blue Ridge B39M at Chicago on Nov 22nd 2022, hard landing and tail strike", "A Blue Ridge Airlines Boeing 737 MAX 9, registration N39MQZ, bounced on landing at Chicago O'Hare's runway 10C in snow and touched down hard with a tail strike. No injuries were reported."), None),
 ("2018061405", "2018-06-14", "Honolulu", "HI", "787-8", "N788QZ", "NONE", "SERS", "VMC", "DAYL",
  "The Boeing 787-8, flight PC-301, encountered clear air turbulence in cruise at flight level 370 about 400 nautical miles northeast of Honolulu. The seat belt sign was off. A flight attendant who was standing in the aft galley was thrown to the floor and sustained a fractured ankle. The flight continued to PHNL where the injured flight attendant was taken to the hospital. There were 212 passengers aboard.",
  "The airplane's encounter with clear air turbulence in cruise flight.",
  [("Enroute-cruise-Turbulence encounter", 1)], None, None),
 ("2023020906", "2023-02-09", "Seattle", "WA", "777-200ER", "N772QZ", "NONE", "SERS", "IMC", "DAYL",
  "During descent through 18,000 feet toward KSEA the Boeing 777-200ER encountered moderate to severe turbulence in convective clouds. The captain had turned the seat belt sign on about two minutes earlier. Two flight attendants were injured, one seriously. Weather radar displayed returns ahead and the crew had requested a deviation, which air traffic control delayed because of traffic.",
  "The airplane's encounter with convective turbulence during descent.",
  [("Descent-Turbulence encounter", 1)],
  ("Incident: Cascadia B772 near Seattle on Feb 9th 2023, turbulence injures cabin crew", "A Cascadia Airways Boeing 777-200ER, registration N772QZ, encountered severe turbulence while descending towards Seattle. Two flight attendants were injured, one seriously, and were taken to hospital after landing."), None),
 ("2020071107", "2020-07-11", "Atlanta", "GA", "737-900", "N739QZ", "MINR", "NONE", "VMC", "DAYL",
  "While in cruise at flight level 350 the crew of the Boeing 737-900 received a low oil pressure indication for the left engine followed by an engine oil quantity decrease. The crew performed the checklist, shut down the left engine (in flight shutdown) and diverted to KATL, landing without further incident. Examination found a failed oil supply line fitting that had been improperly torqued during maintenance two days earlier.",
  "The loss of engine oil due to an oil supply fitting that was improperly torqued during maintenance.",
  [("Enroute-cruise-Loss of engine power (partial)", 1)], None, None),
 ("2024041808", "2024-04-18", "Houston", "TX", "787-9", "N789QZ", "MINR", "NONE", "VMC", "DAYL",
  "The Boeing 787-9 rejected the takeoff at about 120 knots on runway 15L at KIAH after a loud bang from the right engine. The crew stopped on the runway. Fire crews observed no fire. Examination found an uncontained failure of a high pressure turbine blade; fragments penetrated the engine cowl. The airplane was towed to the gate and the passengers deplaned.",
  "The fatigue failure of a high pressure turbine blade, resulting in an uncontained engine failure.",
  [("Takeoff-rejected takeoff-Uncontained engine failure", 1)],
  ("Incident: Meridian B789 at Houston on Apr 18th 2024, rejected takeoff due to engine failure", "A Meridian Pacific Boeing 787-9, registration N789QZ, rejected takeoff from Houston's runway 15L at high speed after the right hand engine failed with a bang. The aircraft stopped on the runway. Debris was found on the runway."),
  {"date": "Thursday 18 April 2024", "type": "Boeing 787-9 Dreamliner", "operator": "Meridian Pacific", "reg": "N789QZ", "yom": "2019",
   "fat": "Fatalities: 0 / Occupants: 268", "damage": "Minor", "cat": "Incident", "loc": "Houston-George Bush Intercontinental Airport (IAH/KIAH), TX",
   "phase": "Take off", "narr": "The aircraft rejected takeoff after an uncontained failure of the right engine."}),
 ("2021120909", "2021-12-09", "Portland", "OR", "737-800", "N738QZ", "SUBS", "NONE", "IMC", "NITE",
  "The Boeing 737-800 landed long on runway 28L at KPDX in heavy rain and overran the runway end, coming to rest in the safety area. The airplane touched down about 3,000 feet beyond the threshold with a 9 knot tailwind. The runway was wet. The crew did not go around despite the long landing. METAR KPDX 090456Z 10009KT 2SM +RA BR OVC006. There were no injuries; the passengers evacuated using the escape slides.",
  "The flight crew's decision to continue a landing with a long touchdown on a wet runway with a tailwind, which resulted in a runway overrun.",
  [("Landing-landing roll-Runway excursion", 1)],
  ("Accident: Summit B738 at Portland on Dec 9th 2021, overran runway on landing", "A Summit Air Boeing 737-800, registration N738QZ, overran the end of Portland's runway 28L in heavy rain at night and came to a stop in the runway end safety area. The passengers evacuated via slides."),
  {"date": "Thursday 9 December 2021", "type": "Boeing 737-800", "operator": "Summit Air", "reg": "N738QZ", "yom": "2009",
   "fat": "Fatalities: 0 / Occupants: 149", "damage": "Substantial", "cat": "Accident", "loc": "Portland International Airport (PDX/KPDX), OR",
   "phase": "Landing", "narr": "The aircraft overran runway 28L after a long landing in heavy rain."}),
 ("2025030110", "2025-03-01", "Minneapolis", "MN", "737 MAX 8", "N38NQZ", "SUBS", "NONE", "IMC", "DAYL",
  "After landing on runway 30L at KMSP the Boeing 737 MAX 8 veered off the left side of the runway during the landing roll. Braking action was reported poor and the runway was snow-covered. The airplane came to rest in the grass. The crosswind was 22 knots, gusting to 31 knots, beyond the operator's limit for a contaminated runway.",
  "The flight crew's decision to land with a crosswind that exceeded the operator's limit for a contaminated runway, which resulted in a loss of directional control.",
  [("Landing-landing roll-Runway excursion", 1), ("Landing-landing roll-Loss of control on ground", 0)], None, None),
 ("2019111511", "2019-11-15", "Newark", "NJ", "787-10", "N78XQZ", "NONE", "MINR", "VMC", "DAYL",
  "During descent into KEWR the crew of the Boeing 787-10 smelled smoke and flight attendants reported smoke in the forward cabin. The crew donned oxygen masks, declared an emergency and landed. Passengers evacuated on the taxiway; three received minor injuries on the escape slides. A lithium battery in a passenger's carry-on bag had entered thermal runaway.",
  "The thermal runaway of a lithium battery in a passenger's carry-on bag, which resulted in smoke in the cabin.",
  [("Descent-Fire/smoke (non-impact)", 1)],
  ("Incident: Pacifica B78X near Newark on Nov 15th 2019, smoke in cabin", "A Pacifica Boeing 787-10, registration N78XQZ, was descending towards Newark when smoke appeared in the forward cabin. The crew declared emergency, landed safely and initiated an evacuation. Three passengers received minor injuries."), None),
 ("2024092812", "2024-09-28", "Los Angeles", "CA", "777-200LR", "N77LQZ", "MINR", "NONE", "VMC", "DAYL",
  "In cruise at flight level 330, the crew of the Boeing 777-200LR noticed fumes and a burning smell in the flight deck. The crew diverted to KLAX. Maintenance found a failed recirculation fan motor that had overheated.",
  "An overheated recirculation fan motor, which produced fumes in the flight deck.",
  [("Enroute-cruise-Fire/smoke (non-impact)", 1)], None, None),
 ("2018020113", "2018-02-01", "Dallas", "TX", "777-300ER", "N77WQZ", "NONE", "NONE", "VMC", "DAYL",
  "During approach to KDFW the crew of the Boeing 777-300ER received a hydraulic failure alert for the center system. The landing gear did not extend normally and the crew used the alternate extension procedure. The airplane landed without further incident. A chafed hydraulic line in the main landing gear wheel well was found leaking.",
  "A chafed hydraulic line that resulted in a loss of center hydraulic system fluid.",
  [("Approach-Sys/Comp malf/fail (non-power)", 1)], None, None),
 ("2023071514", "2023-07-15", "Denver", "CO", "737 MAX 8", "N38PQZ", "NONE", "NONE", "VMC", "DAYL",
  "On final approach to runway 16R at KDEN the Boeing 737 MAX 8 encountered a microburst at about 400 feet above ground level. The crew received a windshear warning, performed the windshear escape maneuver and went around, climbing to 8,000 feet. A second approach was made to runway 35L after the thunderstorm moved east. METAR KDEN 152153Z 22023G41KT 10SM TSRA FEW060CB.",
  "The airplane's encounter with a microburst on final approach.",
  [("Approach-Windshear or thunderstorm", 1)], None, None),
 ("2022050515", "2022-05-05", "San Francisco", "CA", "777-200ER", "N772RZ", "NONE", "NONE", "VMC", "DAYL",
  "While climbing through 9,000 feet after departure from KSFO the Boeing 777-200ER received a traffic collision avoidance resolution advisory against a general aviation airplane that had entered the class B airspace without a clearance. The crew followed the resolution advisory. The two airplanes passed within 0.4 nautical miles horizontally and 300 feet vertically.",
  "The general aviation pilot's entry into class B airspace without a clearance, which resulted in a loss of separation.",
  [("Initial climb-Midair collision", 1)], None, None),
 ("2021041716", "2021-04-17", "Boston", "MA", "787-9", "N789RZ", "SUBS", "NONE", "VMC", "NITE",
  "While taxiing to the gate at KBOS the Boeing 787-9's right wingtip struck the tail of a parked regional jet. The ramp area was congested and no wing walkers were used. The captain reported he believed the airplane had adequate clearance and that the taxi line was obscured.",
  "The flight crew's failure to maintain clearance from a parked airplane while taxiing in a congested ramp area.",
  [("Taxi-Ground collision", 1)], None, None),
]

ev, ac, nr, sq = [], [], [], []
for (eid, date, city, st, model, reg, dmg, inj, wx, light, narr, cause, occs, avh, asn) in E:
    ev.append(dict(ev_id=eid, ev_date=date, ev_city=city, ev_state=st, ev_country="USA",
                   ev_type="ACC" if dmg in ("SUBS", "DEST") or inj in ("SERS", "FATL") else "INC",
                   ev_highest_injury=inj, wx_cond_basic=wx, light_cond=light))
    ac.append(dict(ev_id=eid, Aircraft_Key="1", regis_no=reg, acft_make="BOEING", acft_model=model, far_part="121", damage=dmg))
    nr.append(dict(ev_id=eid, Aircraft_Key="1", narr_accp=narr, narr_cause=cause))
    for k, (o, d) in enumerate(occs, 1):
        sq.append(dict(ev_id=eid, Aircraft_Key="1", Occurrence_No=str(k), Occurrence_Description=o, Defining_ev=str(d)))
for name, rows in [("events", ev), ("aircraft", ac), ("narratives", nr), ("events_sequence", sq)]:
    pd.DataFrame(rows).to_csv(root / "ntsb_csv" / f"{name}.csv", index=False)

for (eid, *_rest) in E:
    pass
n_avh = n_asn = 0
for e in E:
    eid, avh, asn = e[0], e[13], e[14]
    if avh:
        t, b = avh
        (root / "avh_html" / f"avh_{eid}.html").write_text(f"<html><body><h1>{t}</h1><div class='article'>{b}</div></body></html>")
        n_avh += 1
    if asn:
        rows = [("Date", asn["date"]), ("Type", asn["type"]), ("Owner/operator", asn["operator"]), ("Registration", asn["reg"]),
                ("Year of manufacture", asn["yom"]), ("Fatalities", asn["fat"]), ("Aircraft damage", asn["damage"]),
                ("Category", asn["cat"]), ("Location", asn["loc"]), ("Phase", asn["phase"]), ("Nature", "Passenger - Scheduled"),
                ("Investigating agency", "NTSB")]
        html = "<html><body><table>" + "".join(f"<tr><td>{k}:</td><td>{v}</td></tr>" for k, v in rows) + \
               f"</table><p>Narrative:</p><p>{asn['narr']}</p></body></html>"
        (root / "asn_html" / f"asn_{eid}.html").write_text(html)
        n_asn += 1
print(f"fictional Boeing sample -> {root}: {len(E)} NTSB events, {n_avh} AvHerald, {n_asn} ASN")
