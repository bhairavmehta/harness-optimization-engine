"""Generate FICTIONAL sample inputs in each source's native format for smoke tests.
None of these events are real; registrations/operators are invented."""
import json
import random
import sys
from pathlib import Path

import pandas as pd

random.seed(3)
root = Path(sys.argv[1] if len(sys.argv) > 1 else "sample_data")
(root / "ntsb_csv").mkdir(parents=True, exist_ok=True)
(root / "avh_html").mkdir(exist_ok=True)
(root / "asn_html").mkdir(exist_ok=True)

T = {
    "Loss of control in flight": ("Maneuvering-Loss of control in flight",
        "The pilot reported that during a steep turn at {alt} feet AGL the airplane stalled and entered a spin. The 52-year-old pilot held 310 total hours of flight experience. The airplane impacted terrain."),
    "Runway excursion": ("Landing-Runway excursion",
        "During the landing roll on runway 27 the airplane veered off the left side of the runway. The METAR reported wind 31018G26KT 10SM. The pilot reported a gusting crosswind and did not apply sufficient rudder."),
    "Loss of engine power (total)": ("Enroute-Loss of engine power (total)",
        "While in cruise at {alt} feet MSL, the engine lost total power. The pilot performed a forced landing to a field. Examination revealed fuel contamination was not found; the crankshaft had fractured."),
    "Sys/Comp malf/fail (non-power)": ("Approach-Sys/Comp malf/fail (non-power)",
        "On approach the crew received a hydraulic failure alert and the landing gear did not extend normally. The crew declared an emergency, used the alternate extension procedure and landed safely."),
    "Birdstrike": ("Initial climb-Birdstrike",
        "Shortly after takeoff, while climbing through 800 feet, the airplane struck several geese. The crew returned to the departure airport. Damage to the wing leading edge was substantial."),
    "Abnormal runway contact": ("Landing-Abnormal runway contact",
        "The airplane bounced during the flare and touched down hard, resulting in a tail strike. Recorded vertical acceleration reached 2.4 G. The approach was unstabilized."),
}
ev, ac, nr, sq = [], [], [], []
i = 0
for defining, (occ, txt) in T.items():
    for k in range(5):
        i += 1
        eid = f"2025{i:010d}"
        ev.append(dict(ev_id=eid, ev_date=f"{2005 + (i * 5) % 21}-0{1 + k % 9}-1{k}", ev_city=random.choice(["Arlington", "Spokane", "Boise", "Yakima"]),
                       ev_state=random.choice(["WA", "ID", "OR"]), ev_country="USA", ev_type="ACC",
                       ev_highest_injury=random.choice(["NONE", "MINR", "SERS", "FATL"] if "control" in defining else ["NONE", "MINR"]),
                       wx_cond_basic=random.choice(["VMC", "VMC", "IMC"]), light_cond=random.choice(["DAYL", "NITE"])))
        ac.append(dict(ev_id=eid, Aircraft_Key="1", regis_no=f"N{100 + i}ZX", acft_make=random.choice(["CESSNA", "PIPER", "BEECH"]),
                       acft_model=random.choice(["172S", "PA-28-181", "A36"]), far_part="091", damage=random.choice(["SUBS", "MINR"])))
        nr.append(dict(ev_id=eid, Aircraft_Key="1", narr_accp=txt.format(alt=random.choice([800, 1500, 4500, 6500])),
                       narr_cause=f"The pilot's actions leading to {defining.lower()}."))
        sq.append(dict(ev_id=eid, Aircraft_Key="1", Occurrence_No="1", Occurrence_Description=occ, Defining_ev="1"))

# one linked transport-category event (fictional) across all three sources
eid = "20251104999901"
ev.append(dict(ev_id=eid, ev_date="2025-11-04", ev_city="Spokane", ev_state="WA", ev_country="USA", ev_type="INC",
               ev_highest_injury="NONE", wx_cond_basic="VMC", light_cond="NITE"))
ac.append(dict(ev_id=eid, Aircraft_Key="1", regis_no="N787QX", acft_make="BOEING", acft_model="787-9", far_part="121", damage="MINR"))
nr.append(dict(ev_id=eid, Aircraft_Key="1",
               narr_accp="During the landing roll on runway 21 at KGEG, the crew selected reverse thrust. The left thrust reverser deployed slowly and the crew alerting system displayed a REV message. The airplane drifted right and the captain applied rudder and differential braking; the airplane remained on the runway. There was no evidence of a bird strike. The airplane was grounded for maintenance.",
               narr_cause="Slow deployment of the left thrust reverser due to a degraded hydraulic actuator."))
sq += [dict(ev_id=eid, Aircraft_Key="1", Occurrence_No="1", Occurrence_Description="Landing-Sys/Comp malf/fail (non-power)", Defining_ev="1"),
       dict(ev_id=eid, Aircraft_Key="1", Occurrence_No="2", Occurrence_Description="Landing-Loss of control on ground", Defining_ev="0")]

for name, rows in [("events", ev), ("aircraft", ac), ("narratives", nr), ("events_sequence", sq)]:
    pd.DataFrame(rows).to_csv(root / "ntsb_csv" / f"{name}.csv", index=False)

avh = [
    ("Incident: Cascadia B789 at Spokane on Nov 4th 2025, thrust reverser deployed slowly, veered on landing",
     "A Cascadia Airways Boeing 787-9, registration N787QX performing flight CX-412 from Seattle to Spokane with 214 passengers and 11 crew, landed on Spokane's runway 21 at night when the left thrust reverser deployed slowly. The aircraft veered right but the crew was able to keep the aircraft on the runway and taxi to the gate. The aircraft remained on the ground for about 26 hours before returning to service. METAR KGEG 050256Z 23012KT 10SM FEW050 04/M02"),
    ("Incident: Northline A21N near Boise on Oct 2nd 2025, bird strike",
     "A Northline Airbus A321-200N, registration N921NL, was climbing out of Boise when the aircraft struck a flock of birds. The crew stopped the climb at 6000 feet and returned to Boise for a safe landing about 25 minutes after departure. Possibly the engine ingested birds."),
    ("Incident: Pacifica E175 at Portland on Sep 9th 2025, smoke in cabin",
     "A Pacifica Embraer E175, registration N175PX, was on approach to Portland when smoke appeared in the cabin. The crew declared Mayday and landed safely, the passengers disembarked onto the runway. No injuries were reported."),
]
for n, (t, b) in enumerate(avh):
    (root / "avh_html" / f"avh_{n}.html").write_text(f"<html><body><h1>{t}</h1><div class='article'>{b}</div></body></html>")

asn = ("<html><body><table>"
       "<tr><td>Date:</td><td>Tuesday 4 November 2025</td></tr><tr><td>Type:</td><td>Boeing 787-9 Dreamliner</td></tr>"
       "<tr><td>Owner/operator:</td><td>Cascadia Airways</td></tr><tr><td>Registration:</td><td>N787QX</td></tr>"
       "<tr><td>Year of manufacture:</td><td>2017</td></tr><tr><td>Fatalities:</td><td>Fatalities: 0 / Occupants: 225</td></tr>"
       "<tr><td>Aircraft damage:</td><td>Minor</td></tr><tr><td>Category:</td><td>Incident</td></tr>"
       "<tr><td>Location:</td><td>Spokane International Airport (GEG/KGEG), WA</td></tr><tr><td>Phase:</td><td>Landing</td></tr>"
       "<tr><td>Nature:</td><td>Passenger - Scheduled</td></tr><tr><td>Departure airport:</td><td>Seattle-Tacoma (KSEA)</td></tr>"
       "<tr><td>Destination airport:</td><td>Spokane (KGEG)</td></tr><tr><td>Investigating agency:</td><td>NTSB</td></tr></table>"
       "<p>Narrative:</p><p>The left thrust reverser deployed slowly on landing at Spokane, causing the aircraft to veer right. The crew maintained directional control.</p></body></html>")
(root / "asn_html" / "asn_0.html").write_text(asn)
print("sample data ->", root)
