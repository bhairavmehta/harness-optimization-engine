# avintel — feature engineering for aviation occurrence reports

Turns **NTSB**, **The Aviation Herald** and **Aviation Safety Network** reports into one canonical
record per report, ~295 engineered features, weak labels, cross-source links and a calibrated
CICTT occurrence-category classifier — with decision-time-valid evaluation.

## Install

```bash
pip install -r requirements.txt          # core
pip install sentence-transformers        # optional: --embed-model
```

## Quick start

```bash
python scripts/make_sample_data.py sample_data          # FICTIONAL test data in each source's native format
python scripts/make_boeing_sample.py boeing_sample     # FICTIONAL 737/777/787 events (NTSB, AvHerald, ASN)
python -m avintel.pipeline \
    --ntsb-dir sample_data/ntsb_csv \
    --avh-html sample_data/avh_html \
    --asn-html sample_data/asn_html \
    --out out --leakage-check
python -m avintel.viz --out out [--families B737MAX,B737NG/CL,B777,B787] [--run other_out=Label]   # -> out/feature_viewer.html
# viewer views: Report (highlighted narrative + flight profile), Feature matrix, How each bucket works (generated from bucket_docs.py)
python -m avintel.export_xlsx --out out                  # -> out/avintel_features.xlsx
# out/reports_features.csv is written by every pipeline run: one row per report with every field,
# feature, label, prediction and link (column guide in reports_features_columns.csv)
python -m avintel.export_csv --run out="Run A" --run other_out="Run B" --csv all_reports.csv   # combine runs
pytest                                                   # 10 tests incl. an end-to-end run
```

### Real NTSB data

Tested on the full avall.mdb (Nov 2026 release): 1,317 Boeing 737/777/787 aircraft records, 1,192 with an NTSB category.
The ingester splits post-2008 occurrence text ('Taxi-from runway Sys/Comp malf/fail') into phase and event using
the event codes, and appends acft_series to the model ('737' + '8' -> '737-8', a 737 MAX 8).
Many post-2020 and foreign cases have no narrative in avall; evaluation.json reports scores on test reports with text
(`macro_f1_with_text`) as well as overall.


```bash
# avall.mdb (2008+) and Pre2008.mdb from https://data.ntsb.gov/avdata
for t in events aircraft narratives events_sequence Findings; do
  mdb-export avall.mdb "$t" > ntsb_csv/$t.csv
done
python -m avintel.pipeline --ntsb-dir ntsb_csv --out out --eval-cutoff-year 2021 --leakage-check
```
NTSB report PDFs (CAROL final/preliminary reports): `--ntsb-pdf-dir report_pdfs/` (also writes `pdf_fields.csv`).
CAROL exports: `--carol carol.csv` (columns mapped in `ingest_ntsb.CAROL_MAP`).
NTSB moves the downloadable dataset to its Enterprise API on **5 Apr 2027** — the CSV loader is
isolated in `ingest_ntsb.py` so only that module needs to change.

### AvHerald / ASN — licensing first
AvHerald pages state *"reproduction, redistribution and AI learning/use prohibited"*; ASN publishes no
usable reuse terms. Until written terms are obtained, use them for **linkage keys and metadata only**.
The loaders read saved HTML or CSV/JSONL; `ingest_avherald.polite_fetch` is opt-in and rate-limited.

## Pipeline

| Stage | Module | What it does |
|---|---|---|
| 1 Ingest | `ingest_ntsb`, `ingest_avherald`, `ingest_asn` | Source parsers → 22-column canonical schema (`schema.py`). AvHerald headline grammar incl. ICAO type codes; ASN fact table. |
| 2 Normalize | `normalize` | 44 aviation abbreviation patterns, sentence split, NegEx-style affirmed / negated / uncertain scoping. |
| 3 Extract | `extractors` | Altitude/FL, speed, vertical speed, g, distance, crew hours & age, POB, injuries, METAR wind/gust/vis/ceiling, airports, runways, registrations, flight numbers. |
| 4 Featurize | `features`, `taxonomy` | 13 families: `meta_ txt_ occ_ ph_ ata_ hf_ wx_ out_ q_/crew_ ent_ seq_ link_ lbl_`. |
| 5 Weak labels | `labeling` | 6 labeling functions, accuracy-weighted vote vs NTSB gold. |
| 6 Link | `linking` | ±3-day blocking; registration / family / location / text / date score; union-find clusters; label propagation. |
| 7 Classify | `classify` | Word + char TF-IDF + evidence numeric block (+ embeddings) → balanced LR, Platt-calibrated; review flag. |
| 8 Evaluate | `evaluate` | Temporal split grouped by event cluster; majority & lexicon baselines; macro-F1, Brier; per-era / per-source. |

## Leakage controls (from the literature review)

* **Text profiles** (`--profile`): `notification` (title + first paragraph), `factual` (default),
  `full` (adds probable cause — answer-side, only for measuring leakage). `--leakage-check` evaluates all three;
  `evaluation.json → leakage_gap_macro_f1` is the inflation caused by answer-side text.
* **Answer-side columns** (`lbl_*`, `seq_*`, `link_*`, `meta_has_cause`, `meta_n_findings`) are never model inputs —
  see `features.is_answer_column` and `feature_dictionary.csv → side`.
* **NTSB titles** are synthesized without the defining event.
* **Era-aware labels**: post-2008 = defining event; pre-2008 = first occurrence (`lbl_source`, `meta_era`).
  Do not pool trends across 2008 without a bridging study.
* **NTSB → CICTT crosswalk** (`taxonomy.NTSB_DEFINING_TO_CICTT`) is ours, not NTSB's: version it and get SME sign-off.

## Outputs (`--out`)
`records.parquet`, `features.parquet`, `feature_dictionary.csv`, `weak_labels.csv`, `lf_report.csv`,
`links.csv`, `predictions.parquet`, `evaluation.json`, `lexicon_suggestions.json`, `top_terms.json`,
`reports_features.csv` (one row per report, everything) and `reports_features_columns.csv` (column guide).

## Extending
* Lexicons: edit `taxonomy.py`; review `lexicon_suggestions.json` with SMEs.
* Labeling functions: add a function to `labeling.LFS` returning a CICTT code or `None`.
* LLM extraction / fine-tuned encoders: add their outputs as columns (evidence side) or as labeling functions.
