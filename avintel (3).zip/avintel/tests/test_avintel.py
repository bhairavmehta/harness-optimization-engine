import json
import subprocess
import sys
from pathlib import Path

import pandas as pd
import pytest

from avintel import extractors, features, ingest_asn, ingest_avherald
from avintel.normalize import clean, scope_tag

ROOT = Path(__file__).resolve().parents[1]


def test_avherald_title_grammar():
    t = ingest_avherald.parse_title(
        "Incident: Cascadia B789 at Spokane on Nov 4th 2025, thrust reverser deployed slowly, veered on landing")
    assert t["event_type"] == "Incident"
    assert t["aircraft"] == "B789" and t["operator"] == "Cascadia"
    assert ingest_avherald._split_make_model("B789") == ("BOEING", "787-9")
    assert ingest_avherald.parse_title("Incident: Northline A21N near Boise on Oct 2nd 2025, bird strike")["aircraft"] == "A21N"
    assert t["location"] == "Spokane"
    assert t["event_date"] == "2025-11-04"
    assert "thrust reverser" in t["summary"]


def test_abbreviation_and_negation():
    s = clean("There was no evidence of a bird strike. The T/R deployed slowly.")
    assert "thrust reverser" in s
    sent = "There was no evidence of a bird strike."
    i = sent.index("bird strike")
    assert scope_tag(sent, (i, i + 11)) == "neg"
    sent2 = "The aircraft reportedly struck a bird."
    j = sent2.index("struck")
    assert scope_tag(sent2, (j, j + 6)) == "unc"


def test_negated_hit_does_not_fire_affirmed_feature():
    rec = {"report_id": "X:1", "source": "AVHERALD", "title": "", "narrative": "There was no evidence of a bird strike.",
           "occurrences": [], "findings": []}
    row = features.build_row(rec)
    assert row["occ_BIRD"] == 0 and row["occ_BIRD_neg"] == 1


def test_quantity_extraction():
    f = extractors.extract("Climbing through 1,500 feet at 140 knots; METAR 23012G25KT 3SM OVC008. "
                           "The 45-year-old captain had 12,400 hours. flight CX-412 registration N787QX")
    assert f["q_alt_ft_max"] == 1500 and f["q_speed_kt_max"] == 140
    assert f["wx_gust_kt_max"] == 25 and f["wx_vis_sm_min"] == 3 and f["wx_ceiling_ft_min"] == 800
    assert f["crew_total_hours_max"] == 12400 and f["crew_age_max"] == 45
    assert "CX-412" not in (f["ent_registrations"] or "") and "N787QX" in f["ent_registrations"]


def test_asn_fact_table():
    html = ("<table><tr><td>Date:</td><td>Tuesday 4 November 2025</td></tr>"
            "<tr><td>Type:</td><td>Boeing 787-9</td></tr><tr><td>Registration:</td><td>N787QX</td></tr>"
            "<tr><td>Fatalities:</td><td>Fatalities: 0 / Occupants: 225</td></tr>"
            "<tr><td>Aircraft damage:</td><td>Minor</td></tr></table><p>Narrative:</p><p>Reverser slow.</p>")
    r = ingest_asn.parse_asn_html(html)
    assert r["event_date"] == "2025-11-04" and r["registration"] == "N787QX" and r["damage"] == "MINR"
    assert "asn_occupants=225" in r["findings"]


def test_profiles_exclude_probable_cause():
    rec = {"report_id": "NTSB:1", "source": "NTSB", "title": "ACC CESSNA 172", "narrative": "Para one.\n\nPara two.",
           "probable_cause": "The pilot's failure to maintain control.", "occurrences": [], "findings": []}
    assert "failure to maintain" not in features.evidence_text(rec, "factual")
    assert "Para two" not in features.evidence_text(rec, "notification")
    assert "failure to maintain" in features.evidence_text(rec, "full")


def test_era_aware_labels():
    rec = {"source": "NTSB", "defining_event": "Landing-Runway excursion",
           "occurrences": ["Approach-Loss of control in flight", "Landing-Runway excursion"]}
    assert features.make_labels(rec, "post2008")["lbl_cictt"] == "RE"
    pre = features.make_labels(rec, "pre2008")
    assert pre["lbl_cictt"] == "LOC-I" and pre["lbl_source"] == "first_occurrence"


def test_weak_label_codes_and_confidence():
    from avintel import labeling
    votes = pd.DataFrame({"lf_lexicon_top": ["SCF-NP", None], "lf_title_keywords": ["SCF-NP", "BIRD"],
                          "lf_ata_to_cictt": ["SCF-PP", None]})
    out = labeling.combine(votes, {"lf_lexicon_top": 0.3, "lf_title_keywords": 0.9, "lf_ata_to_cictt": 0.6})
    assert out.loc[0, "weak_label"] == "SCF-NP" and 0 <= out.loc[0, "weak_conf"] <= 1
    assert out.loc[1, "weak_label"] == "BIRD" and out.loc[1, "weak_conf"] == 1.0
    assert labeling.lf_lexicon_top({"occ_top": "SCF_NP", "occ_n_categories": 1}) == "SCF-NP"


def test_answer_columns_not_in_model_inputs():
    df = pd.DataFrame({"report_id": ["a"], "source": ["NTSB"], "_text": ["x"], "seq_len": [3], "meta_has_cause": [1],
                       "lbl_linked": ["RE"], "occ_RE": [1], "link_n_sources": [2]})
    cols = features.numeric_columns(df)
    assert cols == ["occ_RE"]


@pytest.mark.slow
def test_end_to_end(tmp_path):
    data = tmp_path / "data"
    out = tmp_path / "out"
    subprocess.run([sys.executable, str(ROOT / "scripts" / "make_sample_data.py"), str(data)], check=True, cwd=ROOT)
    subprocess.run([sys.executable, "-m", "avintel.pipeline", "--ntsb-dir", str(data / "ntsb_csv"),
                    "--avh-html", str(data / "avh_html"), "--asn-html", str(data / "asn_html"),
                    "--out", str(out), "--leakage-check"], check=True, cwd=ROOT)
    feats = pd.read_parquet(out / "features.parquet")
    assert len(feats) == 35 and feats.shape[1] > 250
    links = pd.read_csv(out / "links.csv")
    assert len(links) >= 2
    ev = json.loads((out / "evaluation.json").read_text())
    assert ev["factual"]["n_test"] > 0 and "macro_f1" in ev["factual"]
    pred = pd.read_parquet(out / "predictions.parquet")
    assert {"pred_cictt", "pred_conf", "needs_review"} <= set(pred.columns)
    flat = pd.read_csv(out / "reports_features.csv", encoding="utf-8-sig", low_memory=False)
    assert len(flat) == 35 and flat["report_id"].is_unique
    cols = list(flat.columns)
    assert cols[:2] == ["dataset", "report_id"] and "model_input_text" in cols and "ntsb_probable_cause" in cols
    assert cols.index("model_input_text") < cols.index("meta_year") < cols.index("pred_cictt") < cols.index("linked_reports")
    # the model-input text never contains the probable cause
    row = flat[flat.report_id.str.startswith("NTSB:20251104999901")].iloc[0]
    assert row["ntsb_probable_cause"] not in row["model_input_text"]
    guide = pd.read_csv(out / "reports_features_columns.csv", encoding="utf-8-sig")
    assert set(guide["side"]) >= {"evidence", "answer"} and len(guide) == len(cols)


def test_export_csv_combines_runs(tmp_path):
    from avintel import export_csv
    data, out = tmp_path / "data", tmp_path / "out"
    subprocess.run([sys.executable, str(ROOT / "scripts" / "make_sample_data.py"), str(data)], check=True, cwd=ROOT)
    subprocess.run([sys.executable, "-m", "avintel.pipeline", "--ntsb-dir", str(data / "ntsb_csv"),
                    "--avh-html", str(data / "avh_html"), "--out", str(out), "--no-csv"], check=True, cwd=ROOT)
    assert not (out / "reports_features.csv").exists()
    dest = tmp_path / "all.csv"
    export_csv.main(["--run", f"{out}=Run A", "--run", f"{out}=Run B", "--families", "B787", "--families-for", "Run B", "--csv", str(dest)])
    df = pd.read_csv(dest, encoding="utf-8-sig", low_memory=False)
    assert set(df["dataset"]) == {"Run A", "Run B"}
    assert (df[df.dataset == "Run B"]["meta_family"] == "B787").all()
