"""Decision-time-valid evaluation.

* Temporal split: train on years <= cutoff, test on later years.
* Grouped: every row of a linked cluster (same real-world event across sources)
  is assigned to the side of its EARLIEST report, so an event never straddles the split.
* Baselines: majority class and lexicon `occ_top`.
* Leakage estimate: re-run under the notification / factual / full text profiles;
  the gap between `factual` and `full` is how much answer-side text inflates scores.
* Metrics: macro-F1, per-class precision/recall/F1, Brier score of calibrated probabilities.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, classification_report, f1_score

from .classify import OccurrenceClassifier


def temporal_group_split(feats: pd.DataFrame, cutoff_year: int, group_col: str = "link_cluster"):
    years = pd.to_numeric(feats["meta_year"], errors="coerce")
    groups = feats[group_col] if group_col in feats else feats["report_id"]
    first_year = years.groupby(groups).transform("min")
    train = first_year <= cutoff_year
    test = first_year > cutoff_year
    return (train.fillna(False).to_numpy(dtype=bool).copy(), test.fillna(False).to_numpy(dtype=bool).copy())


def auto_cutoff(feats: pd.DataFrame, test_frac: float = 0.25) -> int:
    years = pd.to_numeric(feats.loc[feats["lbl_cictt"].notna(), "meta_year"], errors="coerce").dropna()
    return int(np.quantile(years, 1 - test_frac)) if len(years) else 9999


def _norm_lex(code):
    return None if code is None or (isinstance(code, float) and np.isnan(code)) else str(code).replace("_", "-")


def evaluate(feats: pd.DataFrame, y: pd.Series, cutoff_year: int | None = None, **clf_kw) -> dict:
    cutoff_year = cutoff_year if cutoff_year is not None else auto_cutoff(feats)
    tr, te = temporal_group_split(feats, cutoff_year)
    tr &= y.notna().to_numpy()
    te &= feats["lbl_cictt"].notna().to_numpy()          # score only on gold labels
    res = {"cutoff_year": cutoff_year, "n_train": int(tr.sum()), "n_test": int(te.sum())}
    if tr.sum() < 4 or te.sum() < 2:
        res["note"] = "not enough labeled rows on one side of the split"
        return res
    try:
        clf = OccurrenceClassifier(**clf_kw).fit(feats[tr], y[tr])
    except ValueError as e:
        res["note"] = f"cannot train: {e}"
        return res
    P = clf.predict_proba(feats[te])
    yt = feats.loc[te, "lbl_cictt"]
    labels = sorted(set(yt) | set(P["pred_cictt"]))
    maj = y[tr].mode().iloc[0]
    lex = feats.loc[te, "occ_top"].map(_norm_lex).fillna(maj)
    res.update({
        "macro_f1": f1_score(yt, P["pred_cictt"], average="macro", labels=labels, zero_division=0),
        "accuracy": accuracy_score(yt, P["pred_cictt"]),
        "baseline_majority_macro_f1": f1_score(yt, [maj] * len(yt), average="macro", labels=labels, zero_division=0),
        "baseline_lexicon_macro_f1": f1_score(yt, lex, average="macro", labels=labels, zero_division=0),
        "per_class": classification_report(yt, P["pred_cictt"], output_dict=True, zero_division=0),
        "unseen_test_classes": sorted(set(yt) - set(clf.classes_)),
        "dropped_rare_classes": clf.dropped_classes_,
        "review_rate": float(P["needs_review"].mean()),
    })
    # reports with a usable narrative (recent NTSB cases often ship without one)
    if "txt_words" in feats:
        has_text = (pd.to_numeric(feats.loc[te, "txt_words"], errors="coerce").fillna(0) >= 30).to_numpy()
        res["n_test_with_text"] = int(has_text.sum())
        if has_text.sum() >= 2:
            yt2, pr2, lx2 = yt[has_text], P["pred_cictt"][has_text], lex[has_text]
            lab2 = sorted(set(yt2) | set(pr2))
            res["macro_f1_with_text"] = round(float(f1_score(yt2, pr2, average="macro", labels=lab2, zero_division=0)), 4)
            res["accuracy_with_text"] = round(float(accuracy_score(yt2, pr2)), 4)
            res["baseline_lexicon_macro_f1_with_text"] = round(float(f1_score(yt2, lx2, average="macro", labels=lab2, zero_division=0)), 4)
    onehot = np.array([[1.0 if t == c else 0.0 for c in clf.classes_] for t in yt])
    res["brier"] = float(np.mean(np.sum((P[[f"p_{c}" for c in clf.classes_]].to_numpy() - onehot) ** 2, axis=1)))
    for k in ("macro_f1", "accuracy", "baseline_majority_macro_f1", "baseline_lexicon_macro_f1"):
        res[k] = round(float(res[k]), 4)
    return res


def stratified_report(feats: pd.DataFrame, pred: pd.DataFrame, by: str) -> pd.DataFrame:
    """Macro-F1 per stratum (e.g. meta_era, meta_commercial, source) on rows with gold labels."""
    d = feats[[by, "lbl_cictt"]].join(pred["pred_cictt"]).dropna(subset=["lbl_cictt"])
    rows = []
    for k, g in d.groupby(by, dropna=False):
        rows.append({by: k, "n": len(g),
                     "macro_f1": round(f1_score(g["lbl_cictt"], g["pred_cictt"], average="macro", zero_division=0), 4)})
    return pd.DataFrame(rows)
