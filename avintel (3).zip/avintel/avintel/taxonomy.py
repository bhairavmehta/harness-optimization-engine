"""Domain taxonomies used as feature dictionaries and weak-label sources.

Occurrence categories follow the CAST/ICAO Common Taxonomy Team (CICTT)
codes that the SEWG category set is built on. Lexicons are deliberately
starter-grade: extend them from your SME reviews and from the NTSB findings
vocabulary (see `mine_lexicon` in features.py).
"""

# ---- CICTT / SEWG occurrence categories -> regex lexicon --------------------
OCCURRENCE_LEXICON = {
    "ARC":       [r"abnormal runway contact", r"hard landing", r"tail ?strike", r"bounced landing", r"wing ?strike", r"gear[- ]up landing", r"nose ?wheel first"],
    "RE":        [r"runway excursion", r"overr[au]n", r"veered off", r"departed the (runway|paved)", r"ran off the (end|side)", r"excursion"],
    "SCF-NP":    [r"hydraulic (failure|leak|loss)", r"landing gear (failure|malfunction|would not|did not extend)", r"flap(s)? (failure|asymmetr|jam)", r"(cabin )?(de)?pressuri[sz]ation", r"electrical (failure|fault)", r"flight control (failure|malfunction|jam)", r"thrust reverser (unlock|deploy|failure|slow)", r"brake (failure|fire|overheat)", r"tire (burst|failure)|tyre burst", r"windshield (crack|failure)", r"door (open|warning)"],
    "SCF-PP":    [r"engine (failure|shut ?down|fire|surge|stall|flame ?out|vibration|separation)", r"in flight shutdown", r"loss of (engine )?power", r"uncontained", r"compressor stall", r"oil pressure", r"(fan|turbine) blade"],
    "LOC-I":     [r"loss of control", r"\bstall(ed)?\b(?! warning test)", r"\bspin\b", r"upset", r"unusual attitude", r"spatial disorientation", r"stick shaker"],
    "LOC-G":     [r"loss of directional control", r"ground loop", r"skid(ded)? on (the )?(taxiway|ramp)"],
    "CFIT":      [r"controlled flight into terrain", r"terrain awareness warning", r"impacted (terrain|trees|mountain|water)", r"collided with terrain"],
    "MAC":       [r"mid-?air", r"near (mid ?air )?collision", r"\bairprox\b", r"loss of separation", r"resolution advisory"],
    "RI":        [r"runway incursion", r"entered the (active )?runway", r"crossed the hold ?(short|line)", r"without (a )?clearance.{0,40}?runway"],
    "GCOL":      [r"ground collision", r"collided with .{0,40}? (on the ground|while taxiing)", r"wing ?tip (struck|clipped|contact)", r"struck .{0,30}?(tug|vehicle|parked)"],
    "RAMP":      [r"\bramp\b", r"pushback", r"tow(ing|bar)", r"ground handling", r"jet ?bridge", r"\bgate\b"],
    "TURB":      [r"turbulence", r"clear air turbulence", r"\bCAT\b", r"wake (vortex|turbulence)"],
    "WSTRW":     [r"wind ?shear", r"microburst", r"thunderstorm", r"convective"],
    "ICE":       [r"\bic(e|ing)\b", r"freezing (rain|drizzle)", r"de-?icing", r"anti-?ice"],
    "BIRD":      [r"bird ?strike", r"struck (a |several )?birds?", r"bird ingestion", r"geese", r"\bwildlife\b"],
    "F-NI":      [r"\bfire\b", r"\bsmoke\b", r"\bfumes?\b", r"burning smell", r"lithium", r"battery (fire|thermal)"],
    "FUEL":      [r"fuel (exhaustion|starvation|leak|imbalance|contamination)", r"ran out of fuel", r"low fuel"],
    "CTOL":      [r"collision with obstacle", r"struck (power ?lines|wires|a tower|an antenna|trees) during (takeoff|landing)"],
    "USOS":      [r"landed (on|at) (the )?(wrong|taxiway|closed)", r"took off from (a )?taxiway", r"undershoot", r"short of the runway"],
    "AMAN":      [r"abrupt manoeuvre|abrupt maneuver", r"evasive (action|manoeuvre|maneuver)"],
    "ADRM":      [r"aerodrome", r"runway (lighting|contamination|condition)", r"\bNOTAM\b", r"\bFOD\b|foreign object"],
    "ATM":       [r"air traffic control (error|instruction|clearance)", r"controller", r"(lost|loss of) communication", r"\bNORDO\b"],
    "TURB-WAKE": [r"wake (vortex|turbulence)"],
    "SEC":       [r"hijack", r"bomb threat", r"unruly", r"security", r"laser (strike|illumination)", r"\bcyber\b", r"spoof(ing)?", r"GPS (jamming|interference)"],
    "UAS":       [r"\bdrone\b", r"\bUAS\b", r"\bUAV\b", r"unmanned"],
    "MED":       [r"medical emergency", r"(pilot|crew) incapacitat", r"passenger .{0,30}?(ill|unwell|died)"],
    "EVAC":      [r"evacuat", r"escape slides?", r"emergency exit"],
}

# ---- Phase of flight (CICTT phase taxonomy, simplified) -------------------
PHASE_LEXICON = {
    "STANDING": [r"\bparked\b", r"at the gate", r"boarding", r"engine start"],
    "TAXI":     [r"\btaxi(ing|ed)?\b", r"pushback", r"\bramp\b"],
    "TAKEOFF":  [r"take ?off roll", r"during (the )?take ?off", r"\brotation\b", r"rejected take ?off", r"\bV1\b", r"lift ?off"],
    "INITIAL_CLIMB": [r"initial climb", r"after (take ?off|departure)", r"climbing through \d"],
    "ENROUTE":  [r"\bcruise\b", r"en ?route", r"flight level", r"\bFL\s?\d{2,3}\b"],
    "DESCENT":  [r"\bdescen(t|ding)\b", r"top of descent"],
    "APPROACH": [r"\bapproach\b", r"\bfinal\b", r"glide ?(slope|path)", r"instrument landing system", r"\bgo around\b"],
    "LANDING":  [r"\blanding\b", r"touch ?down", r"\bflare\b", r"landing roll", r"thrust reverser"],
    "MANEUVERING": [r"maneuver(ing)?", r"aerobatic", r"low pass", r"agricultural"],
}

# ---- ATA iSpec 2200 chapters (system / component) --------------------------
ATA_LEXICON = {
    "21_AIR_COND_PRESS": [r"pressuri[sz]", r"\bpack\b", r"air conditioning", r"bleed air", r"outflow valve"],
    "22_AUTOFLIGHT":     [r"autopilot", r"autothrottle", r"flight director", r"\bMCAS\b"],
    "23_COMMS":          [r"\bradio\b", r"communication", r"transponder"],
    "24_ELECTRICAL":     [r"electrical", r"generator", r"\bbus\b", r"battery"],
    "26_FIRE_PROT":      [r"fire (warning|detection|extinguish|bottle)", r"smoke detector"],
    "27_FLIGHT_CTRL":    [r"aileron", r"elevator", r"rudder", r"spoiler", r"\bflaps?\b", r"\bslats?\b", r"stabili[sz]er", r"trim"],
    "28_FUEL":           [r"fuel (pump|tank|leak|quantity|imbalance)"],
    "29_HYDRAULIC":      [r"hydraulic"],
    "30_ICE_RAIN":       [r"anti-?ic", r"de-?ic", r"\bprobe heat\b"],
    "32_LANDING_GEAR":   [r"landing gear", r"\bbrakes?\b", r"\btyres?\b|\btires?\b", r"anti-?skid", r"nose ?wheel steering"],
    "34_NAVIGATION":     [r"\bGPS\b", r"\bADIRU\b", r"air ?data", r"pitot", r"altimeter", r"angle of attack", r"\bILS\b"],
    "36_PNEUMATIC":      [r"pneumatic", r"bleed (leak|duct)"],
    "49_APU":            [r"auxiliary power unit"],
    "52_DOORS":          [r"\bdoor\b", r"cargo door"],
    "56_WINDOWS":        [r"windshield", r"windscreen", r"cockpit window"],
    "71_POWERPLANT":     [r"\bengine\b", r"nacelle", r"cowl"],
    "72_ENGINE":         [r"\bfan blade\b", r"compressor", r"turbine", r"combustor"],
    "73_ENGINE_FUEL_CTRL": [r"\bFADEC\b", r"fuel control unit", r"\bEEC\b"],
    "78_EXHAUST_TR":     [r"thrust reverser", r"reverser"],
    "79_OIL":            [r"oil (pressure|quantity|leak|temperature)"],
}

# ---- Human factors (HFACS-flavoured) ---------------------------------------
HF_LEXICON = {
    "skill_error":       [r"failed to maintain", r"improper (flare|technique|recovery)", r"inadequate (airspeed|rudder)"],
    "decision_error":    [r"(decision|chose|elected) to (continue|proceed|depart)", r"continued (VFR|the approach) into", r"unstabili[sz]ed approach"],
    "perceptual_error":  [r"spatial disorientation", r"visual illusion", r"misjudg", r"did not see"],
    "violation":         [r"contrary to", r"not in accordance with", r"without (a )?clearance", r"exceed(ed)? .{0,30}?limit"],
    "crm_comm":          [r"crew resource management", r"miscommunication", r"did not (call|challenge)", r"readback"],
    "fatigue":           [r"fatigue", r"\bduty (time|period)\b", r"rest period", r"fell asleep"],
    "training":          [r"training", r"proficiency", r"inexperience", r"low time"],
    "procedures":        [r"checklist", r"standard operating procedure", r"\bSOP\b", r"procedure (was not|not) followed"],
    "maintenance":       [r"maintenance", r"improperly (installed|rigged|torqued)", r"inspection (missed|not performed)", r"\bMEL\b", r"deferred"],
    "automation":        [r"mode confusion", r"automation", r"autopilot (disconnect|engaged)", r"\bFMS\b|flight management"],
    "medical_impair":    [r"toxicolog", r"impair", r"incapacitat"],
    "organizational":    [r"oversight", r"safety management system", r"company (policy|pressure)", r"operator'?s? (procedures|policy)"],
}

WEATHER_LEXICON = {
    "low_visibility":  [r"\bfog\b", r"low visibility", r"\bmist\b", r"\bhaze\b", r"visibility (of )?\d"],
    "precipitation":   [r"\brain\b", r"\bsnow\b", r"\bsleet\b", r"\bhail\b"],
    "wind":            [r"gust", r"crosswind", r"tailwind", r"strong wind"],
    "convective":      [r"thunderstorm", r"\bCB\b|cumulonimbus", r"lightning"],
    "icing":           [r"\bicing\b", r"freezing"],
    "contaminated_rwy":[r"(wet|contaminated|icy|snow-covered|slush) runway", r"braking action (poor|medium)"],
    "night":           [r"\bnight\b", r"\bdark(ness)?\b"],
}

OUTCOME_LEXICON = {
    "diversion":      [r"divert(ed|ing)?", r"diversion"],
    "return":         [r"returned to", r"return to (the departure|base)", r"turn ?back"],
    "rejected_takeoff": [r"rejected take ?off"],
    "go_around":      [r"go around", r"missed approach"],
    "emergency_decl": [r"mayday", r"declared (an )?emergency", r"pan pan", r"squawk(ed)? 7700"],
    "evacuation":     [r"evacuat", r"escape slide"],
    "precautionary_landing": [r"precautionary landing", r"landed safely"],
    "fuel_dump":      [r"fuel dump", r"jettison"],
    "grounded":       [r"remained on the ground", r"grounded", r"aircraft (was )?out of service"],
    "injury":         [r"injur", r"hospital"],
    "fatality":       [r"fatal", r"killed", r"died"],
    "hull_loss":      [r"destroyed", r"written off", r"hull loss"],
}

# NTSB defining-event descriptions -> CICTT code (substring, lower-case).
# Verify against the NTSB eADMS data dictionary for your extract year.
NTSB_DEFINING_TO_CICTT = [
    # post-2008 event names seen in avall (matched before the generic entries below)
    ("pressure/environ sys malf/fail", "SCF-NP"), ("flight control sys malf/fail", "SCF-NP"),
    ("flight instrument malf/fail", "SCF-NP"), ("electrical system malf/failure", "SCF-NP"),
    ("comm system malf/failure", "SCF-NP"), ("nav system malfunction/failure", "SCF-NP"),
    ("aircraft structural failure", "SCF-NP"), ("part(s) separation from ac", "SCF-NP"),
    ("air traffic event", "ATM"), ("wrong surface or wrong airport", "RI"),
    ("altitude deviation", "NAV"), ("navigation error", "NAV"), ("course deviation", "NAV"), ("airspace incursion", "NAV"),
    ("airport occurrence", "ADRM"), ("aircraft loading event", "RAMP"), ("prop/jet/rotor blast", "RAMP"),
    ("abrupt maneuver", "AMAN"), ("evacuation", "EVAC"), ("collision during takeoff/land", "CTOL"),
    ("inflight upset", "LOC-I"), ("aerodynamic stall/spin", "LOC-I"), ("wake turb encounter", "TURB"),
    ("fuel related", "FUEL"), ("unknown or undetermined", "UNK"),
    ("loss of control in flight", "LOC-I"), ("loss of control on ground", "LOC-G"),
    ("controlled flight into terr", "CFIT"), ("runway excursion", "RE"),
    ("abnormal runway contact", "ARC"), ("tailstrike", "ARC"), ("tail strike", "ARC"), ("hard landing", "ARC"), ("nose over", "ARC"), ("gear collapse", "ARC"),
    ("fuel exhaustion", "FUEL"), ("fuel starvation", "FUEL"), ("fuel contamination", "FUEL"),
    ("loss of engine power", "SCF-PP"), ("powerplant sys/comp", "SCF-PP"), ("engine", "SCF-PP"),
    ("sys/comp malf/fail (non-power)", "SCF-NP"), ("non-power", "SCF-NP"), ("landing gear", "SCF-NP"),
    ("midair collision", "MAC"), ("near midair", "MAC"), ("ground collision", "GCOL"),
    ("runway incursion", "RI"), ("turbulence", "TURB"), ("windshear or thunderstorm", "WSTRW"),
    ("birdstrike", "BIRD"), ("wildlife", "BIRD"), ("fire/smoke (non-impact)", "F-NI"),
    ("icing", "ICE"), ("collision with terr/obj (non-cfit)", "CTOL"), ("low altitude operation", "CTOL"),
    ("undershoot", "USOS"), ("overshoot", "RE"), ("ground handling", "RAMP"), ("pushback/towing", "RAMP"),
    ("cabin safety", "CABIN"), ("medical event", "MED"), ("security", "SEC"), ("uas", "UAS"),
]

# Pre-2008 occurrence titles are coarse ("IN FLIGHT ENCOUNTER WITH WEATHER"); refine from findings text.
PRE2008_FINDING_REFINE = [
    ("turbulence", "TURB"), ("windshear", "WSTRW"), ("thunderstorm", "WSTRW"), ("icing", "ICE"),
    ("fuel exhaustion", "FUEL"), ("bird", "BIRD"), ("fire", "F-NI"),
]
