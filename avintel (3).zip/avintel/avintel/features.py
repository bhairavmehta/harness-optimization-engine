"""Feature assembly: canonical records -> wide feature table.

Feature families (prefixes)
---------------------------
meta_*   structured metadata (source, date parts, severity ordinals, FAR part, make family)
txt_*    text statistics / readability / report completeness
occ_*    CICTT occurrence-category lexicon hits (affirmed / negated / uncertain)
ph_*     phase-of-flight hits + first-mentioned phase
ata_*    ATA chapter (system/component) hits
hf_*     human-factors (HFACS-flavoured) hits
wx_*     weather lexicon + METAR-derived quantities
out_*    outcome / response (diversion, RTO, evacuation, ...)
q_*      extracted quantities (altitude, speed, g, distance)
crew_*   crew experience/age
ent_*    entities (airports, runways, registrations, flight numbers)
seq_*    occurrence sequence features (NTSB events_sequence; inferred for others)
lbl_*    NTSB-derived target labels (defining CICTT code)
Optional dense blocks (tfidf / embeddings) are produced separately in vectorize().
"""
from __future__ import annotations

import math
import re
from collections import Counter

import numpy as np
import pandas as pd

from . import extractors, taxonomy
from .normalize import clean, scope_tag, sentences

TEXT_PROFILES = ("notification", "factual", "full")
SEV_INJ = {"NONE": 0, "MINR": 1, "SERS": 2, "FATL": 3}
SEV_DMG = {"NONE": 0, "MINR": 1, "SUBS": 2, "DEST": 3}
PHASE_ORDER = list(taxonomy.PHASE_LEXICON)


def _compile(lex):
    return {k: [re.compile(p, re.I) for p in v] for k, v in lex.items()}


_LEX = {
    "occ": _compile(taxonomy.OCCURRENCE_LEXICON),
    "ph": _compile(taxonomy.PHASE_LEXICON),
    "ata": _compile(taxonomy.ATA_LEXICON),
    "hf": _compile(taxonomy.HF_LEXICON),
    "wx": _compile(taxonomy.WEATHER_LEXICON),
    "out": _compile(taxonomy.OUTCOME_LEXICON),
}


def lexicon_hits(sents: list[str], lex: dict, prefix: str) -> tuple[dict, dict]:
    """Counts of affirmed / negated / uncertain hits per category + first position."""
    aff, neg, unc = Counter(), Counter(), Counter()
    first_pos = {}
    for i, s in enumerate(sents):
        for cat, pats in lex.items():
            for p in pats:
                for m in p.finditer(s):
                    tag = scope_tag(s, m.span())
                    (aff if tag == "aff" else neg if tag == "neg" else unc)[cat] += 1
                    if tag != "neg":
                        first_pos.setdefault(cat, i / max(len(sents), 1))
    out = {}
    for cat in lex:
        key = re.sub(r"[^A-Za-z0-9]+", "_", cat)
        out[f"{prefix}_{key}"] = aff[cat]
        if prefix in ("occ", "ata", "hf"):
            out[f"{prefix}_{key}_neg"] = neg[cat]
            out[f"{prefix}_{key}_unc"] = unc[cat]
    return out, first_pos


def text_stats(text: str, sents: list[str]) -> dict:
    words = re.findall(r"[A-Za-z']+", text)
    nw = len(words)
    syll = sum(max(1, len(re.findall(r"[aeiouy]+", w.lower()))) for w in words)
    fk = 206.835 - 1.015 * (nw / max(len(sents), 1)) - 84.6 * (syll / max(nw, 1)) if nw else None
    return {
        "txt_chars": len(text), "txt_words": nw, "txt_sents": len(sents),
        "txt_flesch": round(fk, 1) if fk is not None else None,
        "txt_digits_ratio": round(sum(c.isdigit() for c in text) / max(len(text), 1), 4),
        "txt_quote_count": text.count('"'),
        "txt_update_markers": len(re.findall(r"\bon [A-Z][a-z]{2} \d{1,2}(st|nd|rd|th) \d{4}\b|\bupdate\b", text, re.I)),
        "txt_has_metar": int(bool(re.search(r"\bMETAR\b|\b\d{6}Z\b", text))),
        "txt_uncertainty_terms": len(re.findall(r"\b(reportedly|unconfirmed|possibly|suspected|alleged)\b", text, re.I)),
    }


def map_defining_to_cictt(desc: str | None) -> str | None:
    if not desc:
        return None
    d = desc.lower()
    for sub, code in taxonomy.NTSB_DEFINING_TO_CICTT:
        if sub in d:
            return code
    return "OTHR"


def model_family(make: str | None, model: str | None) -> str | None:
    s = f"{make or ''} {model or ''}".upper()
    for pat, fam in [(r"737.?(MAX|-?[789]\b|8200|8-200|10\b)", "B737MAX"), (r"MD-?11", "MD-11"),
                     (r"MD-?8[0-9]|MD-?90|DC-?9.?8[0-9]|DC9 8", "MD-80/90"), (r"DC-?9", "DC-9"), (r"DC-?10", "DC-10"),
                     (r"717", "B717"), (r"737", "B737NG/CL"), (r"787", "B787"),
                     (r"777", "B777"), (r"767", "B767"), (r"757", "B757"), (r"747", "B747"),
                     (r"A3[12]\d.*NEO|A32[01]N", "A320neo"), (r"A3[12]\d", "A320ceo"), (r"A33\d", "A330"),
                     (r"A35\d", "A350"), (r"A38\d", "A380"), (r"A22\d|CS[13]00", "A220"),
                     (r"E1[79]\d|ERJ.?1[79]|E2", "E-Jet"), (r"CRJ", "CRJ"), (r"ATR", "ATR"),
                     (r"DHC-?8|DASH|Q[234]00", "Dash8"), (r"CESSNA", "Cessna"), (r"PIPER", "Piper"),
                     (r"BEECH", "Beech"), (r"CIRRUS", "Cirrus"), (r"ROBINSON|BELL|SIKORSKY|AIRBUS HELI|EUROCOPTER", "Rotorcraft")]:
        if re.search(pat, s):
            return fam
    return "OTHER" if s.strip() else None


def era_of(year) -> str | None:
    """NTSB coded by first event before 2008 and by defining event from 2008 (Safety Study SS-21/01)."""
    if year is None or pd.isna(year):
        return None
    return "post2008" if int(year) >= 2008 else "pre2008"


def evidence_text(rec: dict, profile: str = "factual") -> str:
    """Text the model may read at decision time.

    notification : title + first paragraph of the narrative (what is known on day 1)
    factual      : title + full factual narrative           (default; no investigator conclusions)
    full         : + probable cause                         (ANSWER-SIDE: only for leakage measurement)
    """
    if profile not in TEXT_PROFILES:
        raise ValueError(f"profile must be one of {TEXT_PROFILES}")
    rec = {k: (None if isinstance(v, float) and math.isnan(v) else v) for k, v in rec.items()}
    narr = rec.get("narrative") or ""
    if profile == "notification":
        narr = narr.split("\n\n")[0]
    parts = [rec.get("title"), narr]
    if profile == "full":
        parts.append(rec.get("probable_cause"))
    return "\n\n".join(x for x in parts if x)


def build_row(rec: dict, profile: str = "factual") -> dict:
    rec = {k: (None if isinstance(v, float) and math.isnan(v) else v) for k, v in rec.items()}
    text = clean(evidence_text(rec, profile))
    sents = sentences(text)
    row = {"report_id": rec["report_id"], "source": rec["source"]}

    # ---- meta ----
    d = pd.to_datetime(rec.get("event_date"), errors="coerce")
    row.update({
        "meta_year": None if pd.isna(d) else d.year,
        "meta_month": None if pd.isna(d) else d.month,
        "meta_dow": None if pd.isna(d) else d.dayofweek,
        "meta_month_sin": None if pd.isna(d) else math.sin(2 * math.pi * d.month / 12),
        "meta_month_cos": None if pd.isna(d) else math.cos(2 * math.pi * d.month / 12),
        "meta_event_type": (rec.get("event_type") or "").upper() or None,
        "meta_inj_ord": SEV_INJ.get((rec.get("highest_injury") or "").upper()),
        "meta_dmg_ord": SEV_DMG.get((rec.get("damage") or "").upper()),
        "meta_far_part": rec.get("far_part"),
        "meta_commercial": int(str(rec.get("far_part") or "").strip().lstrip("0") in {"121", "125", "129", "135"})
        if rec.get("far_part") else None,
        "meta_era": era_of(None if pd.isna(d) else d.year),
        "meta_post2008": None if pd.isna(d) else int(d.year >= 2008),
        "meta_make": (rec.get("aircraft_make") or "").upper() or None,
        "meta_family": model_family(rec.get("aircraft_make"), rec.get("aircraft_model")),
        "meta_imc": {"IMC": 1, "VMC": 0}.get((rec.get("wx_cond") or "").upper()),
        "meta_night": int((rec.get("light_cond") or "").upper()[:4] in {"NITE", "NIGH", "NDRK", "NBRT"})
        if rec.get("light_cond") else None,
        "meta_country": rec.get("country"),
        "meta_has_cause": int(bool(rec.get("probable_cause"))),
        "meta_n_findings": len(rec.get("findings") or []),
    })
    # ASN structured extras carried as key=value tags
    for tag in rec.get("findings") or []:
        if tag.startswith("asn_"):
            k, _, v = tag.partition("=")
            row[f"meta_{k}"] = v
    if row.get("meta_asn_yom") and row["meta_year"]:
        try:
            row["meta_aircraft_age"] = row["meta_year"] - int(row["meta_asn_yom"])
        except ValueError:
            pass

    # ---- text & lexicons ----
    row.update(text_stats(text, sents))
    first_phase = None
    for prefix, lex in _LEX.items():
        hits, first = lexicon_hits(sents, lex, prefix)
        row.update(hits)
        if prefix == "ph" and first:
            first_phase = min(first, key=first.get)
            last_phase = max(first, key=first.get)
            row["ph_first"] = first_phase
            row["ph_last"] = last_phase
            row["ph_n_distinct"] = len(first)
    row.setdefault("ph_first", None)
    occ_aff = {k: v for k, v in row.items() if k.startswith("occ_") and not k.endswith(("_neg", "_unc"))}
    row["occ_n_categories"] = sum(1 for v in occ_aff.values() if v > 0)
    row["occ_top"] = max(occ_aff, key=occ_aff.get).replace("occ_", "") if any(occ_aff.values()) else None
    row["ata_n_systems"] = sum(1 for k, v in row.items() if k.startswith("ata_") and k[4:6].isdigit() and not k.endswith(("_neg", "_unc")) and v > 0)
    row["hf_any"] = int(any(v > 0 for k, v in row.items() if k.startswith("hf_") and not k.endswith(("_neg", "_unc"))))

    # ---- extracted quantities / entities ----
    row.update(extractors.extract(text))

    # ---- sequence (NTSB) ----
    occs = rec.get("occurrences") or []
    row["seq_len"] = len(occs)
    row["seq_first"] = occs[0] if occs else None
    row["seq_defining"] = rec.get("defining_event")
    row["seq_cictt_chain"] = ">".join(filter(None, (map_defining_to_cictt(o) for o in occs))) or None
    row["seq_defining_pos"] = (occs.index(rec["defining_event"]) / max(len(occs) - 1, 1)
                               if rec.get("defining_event") in occs else None)
    fnd = [f for f in (rec.get("findings") or []) if not f.startswith("asn_")]
    row["seq_findings_personnel"] = sum("personnel" in f.lower() for f in fnd)
    row["seq_findings_aircraft"] = sum("aircraft" in f.lower() for f in fnd)
    row["seq_findings_environment"] = sum("environment" in f.lower() for f in fnd)
    phases = [o.split("-", 1)[0].strip().upper() for o in occs if "-" in o]
    row["seq_phase_chain"] = ">".join(phases) or None
    row["seq_n_phase_transitions"] = sum(1 for a, b in zip(phases, phases[1:]) if a != b)
    di = occs.index(rec["defining_event"]) if rec.get("defining_event") in occs else None
    row["seq_pre_defining"] = occs[di - 1] if di else None

    # ---- labels (era-aware) ----
    row.update(make_labels(rec, row["meta_era"]))
    row["_text"] = text
    return row


def make_labels(rec: dict, era: str | None) -> dict:
    """Primary CICTT label + provenance.

    post-2008 NTSB: defining event (events_sequence.defining_ev)
    pre-2008 NTSB or no defining flag: first coded occurrence (a DIFFERENT label definition;
    keep `lbl_source` and never pool trends across the two without a bridging study)
    lbl_cictt_all: multi-label set over every coded occurrence.
    """
    out = {"lbl_cictt": None, "lbl_source": None, "lbl_cictt_all": None}
    if rec.get("source") != "NTSB":
        return out
    occs = rec.get("occurrences") or []
    if rec.get("defining_event") and era != "pre2008":
        out["lbl_cictt"], out["lbl_source"] = map_defining_to_cictt(rec["defining_event"]), "defining_event"
    elif occs:
        out["lbl_cictt"], out["lbl_source"] = map_defining_to_cictt(occs[0]), "first_occurrence"
        if out["lbl_cictt"] == "OTHR":  # coarse pre-2008 title: refine from cause findings
            ftxt = " ".join(f for f in (rec.get("findings") or []) if not f.startswith("asn_")).lower()
            for sub, code in taxonomy.PRE2008_FINDING_REFINE:
                if sub in ftxt:
                    out["lbl_cictt"], out["lbl_source"] = code, "first_occurrence+findings"
                    break
    codes = sorted({c for c in (map_defining_to_cictt(o) for o in occs) if c})
    out["lbl_cictt_all"] = "|".join(codes) or None
    return out


# Columns derived from investigator conclusions. Never model inputs when the target is a
# CICTT category / cause; usable only for analysis of closed investigations.
ANSWER_PREFIXES = ("lbl_", "seq_", "link_")
ANSWER_COLUMNS = {"meta_has_cause", "meta_n_findings"}


def is_answer_column(c: str) -> bool:
    return c.startswith(ANSWER_PREFIXES) or c in ANSWER_COLUMNS


def build_feature_table(records: pd.DataFrame, profile: str = "factual") -> pd.DataFrame:
    rows = [build_row(r, profile) for r in records.to_dict("records")]
    df = pd.DataFrame(rows)
    # severity composite usable across sources
    df["meta_severity_score"] = (df["meta_inj_ord"].fillna(0) * 2 + df["meta_dmg_ord"].fillna(0)
                                 + (df.get("out_fatality", 0) > 0) * 3 + (df.get("out_hull_loss", 0) > 0) * 2)
    return df


def vectorize(df: pd.DataFrame, max_features: int = 20000, embed_model: str | None = None):
    """Sparse TF-IDF (word 1-2g + char 3-5g) and optional sentence embeddings."""
    from scipy.sparse import hstack
    from sklearn.feature_extraction.text import TfidfVectorizer
    w = TfidfVectorizer(ngram_range=(1, 2), min_df=1, max_features=max_features, sublinear_tf=True, stop_words="english")
    c = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5), min_df=1, max_features=max_features // 2, sublinear_tf=True)
    X = hstack([w.fit_transform(df["_text"]), c.fit_transform(df["_text"])]).tocsr()
    emb = None
    if embed_model:
        from sentence_transformers import SentenceTransformer  # optional dependency
        emb = SentenceTransformer(embed_model).encode(df["_text"].tolist(), normalize_embeddings=True, show_progress_bar=False)
    return X, (w, c), emb


def numeric_columns(df: pd.DataFrame) -> list[str]:
    """Evidence-side numeric features only (answer-side columns excluded)."""
    return [c for c in df.columns if c not in ("report_id", "source", "_text") and not is_answer_column(c)
            and pd.api.types.is_numeric_dtype(df[c])]


def numeric_block(df: pd.DataFrame, cols: list[str] | None = None) -> tuple[np.ndarray, list[str]]:
    cols = cols or numeric_columns(df)
    X = df.reindex(columns=cols).apply(pd.to_numeric, errors="coerce").fillna(0)
    return X.to_numpy(dtype=float), cols


def mine_lexicon(df: pd.DataFrame, label_col: str = "lbl_cictt", top_k: int = 25) -> dict:
    """Discriminative n-grams per label (chi2) — use to grow taxonomy lexicons with SME review."""
    from sklearn.feature_extraction.text import CountVectorizer
    from sklearn.feature_selection import chi2
    d = df[df[label_col].notna()]
    if d[label_col].nunique() < 2:
        return {}
    cv = CountVectorizer(ngram_range=(1, 3), min_df=2, stop_words="english", binary=True)
    X = cv.fit_transform(d["_text"])
    vocab = np.array(cv.get_feature_names_out())
    out = {}
    for lab in sorted(d[label_col].unique()):
        y = (d[label_col] == lab).astype(int)
        if y.sum() == 0:
            continue
        s, _ = chi2(X, y)
        out[lab] = vocab[np.argsort(np.nan_to_num(s))[::-1][:top_k]].tolist()
    return out
