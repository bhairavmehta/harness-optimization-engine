"""Aviation Herald ingestion.

The Aviation Herald (avherald.com) is a privately run site. Before collecting
pages at scale, confirm your organization has permission / a licence and follow
the site's terms and robots.txt. This module therefore works primarily on
*already-saved* HTML (or a CSV/JSONL of title+body) and ships only a polite,
opt-in single-page fetcher.

Headline grammar (highly regular, and the richest structured signal on AvH):

    "<Class>: <Operator> <Aircraft> [<at|near|over|enroute> <Place>] on <Mon> <Dth> <YYYY>, <summary>"
    Class ∈ {Incident, Accident, Crash, Report}
"""
from __future__ import annotations

import hashlib
import json
import re
import time
from pathlib import Path

import pandas as pd
from bs4 import BeautifulSoup

from .schema import CANONICAL_COLUMNS, empty_record

ICAO_TYPES = {  # ICAO type designators used in AvHerald headlines -> (make, model)
    "B788": ("BOEING", "787-8"), "B789": ("BOEING", "787-9"), "B78X": ("BOEING", "787-10"),
    "B37M": ("BOEING", "737 MAX 7"), "B38M": ("BOEING", "737 MAX 8"), "B39M": ("BOEING", "737 MAX 9"),
    "B3XM": ("BOEING", "737 MAX 10"), "B736": ("BOEING", "737-600"), "B737": ("BOEING", "737-700"),
    "B738": ("BOEING", "737-800"), "B739": ("BOEING", "737-900"), "B744": ("BOEING", "747-400"),
    "B748": ("BOEING", "747-8"), "B752": ("BOEING", "757-200"), "B753": ("BOEING", "757-300"),
    "B762": ("BOEING", "767-200"), "B763": ("BOEING", "767-300"), "B764": ("BOEING", "767-400"),
    "B772": ("BOEING", "777-200"), "B77L": ("BOEING", "777-200LR"), "B773": ("BOEING", "777-300"),
    "B77W": ("BOEING", "777-300ER"), "B778": ("BOEING", "777-8"), "B779": ("BOEING", "777-9"),
    "A19N": ("AIRBUS", "A319neo"), "A20N": ("AIRBUS", "A320neo"), "A21N": ("AIRBUS", "A321neo"),
    "A318": ("AIRBUS", "A318"), "A319": ("AIRBUS", "A319"), "A320": ("AIRBUS", "A320"), "A321": ("AIRBUS", "A321"),
    "A332": ("AIRBUS", "A330-200"), "A333": ("AIRBUS", "A330-300"), "A338": ("AIRBUS", "A330-800neo"),
    "A339": ("AIRBUS", "A330-900neo"), "A343": ("AIRBUS", "A340-300"), "A346": ("AIRBUS", "A340-600"),
    "A359": ("AIRBUS", "A350-900"), "A35K": ("AIRBUS", "A350-1000"), "A388": ("AIRBUS", "A380-800"),
    "BCS1": ("AIRBUS", "A220-100"), "BCS3": ("AIRBUS", "A220-300"),
    "E170": ("EMBRAER", "E170"), "E175": ("EMBRAER", "E175"), "E190": ("EMBRAER", "E190"),
    "E195": ("EMBRAER", "E195"), "E290": ("EMBRAER", "E190-E2"), "E295": ("EMBRAER", "E195-E2"),
    "CRJ2": ("BOMBARDIER", "CRJ200"), "CRJ7": ("BOMBARDIER", "CRJ700"), "CRJ9": ("BOMBARDIER", "CRJ900"),
    "CRJX": ("BOMBARDIER", "CRJ1000"), "DH8D": ("DHC", "Dash 8-400"), "AT72": ("ATR", "ATR 72"),
    "AT76": ("ATR", "ATR 72-600"), "AT45": ("ATR", "ATR 42-500"), "MD11": ("BOEING", "MD-11"),
}
_ICAO_TOKEN = "|".join(sorted(ICAO_TYPES, key=len, reverse=True))

_AC_TOKEN = (
    rf"\b(?:{_ICAO_TOKEN})\b|"
    r"(?:Airbus\s+)?A\d{3}(?:-\d{3,4})?(?:neo|NEO)?|A220(?:-\d{3})?|A3[0-8]\d(?:-\d{3,4})?|"
    r"(?:Boeing\s+)?(?:7[0-8]7|B7[0-8]7)(?:-[0-9A-Z]{1,4})?(?:\s?MAX\s?\d*)?|"
    r"Embraer\s+\w+|E-?1[79]\d|E-?[12][79]\d|ERJ-?\d{3}|CRJ-?\d{3,4}|"
    r"(?:ATR|Dash|DHC-8|Q)\s?-?\d{2,3}(?:-\d{3})?|Bombardier\s+\w+|Fokker\s+\d+|"
    r"MD-?\d{2}|Saab\s+\d+|Sukhoi\s+\w+|Comac\s+\w+|C919|ARJ21|A\d{3}"
)

TITLE_RE = re.compile(
    r"^(?P<cls>Incident|Accident|Crash|Report)\s*:\s*"
    r"(?P<who>.+?)\s+"
    r"(?:(?P<prep>at|near|over|enroute|en route|south of|north of|east of|west of)\s+(?P<where>.+?)\s+)?"
    r"on\s+(?P<date>[A-Z][a-z]{2}\s+\d{1,2}(?:st|nd|rd|th)?\s+\d{4})"
    r"\s*,\s*(?P<summary>.+)$",
    re.I,
)
AC_RE = re.compile(rf"(?P<ac>{_AC_TOKEN})", re.I)


def parse_title(title: str) -> dict:
    out = {"event_type": None, "operator": None, "aircraft": None, "location": None,
           "event_date": None, "summary": None}
    m = TITLE_RE.match(title.strip())
    if not m:
        return out
    who = m.group("who")
    acm = AC_RE.search(who)
    if acm:
        out["aircraft"] = acm.group("ac").strip()
        out["operator"] = who[: acm.start()].strip() or None
    else:
        out["operator"] = who
    date = re.sub(r"(st|nd|rd|th)\b", "", m.group("date"))
    d = pd.to_datetime(date, format="%b %d %Y", errors="coerce")
    out.update(
        event_type=m.group("cls").title(),
        location=(m.group("where") or "").strip() or None,
        event_date=None if pd.isna(d) else str(d.date()),
        summary=m.group("summary").strip(),
    )
    return out


REG_RE = re.compile(r"\bregistration\s+([A-Z0-9]{1,2}-?[A-Z0-9]{2,5})\b", re.I)


def parse_article_html(html: str, url: str | None = None) -> dict:
    soup = BeautifulSoup(html, "html.parser")
    for t in soup(["script", "style", "nav", "header", "footer", "form"]):
        t.decompose()
    title = ""
    h = soup.find(["h1", "h2"]) or soup.find("title")
    if h:
        title = h.get_text(" ", strip=True)
    # Body: the largest text-bearing block is robust to template changes.
    blocks = soup.find_all(["div", "td", "article", "span"])
    body = max((b.get_text("\n", strip=True) for b in blocks), key=len, default=soup.get_text("\n", strip=True))
    if title and body.startswith(title):
        body = body[len(title):].strip()
    return _to_record(title, body, url)


def _to_record(title: str, body: str, url: str | None) -> dict:
    t = parse_title(title or "")
    rec = empty_record()
    rid = hashlib.sha1((url or title or body[:200]).encode()).hexdigest()[:12]
    make, model = _split_make_model(t["aircraft"])
    regm = REG_RE.search(body or "")
    rec.update(
        report_id=f"AVH:{rid}", source="AVHERALD", title=title, narrative=body,
        event_type=t["event_type"], operator=t["operator"], location=t["location"],
        event_date=t["event_date"], aircraft_make=make, aircraft_model=model,
        registration=regm.group(1).upper() if regm else None, url=url,
        probable_cause=None,
    )
    rec["highest_injury"] = "FATL" if t["event_type"] == "Crash" else None
    return rec


def _split_make_model(ac: str | None):
    if not ac:
        return None, None
    if ac.upper() in ICAO_TYPES:
        return ICAO_TYPES[ac.upper()]
    a = ac.replace("Boeing", "").replace("Airbus", "").strip()
    if re.match(r"^B?7[0-8]7", a, re.I):
        return "BOEING", re.sub(r"^B", "", a, flags=re.I)
    if re.match(r"^A\d{3}", a, re.I):
        return "AIRBUS", a
    if re.match(r"^(E-?\d|ERJ|Embraer)", a, re.I):
        return "EMBRAER", a.replace("Embraer", "").strip()
    if re.match(r"^CRJ|^Bombardier|^Dash|^DHC|^Q\d", a, re.I):
        return "BOMBARDIER/DHC", a
    if re.match(r"^ATR", a, re.I):
        return "ATR", a
    return None, a


def load_saved_html_dir(path: str | Path) -> pd.DataFrame:
    rows = []
    for f in sorted(Path(path).glob("*.htm*")):
        rows.append(parse_article_html(f.read_text(errors="ignore"), url=f.name))
    return pd.DataFrame(rows, columns=CANONICAL_COLUMNS)


def load_jsonl(path: str | Path) -> pd.DataFrame:
    """JSONL/CSV with at least `title` and `body` (optional `url`)."""
    p = Path(path)
    if p.suffix == ".csv":
        items = pd.read_csv(p, dtype=str).fillna("").to_dict("records")
    else:
        items = [json.loads(l) for l in p.read_text().splitlines() if l.strip()]
    rows = [_to_record(i.get("title", ""), i.get("body", ""), i.get("url")) for i in items]
    return pd.DataFrame(rows, columns=CANONICAL_COLUMNS)


def polite_fetch(urls, out_dir, delay_s: float = 10.0, user_agent: str = "avintel-research (contact: you@org)"):
    """Opt-in fetcher: one request every `delay_s` seconds, caches to disk, skips existing.
    Only use with permission from the site operator."""
    import urllib.request
    out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    for u in urls:
        f = out / (hashlib.sha1(u.encode()).hexdigest()[:12] + ".html")
        if f.exists():
            continue
        req = urllib.request.Request(u, headers={"User-Agent": user_agent})
        with urllib.request.urlopen(req, timeout=30) as r:
            f.write_bytes(r.read())
        time.sleep(delay_s)
