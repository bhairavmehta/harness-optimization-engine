"""Text normalisation tuned for aviation narratives.

- Expands domain abbreviations (so 'TR', 'thrust rev', 'reverser' all hit the
  same lexicon entry) while keeping the original text for audit.
- Sentence-splits and tags each sentence with negation / uncertainty so that
  "no evidence of bird strike" does not fire the BIRD feature.
"""
from __future__ import annotations

import re

ABBREV = {
    r"\bA/?P\b": "autopilot", r"\bA/?T\b": "autothrottle", r"\bATC\b": "air traffic control",
    r"\bAGL\b": "above ground level", r"\bMSL\b": "mean sea level", r"\bAOA\b": "angle of attack",
    r"\bAPU\b": "auxiliary power unit", r"\bCVR\b": "cockpit voice recorder",
    r"\bFDR\b": "flight data recorder", r"\bEGPWS\b": "terrain awareness warning",
    r"\bTAWS\b": "terrain awareness warning", r"\bGPWS\b": "terrain awareness warning",
    r"\bTCAS\b": "traffic collision avoidance", r"\bRA\b": "resolution advisory",
    r"\bFO\b": "first officer", r"\bF/O\b": "first officer", r"\bPIC\b": "pilot in command",
    r"\bPF\b": "pilot flying", r"\bPM\b": "pilot monitoring", r"\bCFI\b": "flight instructor",
    r"\bRTO\b": "rejected takeoff", r"\bG/?A\b": "go around", r"\bTOGA\b": "takeoff go around",
    r"\bIFSD\b": "in flight shutdown", r"\bEICAS\b": "crew alerting", r"\bECAM\b": "crew alerting",
    r"\bT/?R\b": "thrust reverser", r"\bthrust revs?\b": "thrust reverser",
    r"\bMLG\b": "main landing gear", r"\bNLG\b": "nose landing gear", r"\bL/?G\b": "landing gear",
    r"\bRWY\b": "runway", r"\bTWY\b": "taxiway", r"\bILS\b": "instrument landing system",
    r"\bIMC\b": "instrument meteorological conditions", r"\bVMC\b": "visual meteorological conditions",
    r"\bWX\b": "weather", r"\bLLWS\b": "low level windshear", r"\bFOD\b": "foreign object debris",
    r"\bMAYDAY\b": "mayday emergency", r"\bPAN PAN\b": "pan pan urgency",
    r"\bkts?\b": "knots", r"\bft\b": "feet", r"\bnm\b": "nautical miles",
}
_ABBREV_RE = [(re.compile(k, re.I if k.islower() else 0), v) for k, v in ABBREV.items()]

NEG_CUES = r"\b(no|not|without|denied|negative for|none|neither|nor|ruled out|absence of|did not|didn't|was not|were not|no evidence of)\b"
UNC_CUES = r"\b(possibl[ey]|probabl[ey]|may have|might have|suspected|reportedly|unconfirmed|alleged|appears? to|likely|believed)\b"
_NEG = re.compile(NEG_CUES, re.I)
_UNC = re.compile(UNC_CUES, re.I)
_SENT = re.compile(r"(?<=[.!?])\s+(?=[A-Z\"'(])|\n+")


def clean(text: str | None) -> str:
    if not text:
        return ""
    t = text.replace(" ", " ")
    t = re.sub(r"[ \t]+", " ", t)
    for rx, rep in _ABBREV_RE:
        t = rx.sub(rep, t)
    return t.strip()


def sentences(text: str) -> list[str]:
    return [s.strip() for s in _SENT.split(text) if s and s.strip()]


def scope_tag(sentence: str, term_span: tuple[int, int], window_words: int = 6) -> str:
    """Return 'neg', 'unc' or 'aff' for a term occurrence (NegEx-style window)."""
    pre = sentence[: term_span[0]]
    pre_words = pre.split()[-window_words:]
    pre_win = " ".join(pre_words)
    if _NEG.search(pre_win):
        return "neg"
    if _UNC.search(pre_win) or _UNC.search(sentence[term_span[1]: term_span[1] + 40]):
        return "unc"
    return "aff"
