"""End-to-end CLI.

python -m avintel.pipeline \
    --ntsb-dir data/ntsb_csv  [--ntsb-pdf-dir report_pdfs/] [--carol carol.csv] \
    --avh-html data/avh_html  [--avh-jsonl avh.jsonl] \
    --asn-html data/asn_html  [--asn-table asn.csv] \
    --out out/ [--profile factual] [--eval-cutoff-year 2021] [--leakage-check] \
    [--embed-model sentence-transformers/all-MiniLM-L6-v2]

Outputs (in --out):
  records.parquet          canonical records from every source
  features.parquet         engineered features (one row per report)
  feature_dictionary.csv   column -> family, evidence/answer side, dtype, coverage
  weak_labels.csv          labeling-function votes + combined weak label
  lf_report.csv            coverage / accuracy of each labeling function vs NTSB gold
  links.csv                cross-source record pairs with component scores
  predictions.parquet      calibrated class probabilities, review flag
  evaluation.json          temporal grouped evaluation (+ profile leakage check)
  lexicon_suggestions.json chi2 n-grams per class for SME lexicon review
  top_terms.json           strongest n-grams per class from the fitted model
  reports_features.csv     ONE ROW PER REPORT: fields, model-input text, NTSB conclusions, all features,
                           weak labels, predictions, linked reports, PDF fields (skip with --no-csv)
  reports_features_columns.csv  column guide: group and side (evidence / answer / derived / output)
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from . import evaluate as ev
from . import features, ingest_asn, ingest_avherald, ingest_ntsb, ingest_ntsb_pdf, labeling, linking
from .classify import OccurrenceClassifier, training_labels


def load_all(a) -> pd.DataFrame:
    parts = []
    for d in a.ntsb_dir or []: parts.append(ingest_ntsb.load_avall_csv_dir(d))
    if a.carol: parts.append(ingest_ntsb.load_carol(a.carol))
    if getattr(a, "ntsb_pdf_dir", None):
        r, f = ingest_ntsb_pdf.load_pdf_dir(a.ntsb_pdf_dir)
        parts.append(r)
        Path(a.out).mkdir(parents=True, exist_ok=True)
        f.to_csv(Path(a.out) / "pdf_fields.csv", index=False)
    for d in a.avh_html or []: parts.append(ingest_avherald.load_saved_html_dir(d))
    if a.avh_jsonl: parts.append(ingest_avherald.load_jsonl(a.avh_jsonl))
    for d in a.asn_html or []: parts.append(ingest_asn.load_saved_html_dir(d))
    if a.asn_table: parts.append(ingest_asn.load_table(a.asn_table))
    if not parts:
        raise SystemExit("no inputs given")
    recs = pd.concat(parts, ignore_index=True)
    return recs.drop_duplicates("report_id").reset_index(drop=True)


def build(recs: pd.DataFrame, profile: str):
    """Features + weak labels + linkage for one text profile."""
    feats = features.build_feature_table(recs, profile=profile)
    votes = labeling.apply_lfs(feats)
    lf_rep = labeling.lf_report(votes, feats["lbl_cictt"])
    w = {r.lf: r.accuracy for r in lf_rep.itertuples() if pd.notna(r.accuracy)}
    weak = labeling.combine(votes, w or None)

    links = linking.link(recs, feats)
    cl = linking.clusters(links, feats["report_id"])
    feats["link_cluster"] = feats["report_id"].map(cl)
    feats["link_n_sources"] = feats.groupby("link_cluster")["source"].transform("nunique")
    gold = feats.dropna(subset=["lbl_cictt"]).groupby("link_cluster")["lbl_cictt"].first()
    feats["lbl_linked"] = feats["link_cluster"].map(gold)
    return feats, votes, weak, lf_rep, links


def feature_dictionary(feats: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for c in feats.columns:
        if c == "_text":
            continue
        rows.append({"column": c, "family": c.split("_")[0], "side": "answer" if features.is_answer_column(c) else "evidence",
                     "dtype": str(feats[c].dtype), "coverage": round(float(feats[c].notna().mean()), 3),
                     "nonzero": round(float((pd.to_numeric(feats[c], errors="coerce").fillna(0) != 0).mean()), 3)
                     if pd.api.types.is_numeric_dtype(feats[c]) else None})
    return pd.DataFrame(rows)


def run(a):
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    recs = load_all(a)
    feats, votes, weak, lf_rep, links = build(recs, a.profile)
    y, origin = training_labels(feats, weak)

    clf_kw = dict(embed_model=a.embed_model)
    evaluation = {"profile": a.profile, a.profile: ev.evaluate(feats, y, a.eval_cutoff_year, **clf_kw)}
    if a.leakage_check:
        for p in features.TEXT_PROFILES:
            if p == a.profile:
                continue
            f2, _, w2, _, _ = build(recs, p)
            y2, _ = training_labels(f2, w2)
            evaluation[p] = ev.evaluate(f2, y2, a.eval_cutoff_year, **clf_kw)
        if "full" in evaluation and "factual" in evaluation and "macro_f1" in evaluation["full"]:
            evaluation["leakage_gap_macro_f1"] = round(evaluation["full"]["macro_f1"] - evaluation["factual"].get("macro_f1", 0), 4)

    # production model: all labeled rows
    pred = pd.DataFrame(index=feats.index)
    top = {}
    try:
        clf = OccurrenceClassifier(**clf_kw).fit(feats[y.notna()], y[y.notna()])
        pred = clf.predict_proba(feats)
        pred["pred_in_sample"] = y.notna().to_numpy()
        top = clf.top_terms()
        evaluation["by_era"] = ev.stratified_report(feats, pred, "meta_era").to_dict("records")
        evaluation["by_source"] = ev.stratified_report(feats, pred, "source").to_dict("records")
    except ValueError as e:
        evaluation["production_model"] = str(e)
    evaluation["label_origin_counts"] = origin.value_counts(dropna=False).rename(str).to_dict()

    recs.to_parquet(out / "records.parquet")
    feats.drop(columns=["_text"]).to_parquet(out / "features.parquet")
    feature_dictionary(feats).to_csv(out / "feature_dictionary.csv", index=False)
    pd.concat([feats[["report_id"]], votes, weak], axis=1).to_csv(out / "weak_labels.csv", index=False)
    lf_rep.to_csv(out / "lf_report.csv", index=False)
    links.to_csv(out / "links.csv", index=False)
    pd.concat([feats[["report_id", "source", "lbl_cictt", "lbl_linked"]], pred], axis=1).to_parquet(out / "predictions.parquet")
    (out / "evaluation.json").write_text(json.dumps(evaluation, indent=1, default=str))
    (out / "lexicon_suggestions.json").write_text(json.dumps(features.mine_lexicon(feats), indent=1))
    (out / "top_terms.json").write_text(json.dumps(top, indent=1))
    if not a.no_csv:  # one flat row per report: fields, text, NTSB conclusions, features, labels, predictions, links
        from .export_csv import build_frame, column_guide, order_columns
        flat = build_frame(out, a.dataset_label or out.name)
        flat = flat[order_columns(list(flat.columns))]
        flat.to_csv(out / "reports_features.csv", index=False, encoding="utf-8-sig")
        column_guide(flat).to_csv(out / "reports_features_columns.csv", index=False, encoding="utf-8-sig")
    print(f"records={len(recs)} feature_cols={feats.shape[1] - 1} links={len(links)} "
          f"labels={origin.value_counts().to_dict()} -> {out}")
    return recs, feats, pred, links, evaluation


def main(argv=None):
    p = argparse.ArgumentParser(description="Feature engineering for NTSB / AvHerald / ASN reports")
    for k in ("ntsb-dir", "avh-html", "asn-html"):
        p.add_argument(f"--{k}", nargs="+", help="one or more directories")
    for k in ("ntsb-pdf-dir", "carol", "avh-jsonl", "asn-table", "embed-model"):
        p.add_argument(f"--{k}")
    p.add_argument("--out", default="out")
    p.add_argument("--profile", default="factual", choices=features.TEXT_PROFILES,
                   help="text the model may read; 'full' adds probable cause (leaky)")
    p.add_argument("--eval-cutoff-year", type=int, default=None, help="train <= year, test > year (default: 75th pct)")
    p.add_argument("--leakage-check", action="store_true", help="also evaluate the other text profiles")
    p.add_argument("--no-csv", action="store_true", help="do not write reports_features.csv")
    p.add_argument("--dataset-label", default=None, help="value of the 'dataset' column in reports_features.csv")
    run(p.parse_args(argv))


if __name__ == "__main__":
    main()
