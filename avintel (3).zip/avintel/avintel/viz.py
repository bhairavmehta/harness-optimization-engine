"""Interactive HTML viewer for engineered features.

python -m avintel.viz --out out/ --html out/feature_viewer.html

Reads the pipeline outputs (records.parquet, features.parquet, predictions.parquet,
links.csv), re-derives the character spans behind every lexicon / quantity / entity
feature, and writes ONE self-contained HTML page: narrative with highlighted spans
(affirmed / negated / uncertain), feature panel by family, calibrated predictions and
cross-source links.
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

import numpy as np
import pandas as pd

from . import extractors, taxonomy
from .features import evidence_text
from .normalize import _SENT, clean, scope_tag

FAMILY_LEX = {
    "occ": taxonomy.OCCURRENCE_LEXICON, "ph": taxonomy.PHASE_LEXICON, "ata": taxonomy.ATA_LEXICON,
    "hf": taxonomy.HF_LEXICON, "wx": taxonomy.WEATHER_LEXICON, "out": taxonomy.OUTCOME_LEXICON,
}
QUANT_RX = {
    "altitude": extractors.ALT_RE, "flight level": extractors.FL_RE, "speed": extractors.SPD_RE,
    "vertical speed": extractors.VSPD_RE, "distance": extractors.NM_RE, "g-load": extractors.G_RE,
    "crew hours": extractors.HOURS_RE, "age": extractors.AGE_RE, "people on board": extractors.POB_RE,
    "METAR wind": extractors.WIND_RE, "METAR visibility": extractors.VIS_RE, "METAR ceiling": extractors.CEIL_RE,
}
ENT_RX = {"airport": extractors.ICAO_APT_RE, "runway": extractors.RWY_RE,
          "registration": extractors.REG_N_RE, "flight number": extractors.FLIGHT_NO_RE}


def _sentence_bounds(text: str):
    bounds, start = [], 0
    for m in _SENT.finditer(text):
        bounds.append((start, m.start())); start = m.end()
    bounds.append((start, len(text)))
    return bounds


def spans_for(text: str) -> list[dict]:
    spans = []
    sb = _sentence_bounds(text)

    def sent_of(pos):
        for a, b in sb:
            if a <= pos <= b:
                return a, b
        return 0, len(text)

    for fam, lex in FAMILY_LEX.items():
        for cat, pats in lex.items():
            for p in pats:
                for m in re.finditer(p, text, re.I):
                    if m.end() == m.start():
                        continue
                    a, b = sent_of(m.start())
                    tag = scope_tag(text[a:b], (m.start() - a, m.end() - a))
                    spans.append({"s": m.start(), "e": m.end(), "fam": fam, "cat": cat, "tag": tag})
    for cat, rx in QUANT_RX.items():
        for m in rx.finditer(text):
            spans.append({"s": m.start(), "e": m.end(), "fam": "q", "cat": cat, "tag": "aff"})
    for cat, rx in ENT_RX.items():
        for m in rx.finditer(text):
            spans.append({"s": m.start(), "e": m.end(), "fam": "ent", "cat": cat, "tag": "aff"})
    # resolve overlaps: longer spans win, then family priority
    prio = {"occ": 0, "ata": 1, "hf": 2, "out": 3, "wx": 4, "ph": 5, "q": 6, "ent": 7}
    spans.sort(key=lambda s: (-(s["e"] - s["s"]), prio[s["fam"]]))
    owner = np.full(len(text) + 1, -1)
    out = []
    for s in spans:
        hit = owner[s["s"]:s["e"]]
        if (hit < 0).all():
            owner[s["s"]:s["e"]] = len(out)
            s["also"] = []
            out.append(s)
        else:  # overlapping evidence: attach to the span that owns most of it
            k = int(np.bincount(hit[hit >= 0]).argmax())
            if not any(a["fam"] == s["fam"] and a["cat"] == s["cat"] for a in [out[k]] + out[k]["also"]):
                out[k]["also"].append({"fam": s["fam"], "cat": s["cat"], "tag": s["tag"]})
    return sorted(out, key=lambda s: s["s"])


def featOf_py(s: dict) -> str:
    """Feature column fed by a span (lexicon families only)."""
    if s["fam"] in ("q", "ent"):
        return ""
    return f"{s['fam']}_{re.sub(r'[^A-Za-z0-9]+', '_', s['cat'])}" + ("" if s["tag"] == "aff" else f"_{s['tag']}")


def _jsonable(v):
    if v is None or (isinstance(v, float) and np.isnan(v)):
        return None
    if isinstance(v, (np.integer,)):
        return int(v)
    if isinstance(v, (np.floating,)):
        return round(float(v), 4)
    if isinstance(v, (np.bool_,)):
        return bool(v)
    return v


def build_payload(out_dir: Path, profile: str = "factual", families: list[str] | None = None, note: str | None = None) -> dict:
    recs = pd.read_parquet(out_dir / "records.parquet")
    feats = pd.read_parquet(out_dir / "features.parquet")
    preds = pd.read_parquet(out_dir / "predictions.parquet")
    links = pd.read_csv(out_dir / "links.csv") if (out_dir / "links.csv").exists() else pd.DataFrame()
    fdict = pd.read_csv(out_dir / "feature_dictionary.csv") if (out_dir / "feature_dictionary.csv").exists() else None
    ev = json.loads((out_dir / "evaluation.json").read_text()) if (out_dir / "evaluation.json").exists() else {}

    weak = {}
    if (out_dir / "weak_labels.csv").exists():
        wl = pd.read_csv(out_dir / "weak_labels.csv")
        weak = {r.report_id: (r.weak_label, float(r.weak_conf)) for r in wl.itertuples() if pd.notna(r.weak_label)}
    pcols = [c for c in preds.columns if c.startswith("p_")]
    recs = recs.set_index("report_id")
    preds = preds.set_index("report_id")
    reports = []
    if families:
        feats = feats[feats["meta_family"].isin(families)]
    keep_ids = set(feats["report_id"])
    if len(links):
        links = links[links.id_a.isin(keep_ids) & links.id_b.isin(keep_ids)]
    for row in feats.to_dict("records"):
        rid = row["report_id"]
        rec = recs.loc[rid].to_dict()
        rec["report_id"] = rid
        for k in ("occurrences", "findings"):
            v = rec.get(k)
            rec[k] = list(v) if v is not None and not isinstance(v, float) else []
        text = clean(evidence_text(rec, profile))
        feat_vals = {}
        for k, v in row.items():
            v = _jsonable(v)
            if k in ("report_id", "source") or v in (None, 0, "", False):
                continue
            feat_vals[k] = v
        pr = preds.loc[rid] if rid in preds.index else None
        lk = []
        if len(links):
            for l in links[(links.id_a == rid) | (links.id_b == rid)].to_dict("records"):
                lk.append({"other": l["id_b"] if l["id_a"] == rid else l["id_a"],
                           **{k: _jsonable(l[k]) for k in ("score", "s_reg", "s_family", "s_loc", "s_text")}})
        reports.append({
            "id": rid, "source": row["source"], "title": rec.get("title") or rid,
            "family": row.get("meta_family"), "dataset": None,
            "has_narrative": bool(rec.get("narrative")) and not (isinstance(rec.get("narrative"), float)),
            "date": rec.get("event_date"), "make": rec.get("aircraft_make"), "model": rec.get("aircraft_model"),
            "registration": rec.get("registration"), "location": rec.get("location"),
            "text": text, "spans": spans_for(text), "features": feat_vals,
            "probable_cause": rec.get("probable_cause"), "occurrences": rec["occurrences"],
            "pred": None if pr is None else {
                "probs": {c[2:]: _jsonable(pr[c]) for c in pcols if pd.notna(pr[c])},
                "top": pr.get("pred_cictt"), "conf": _jsonable(pr.get("pred_conf")),
                "margin": _jsonable(pr.get("pred_margin")), "review": _jsonable(pr.get("needs_review")),
                "in_sample": _jsonable(pr.get("pred_in_sample"))},
            "links": lk,
            "weak": None if rid not in weak else {"label": weak[rid][0], "conf": round(weak[rid][1], 3)},
        })
    side = {} if fdict is None else dict(zip(fdict["column"], fdict["side"]))
    return {"reports": reports, "side": side, "n_features": int(feats.shape[1] - 2), "families": families or [], "note": note,
            "evaluation": {k: ev.get(k) for k in ("profile", "leakage_gap_macro_f1")} |
                          {p: {kk: ev[p].get(kk) for kk in ("macro_f1", "baseline_lexicon_macro_f1",
                                                              "baseline_majority_macro_f1", "n_train", "n_test", "cutoff_year")}
                           for p in ("notification", "factual", "full") if isinstance(ev.get(p), dict)}}


def merge_payloads(parts: list[tuple[str, dict]], note: str | None = None, families=None) -> dict:
    """Combine several pipeline runs (each keeps its own model, labels and links) into one viewer."""
    reports, side = [], {}
    for label, pl in parts:
        for r in pl["reports"]:
            r["dataset"] = label
            reports.append(r)
        side.update(pl["side"])
    evaluation = parts[0][1]["evaluation"] if len(parts) == 1 else {}
    return {"reports": reports, "side": side, "n_features": max(pl["n_features"] for _, pl in parts),
            "families": families or [], "note": note, "evaluation": evaluation,
            "datasets": [label for label, _ in parts]}


def write_html(payload: dict, path: Path, template: Path | None = None):
    template = template or Path(__file__).with_name("viewer_template.html")
    html = template.read_text().replace("/*__DATA__*/null", json.dumps(payload, default=str).replace("</", "<\\/"))
    path.write_text(html)
    return path


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument("--out", default="out", help="pipeline output directory")
    p.add_argument("--run", action="append", default=[],
                   help="extra run as DIR=Label (repeatable); combines several pipeline outputs in one viewer")
    p.add_argument("--label", default=None, help="dataset label for --out when combining runs")
    p.add_argument("--html", default=None)
    p.add_argument("--profile", default="factual")
    p.add_argument("--families", default=None,
                   help="comma-separated meta_family filter, e.g. B737MAX,B777,B787")
    p.add_argument("--note", default=None, help="banner text shown under the title")
    a = p.parse_args(argv)
    out = Path(a.out)
    dest = Path(a.html) if a.html else out / "feature_viewer.html"
    fams = [x.strip() for x in a.families.split(",")] if a.families else None
    if a.run:
        parts = [(a.label or out.name, build_payload(out, a.profile, fams))]
        for spec in a.run:
            d, _, lab = spec.partition("=")
            parts.append((lab or Path(d).name, build_payload(Path(d), a.profile, fams)))
        payload = merge_payloads(parts, a.note, fams)
    else:
        payload = build_payload(out, a.profile, fams, a.note)
        payload["datasets"] = []
    from .bucket_docs import bucket_docs
    payload["buckets"] = bucket_docs()
    # newest first; reports with a narrative before text-less ones of the same date
    payload["reports"].sort(key=lambda r: (r.get("date") or "", bool(r.get("text"))), reverse=True)
    write_html(payload, dest)
    print("viewer ->", dest)


if __name__ == "__main__":
    main()
