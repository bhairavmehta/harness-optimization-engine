"""NTSB ingestion.

Supported inputs
----------------
1. A directory of CSVs exported from the NTSB `avall.mdb` (or `PRE1982`/monthly
   `upYYMMDD.mdb`) Access databases. Export with mdbtools:

       for t in events aircraft narratives events_sequence Findings; do
           mdb-export avall.mdb "$t" > ntsb_csv/$t.csv
       done

2. A CAROL bulk export (CSV or JSON) — columns are mapped through CAROL_MAP.

Column names in the Access tables are case-inconsistent across releases, so all
headers are lower-cased on load.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

import pandas as pd

from .schema import CANONICAL_COLUMNS, empty_record


def _read(dir_: Path, name: str) -> pd.DataFrame | None:
    for cand in dir_.glob("*.csv"):
        if cand.stem.lower() == name.lower():
            df = pd.read_csv(cand, dtype=str, keep_default_na=False, low_memory=False)
            df.columns = [c.strip().lower() for c in df.columns]
            return df.replace({"": None})
    return None


def _first(series_or_none, default=None):
    if series_or_none is None or len(series_or_none) == 0:
        return default
    v = series_or_none.iloc[0]
    return default if pd.isna(v) else v


def load_avall_csv_dir(path: str | Path) -> pd.DataFrame:
    """Join the core avall tables into one canonical row per (event, aircraft)."""
    d = Path(path)
    events = _read(d, "events")
    if events is None:
        raise FileNotFoundError(f"events.csv not found in {d}")
    aircraft = _read(d, "aircraft")
    narr = _read(d, "narratives")
    seq = _read(d, "events_sequence")
    findings = _read(d, "findings")

    # index helpers
    def by_key(df):
        if df is None:
            return {}
        key_cols = ["ev_id", "aircraft_key"] if "aircraft_key" in df.columns else ["ev_id"]
        return {k: g for k, g in df.groupby(key_cols if len(key_cols) > 1 else key_cols[0])}

    if seq is not None and {"eventsoe_no", "occurrence_description"} <= set(seq.columns):
        seq = seq.copy()
        seq["occurrence_description"] = _split_phase_event(seq)
    ac_idx, narr_idx, seq_idx, fnd_idx = map(by_key, (aircraft, narr, seq, findings))

    rows = []
    ac_iter = (
        aircraft[["ev_id", "aircraft_key"]].drop_duplicates().itertuples(index=False)
        if aircraft is not None
        else ((e, "1") for e in events["ev_id"])
    )
    ev_by_id = events.set_index("ev_id")

    for ev_id, ac_key in ac_iter:
        if ev_id not in ev_by_id.index:
            continue
        ev = ev_by_id.loc[ev_id]
        if isinstance(ev, pd.DataFrame):
            ev = ev.iloc[0]
        k = (ev_id, ac_key)
        ac = ac_idx.get(k)
        nr = narr_idx.get(k)
        sq = seq_idx.get(k)
        fd = fnd_idx.get(k)

        rec = empty_record()
        rec.update(
            report_id=f"NTSB:{ev_id}:{ac_key}",
            source="NTSB",
            event_date=str(pd.to_datetime(ev.get("ev_date"), errors="coerce").date())
            if ev.get("ev_date") else None,
            event_type=ev.get("ev_type"),
            location=", ".join(x for x in [ev.get("ev_city"), ev.get("ev_state")] if x),
            country=ev.get("ev_country"),
            highest_injury=ev.get("ev_highest_injury"),
            wx_cond=ev.get("wx_cond_basic"),
            light_cond=ev.get("light_cond"),
        )
        if ac is not None:
            rec.update(
                registration=_first(ac.get("regis_no")),
                aircraft_make=_first(ac.get("acft_make")),
                aircraft_model=_model_with_series(_first(ac.get("acft_model")), _first(ac.get("acft_series"))),
                far_part=_first(ac.get("far_part")),
                damage=_first(ac.get("damage")),
                operator=_first(ac.get("oper_name")) if "oper_name" in ac else None,
            )
        if nr is not None:
            parts = [_first(nr.get(c), "") for c in ("narr_accp", "narr_accf", "narr_inc")]
            rec["narrative"] = "\n\n".join(p for p in parts if p).strip() or None
            rec["probable_cause"] = _first(nr.get("narr_cause"))
        if sq is not None:
            sq = sq.copy()
            if "occurrence_no" in sq:
                sq["_o"] = pd.to_numeric(sq["occurrence_no"], errors="coerce")
                sq = sq.sort_values("_o")
            desc_col = next((c for c in ("occurrence_description", "occurrence_code") if c in sq), None)
            if desc_col:
                rec["occurrences"] = [x for x in sq[desc_col].tolist() if x]
                if "defining_ev" in sq:
                    de = sq[sq["defining_ev"].astype(str).isin(["1", "True", "true", "Y"])]
                    rec["defining_event"] = _first(de[desc_col]) if len(de) else None
        if fd is not None and "finding_description" in fd:
            rec["findings"] = [x for x in fd["finding_description"].tolist() if x]

        rec["title"] = _synth_title(rec)
        rows.append(rec)

    return pd.DataFrame(rows, columns=CANONICAL_COLUMNS)


# CAROL export column names -> canonical
CAROL_MAP = {
    "NtsbNo": "ntsb_no", "EventDate": "event_date", "EventType": "event_type",
    "City": "city", "State": "state", "Country": "country",
    "HighestInjuryLevel": "highest_injury", "AirCraftDamage": "damage",
    "RegistrationNumber": "registration", "Make": "aircraft_make", "Model": "aircraft_model",
    "Operator": "operator", "FAR": "far_part", "WeatherCondition": "wx_cond",
    "ProbableCause": "probable_cause", "AnalysisNarrative": "narrative",
    "FactualNarrative": "narrative_f", "DefiningEvent": "defining_event",
}


def load_carol(path: str | Path) -> pd.DataFrame:
    p = Path(path)
    if p.suffix.lower() == ".json":
        raw = pd.json_normalize(json.loads(p.read_text()))
    else:
        raw = pd.read_csv(p, dtype=str, keep_default_na=False).replace({"": None})
    raw = raw.rename(columns={k: v for k, v in CAROL_MAP.items() if k in raw.columns})
    rows = []
    for r in raw.to_dict("records"):
        rec = empty_record()
        for c in CANONICAL_COLUMNS:
            if c in r and r[c] is not None:
                rec[c] = r[c]
        rec["narrative"] = "\n\n".join(x for x in [r.get("narrative_f"), r.get("narrative")] if x) or None
        rec["report_id"] = f"NTSB:{r.get('ntsb_no')}"
        rec["source"] = "NTSB"
        rec["location"] = ", ".join(x for x in [r.get("city"), r.get("state")] if x)
        if rec["event_date"]:
            rec["event_date"] = str(pd.to_datetime(rec["event_date"], errors="coerce").date())
        rec["title"] = _synth_title(rec)
        rows.append(rec)
    return pd.DataFrame(rows, columns=CANONICAL_COLUMNS)


def _model_with_series(model, series):
    """'737' + series '8' -> '737-8' (a 737 MAX 8); keep the model alone when it already carries the series."""
    if not model:
        return model
    m, sr = str(model).strip(), str(series or "").strip()
    if not sr or sr.upper() in m.upper().replace(" ", "").replace("-", ""):
        return m
    return f"{m}-{sr}" if re.fullmatch(r"[A-Z]?\d{3}", m.upper()) else f"{m} {sr}"


def _split_phase_event(seq: pd.DataFrame) -> pd.Series:
    """Post-2008 occurrence_description is '<phase> <event>' with no separator ('Taxi-from runway Sys/Comp
    malf/fail (non-power)'). The event text is the part shared by every row with the same eventsoe_no, so
    take the longest common word suffix per event code and rebuild '<phase>-<event>'."""
    desc = seq["occurrence_description"].fillna("")
    ev_text = {}
    for code, g in desc.groupby(seq["eventsoe_no"]):
        words = [d.split() for d in g.unique() if d]
        if len(words) < 2:
            continue
        suf = words[0]
        for w in words[1:]:
            k = 0
            while k < min(len(suf), len(w)) and suf[-1 - k] == w[-1 - k]:
                k += 1
            suf = suf[len(suf) - k:]
        if suf:
            ev_text[code] = " ".join(suf)
    out = []
    for d, code in zip(desc, seq["eventsoe_no"]):
        ev = ev_text.get(code)
        if ev and d.endswith(ev) and len(d) > len(ev):
            out.append(f"{d[:-len(ev)].strip()}-{ev}")
        else:
            out.append(d)
    return pd.Series(out, index=seq.index)


def _synth_title(rec: dict) -> str:
    bits = [rec.get("event_type") or "", f"{rec.get('aircraft_make') or ''} {rec.get('aircraft_model') or ''}".strip()]
    if rec.get("location"):
        bits.append(f"at {rec['location']}")
    if rec.get("event_date"):
        bits.append(f"on {rec['event_date']}")
    # NOTE: the defining event is deliberately NOT put in the title: it is the label.
    return " ".join(b for b in bits if b)
