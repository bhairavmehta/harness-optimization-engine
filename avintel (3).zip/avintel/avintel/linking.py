"""Cross-source record linkage (NTSB <-> AvHerald <-> ASN).

Blocking on date window, scoring on registration, aircraft family, location
tokens and narrative similarity. Linked clusters let you (a) propagate NTSB
ground-truth labels to media reports, (b) dedupe event counts, and (c) build
'time-to-final-report' and 'media vs. investigation divergence' features.
"""
from __future__ import annotations

import re

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer


def _tok(s):
    return set(re.findall(r"[a-z]{3,}", (s or "").lower()))


def link(records: pd.DataFrame, feats: pd.DataFrame, day_window: int = 3, threshold: float = 0.55) -> pd.DataFrame:
    r = records.merge(feats[["report_id", "meta_family", "_text"]], on="report_id")
    r["_d"] = pd.to_datetime(r["event_date"], errors="coerce")
    tf = TfidfVectorizer(stop_words="english", min_df=1).fit(r["_text"])
    V = tf.transform(r["_text"])
    out = []
    idx = r.index.tolist()
    for i in idx:
        for j in idx:
            if j <= i or r.at[i, "source"] == r.at[j, "source"]:
                continue
            di, dj = r.at[i, "_d"], r.at[j, "_d"]
            if pd.isna(di) or pd.isna(dj) or abs((di - dj).days) > day_window:
                continue
            reg_i, reg_j = (r.at[i, "registration"] or "").replace("-", ""), (r.at[j, "registration"] or "").replace("-", "")
            s_reg = 1.0 if reg_i and reg_i == reg_j else 0.0
            s_fam = 1.0 if r.at[i, "meta_family"] and r.at[i, "meta_family"] == r.at[j, "meta_family"] else 0.0
            li, lj = _tok(r.at[i, "location"]), _tok(r.at[j, "location"])
            s_loc = len(li & lj) / max(len(li | lj), 1)
            s_txt = float((V[i] @ V[j].T).toarray()[0, 0])
            s_day = 1 - abs((di - dj).days) / (day_window + 1)
            score = 0.45 * s_reg + 0.15 * s_fam + 0.15 * s_loc + 0.15 * s_txt + 0.10 * s_day
            if score >= threshold or s_reg == 1.0:
                out.append({"id_a": r.at[i, "report_id"], "id_b": r.at[j, "report_id"], "score": round(score, 3),
                            "s_reg": s_reg, "s_family": s_fam, "s_loc": round(s_loc, 2), "s_text": round(s_txt, 2)})
    return pd.DataFrame(out, columns=["id_a", "id_b", "score", "s_reg", "s_family", "s_loc", "s_text"])


def clusters(links: pd.DataFrame, ids) -> dict:
    parent = {i: i for i in ids}

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]; x = parent[x]
        return x
    for a, b in links[["id_a", "id_b"]].itertuples(index=False):
        parent[find(a)] = find(b)
    return {i: find(i) for i in ids}
