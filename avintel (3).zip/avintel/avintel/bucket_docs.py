"""Explanations of every feature bucket, assembled from the code that computes it.

Rules (lexicon patterns, regexes, crosswalks) are read from taxonomy.py / extractors.py at
build time, so the viewer's "How each bucket works" tabs can never drift from the code.
"""
from __future__ import annotations

from . import extractors, labeling, taxonomy
from .normalize import ABBREV, NEG_CUES, UNC_CUES


def _lex(d):
    return [{"name": k, "patterns": v} for k, v in d.items()]


def _rx(pairs):
    return [{"name": n, "patterns": [r.pattern]} for n, r in pairs]


SCOPE_STEP = ("Each match is checked for scope: a negation cue in the six words before it (for example "
              "<i>no</i>, <i>not</i>, <i>without</i>, <i>no evidence of</i>, <i>ruled out</i>) marks it negated; a hedge before it or "
              "within 40 characters after it (<i>possibly</i>, <i>reportedly</i>, <i>suspected</i>, <i>likely</i>) marks it uncertain.")
LEX_STEPS = [
    "Build the evidence text: the title and factual narrative only. The probable cause is never read.",
    f"Expand {len(ABBREV)} aviation abbreviations so variants hit the same rule (T/R and thrust rev become thrust reverser; RTO becomes rejected takeoff).",
    "Split into sentences, then run every regular expression in the rule table against each sentence, case-insensitive.",
    SCOPE_STEP,
    "Count stated, negated and uncertain matches separately for every category, so the model can tell “fire” from “no fire” and “possible fire”.",
]


def bucket_docs() -> list[dict]:
    return [
        {
            "id": "meta", "fam": None, "name": "Report details", "prefix": "meta_*",
            "purpose": "Structured facts about the event, the aircraft and the operation, read from coded fields rather than from the narrative.",
            "source": "features.build_row (meta block), features.model_family, ingest_* modules",
            "steps": [
                "Every source is first mapped onto one 22-column record (date, operator, registration, make, model, FAR part, injury, damage, weather, light, narrative, cause, coded events, findings).",
                "Dates become year, month, day of week, and month as sine and cosine so December and January sit next to each other.",
                "Highest injury becomes an ordinal 0–3 (none, minor, serious, fatal); damage becomes 0–3 (none, minor, substantial, destroyed).",
                "FAR part gives a commercial flag for Parts 121, 125, 129 and 135. Weather becomes an IMC flag and light code a night flag.",
                "Make and model are mapped to an aircraft family (737 MAX, 737 NG/Classic, 777, 787, MD-11, MD-80/90, DC-9, A320ceo/neo …) by an ordered regex table.",
                "Event year assigns the NTSB coding era: before 2008 NTSB coded the first event, from 2008 the defining event.",
                "ASN fact-table fields (phase, nature, airports, year built, occupants) are carried over; aircraft age is event year minus year built.",
                "A cross-source severity score adds 2 × injury level, damage level, 3 if fatality words appear and 2 if hull-loss words appear.",
            ],
            "rules": [{"name": "Aircraft family table", "patterns": [
                r"737.?(MAX|-[789]\b|8\b|9\b) → 737 MAX", r"MD-?11 → MD-11", r"MD-?8x | MD-90 | DC-9-8x → MD-80/90",
                r"DC-?9 → DC-9", r"737 → 737 NG/Classic", r"787 → 787", r"777 → 777", r"A3[12]x neo → A320neo", r"…"]}],
            "caveats": [
                "meta_has_cause and meta_n_findings come from NTSB's conclusions; they are kept for analysis but excluded from the model.",
                "Injury and damage come from coded fields; AvHerald reports usually lack them, so severity there leans on outcome words.",
            ],
        },
        {
            "id": "txt", "fam": None, "name": "Text statistics", "prefix": "txt_*",
            "purpose": "How much the report says and how it says it: length, readability and signals of an early or uncertain report.",
            "source": "features.text_stats",
            "steps": [
                "Count characters, words and sentences of the evidence text.",
                "Flesch reading ease: 206.835 − 1.015 × words per sentence − 84.6 × syllables per word, with syllables approximated by vowel groups.",
                "Share of characters that are digits (dense numeric reports read differently from summaries).",
                "Count dated update lines (“on Nov 4th 2025 …”) typical of AvHerald articles that grow as investigations progress.",
                "Flag an embedded METAR, and count hedging words such as reportedly, unconfirmed, possibly, suspected, alleged.",
            ],
            "rules": [], "caveats": ["Preliminary stubs with no narrative get near-zero values here; use report kind to separate them."],
        },
        {
            "id": "occ", "fam": "occ", "name": "Occurrence categories", "prefix": "occ_*",
            "purpose": "Which CICTT occurrence categories (the basis of the SEWG categories) the narrative describes, with negation and hedging kept apart.",
            "source": "taxonomy.OCCURRENCE_LEXICON, features.lexicon_hits, normalize.scope_tag",
            "steps": LEX_STEPS + ["Summaries: occ_n_categories counts categories with a stated match; occ_top is the category with the most stated matches and feeds a labeling rule."],
            "rules": _lex(taxonomy.OCCURRENCE_LEXICON),
            "caveats": [
                "Keywords are starter-grade. Real reports showed false positives (“deicing pad” fires ICE in a ground collision) and gaps (a runway crossing without the word incursion).",
                "Patterns that span words are bounded (for example struck .{0,30}?vehicle) so one match cannot run across a whole sentence.",
                "The chi-square miner in features.mine_lexicon proposes new terms per category for SME review.",
            ],
        },
        {
            "id": "ph", "fam": "ph", "name": "Phase of flight", "prefix": "ph_*",
            "purpose": "Where in the flight the narrative places the event, as an ordered profile from standing to landing.",
            "source": "taxonomy.PHASE_LEXICON, features.build_row (ph block)",
            "steps": LEX_STEPS[:3] + [
                "Count stated matches for each of nine phases (negated matches do not count).",
                "ph_first and ph_last are the phases whose first stated match appears earliest and latest in the narrative; ph_n_distinct counts phases mentioned.",
                "The report view draws these on a flight profile and overlays the phases NTSB coded in its event sequence, so text and coding can be compared.",
            ],
            "rules": _lex(taxonomy.PHASE_LEXICON),
            "caveats": ["Narratives mention phases that are not where the event happened (“departed Dallas”, “taxied to the gate”), so ph_last often reads taxi or landing after an en-route event."],
        },
        {
            "id": "ata", "fam": "ata", "name": "Aircraft systems (ATA)", "prefix": "ata_*",
            "purpose": "Which aircraft systems and components the narrative involves, using ATA iSpec 2200 chapters.",
            "source": "taxonomy.ATA_LEXICON, features.lexicon_hits",
            "steps": LEX_STEPS + ["ata_n_systems counts chapters with at least one stated match."],
            "rules": _lex(taxonomy.ATA_LEXICON),
            "caveats": ["A system can be named without being at fault (“the captain applied rudder”); pair ATA hits with occurrence and outcome features rather than reading them alone.",
                        "Chapter 78 (thrust reverser) is the screening hook for the slow-deployment analyses."],
        },
        {
            "id": "hf", "fam": "hf", "name": "Human factors", "prefix": "hf_*",
            "purpose": "Signals of crew, maintenance and organizational contributions, grouped in an HFACS-style scheme.",
            "source": "taxonomy.HF_LEXICON, features.lexicon_hits",
            "steps": LEX_STEPS + ["hf_any flags reports with at least one stated human-factors match."],
            "rules": _lex(taxonomy.HF_LEXICON),
            "caveats": ["Human-factors wording concentrates in the analysis and probable cause, which the model does not read; factual narratives carry fewer cues, by design.",
                        "Part 121 work needs the supervisory and organizational tiers expanded; GA-oriented studies often drop them."],
        },
        {
            "id": "wx", "fam": "wx", "name": "Weather", "prefix": "wx_*",
            "purpose": "Weather conditions from plain language plus hard numbers read from embedded METARs.",
            "source": "taxonomy.WEATHER_LEXICON, extractors.WIND_RE / VIS_RE / CEIL_RE / METAR_WX_RE",
            "steps": [
                "Seven keyword groups (low visibility, precipitation, wind, convective, icing, contaminated runway, night) are counted like the other lexicons.",
                "METAR wind groups (for example 28016G24KT) give wx_wind_kt_max and wx_gust_kt_max.",
                "Visibility in statute miles (4SM, 1/2SM) gives wx_vis_sm_min; BKN/OVC/VV layers give wx_ceiling_ft_min (hundreds of feet × 100).",
                "Present-weather codes (TS, RA, SN, FG, BR, FZRA …) are collected into wx_metar_phenomena.",
            ],
            "rules": _lex(taxonomy.WEATHER_LEXICON) + _rx([("METAR wind", extractors.WIND_RE), ("Visibility", extractors.VIS_RE),
                                                           ("Ceiling", extractors.CEIL_RE), ("Present weather", extractors.METAR_WX_RE)]),
            "caveats": ["NTSB PDFs carry weather in a data table (also parsed into the PDF fields), which is more reliable than narrative wording."],
        },
        {
            "id": "out", "fam": "out", "name": "Outcomes", "prefix": "out_*",
            "purpose": "What happened next: crew responses and consequences, useful for severity and for screening media reports.",
            "source": "taxonomy.OUTCOME_LEXICON, features.lexicon_hits",
            "steps": LEX_STEPS[:3] + ["Count stated matches for twelve outcomes, from diversion and rejected takeoff to evacuation, fatality and hull loss.",
                                      "out_fatality and out_hull_loss also feed the cross-source severity score."],
            "rules": _lex(taxonomy.OUTCOME_LEXICON),
            "caveats": ["Words like injur- also appear in “no injuries”; the negation scope keeps those out of the stated count."],
        },
        {
            "id": "q", "fam": "q", "name": "Quantities", "prefix": "q_*, crew_*, pob_*, n_*, delay_*",
            "purpose": "Numbers stated in the narrative: flight state, crew experience, people on board and casualties.",
            "source": "extractors.extract",
            "steps": [
                "Each regex captures a number and its unit; thousands separators are removed.",
                "Altitudes in feet (with AGL or MSL) and flight levels (× 100) give count, max and min; values over 60,000 ft are discarded as noise.",
                "Speeds in knots (under 700), vertical speed in feet per minute, distances in nautical miles and g-loads (under 10) give maxima.",
                "Crew hours of 20 or more give total-hours max and min; hours “in type” or “in make and model” give crew_type_hours_min; ages 16–90 give crew_age_max.",
                "Passenger counts, injured and killed counts, and delays in hours are extracted the same way.",
            ],
            "rules": _rx([("Altitude", extractors.ALT_RE), ("Flight level", extractors.FL_RE), ("Speed", extractors.SPD_RE),
                          ("Vertical speed", extractors.VSPD_RE), ("Distance", extractors.NM_RE), ("g-load", extractors.G_RE),
                          ("Crew hours", extractors.HOURS_RE), ("Hours in type", extractors.TYPE_HRS_RE), ("Age", extractors.AGE_RE),
                          ("People on board", extractors.POB_RE), ("Injured / killed", extractors.INJ_RE), ("Delay", extractors.DELAY_RE)]),
            "caveats": ["Regexes take the narrative at its word and cannot tell whose altitude or which pilot's hours; the NTSB PDF tables give pilot age and hours per seat more reliably."],
        },
        {
            "id": "ent", "fam": "ent", "name": "Entities", "prefix": "ent_*",
            "purpose": "Names that identify the event: airports, runways, registrations and flight numbers. They drive cross-source linking.",
            "source": "extractors.extract (entity block)",
            "steps": [
                "ICAO airport codes: four capitals starting with a region letter (K, C, E, P, L, R, O, V, Y, Z, S, F, U, W).",
                "Runways: the number (and L, R or C) after the word runway.",
                "Registrations: US N-numbers and hyphenated international marks (G-EUPT, 9V-SMA).",
                "Flight numbers: the token after the word flight. Anything taken as a flight number is removed from the registration list.",
            ],
            "rules": _rx([("ICAO airport", extractors.ICAO_APT_RE), ("Runway", extractors.RWY_RE), ("US registration", extractors.REG_N_RE),
                          ("International registration", extractors.REG_INTL_RE), ("Flight number", extractors.FLIGHT_NO_RE)]),
            "caveats": ["Four-capital words in shouting text can look like ICAO codes; check against an airport table before using ent_airports for joins."],
        },
        {
            "id": "seq", "fam": None, "name": "NTSB event sequence", "prefix": "seq_*",
            "purpose": "NTSB's own coded chain of events and findings. These are investigator conclusions: kept for labels and analysis, never fed to the model.",
            "source": "features.build_row (sequence block), ingest_ntsb (events_sequence, Findings), ingest_ntsb_pdf (History of Flight table)",
            "steps": [
                "Read the ordered occurrences from events_sequence, or from the History of Flight table in report PDFs (pre-2008 PDFs: Occurrence #n with Phase of Operation).",
                "seq_len, seq_first and seq_defining record the chain, its first event and the defining event; seq_defining_pos is the defining event's relative position.",
                "Each occurrence is mapped through our NTSB-to-CICTT crosswalk into seq_cictt_chain (for example SCF-NP > LOC-G).",
                "Phases are taken from the occurrence prefix: seq_phase_chain and seq_n_phase_transitions; seq_pre_defining is the event just before the defining one.",
                "Findings are counted by area: personnel, aircraft, environment.",
            ],
            "rules": [{"name": "NTSB event to CICTT crosswalk (first match wins)", "patterns": [f"{a} → {b}" for a, b in taxonomy.NTSB_DEFINING_TO_CICTT]}],
            "caveats": ["NTSB publishes no official event-to-CICTT crosswalk; this one is ours and needs SME sign-off and versioning.",
                        "About half of recent cases and every preliminary report lack a coded sequence."],
        },
        {
            "id": "link", "fam": None, "name": "Cross-source linkage", "prefix": "link_*",
            "purpose": "Recognizing the same event in NTSB, AvHerald and ASN so labels can be shared and counts are not inflated.",
            "source": "linking.link, linking.clusters",
            "steps": [
                "Block: only compare reports from different sources whose dates are within three days.",
                "Score each pair: 0.45 × same registration + 0.15 × same aircraft family + 0.15 × location word overlap + 0.15 × TF-IDF text similarity + 0.10 × date closeness.",
                "Accept pairs scoring at least 0.55, or any pair with the same registration.",
                "Join accepted pairs into clusters (union-find): link_cluster is the cluster id, link_n_sources the number of sources in it.",
                "Copy the NTSB category to the other reports in the cluster (lbl_linked).",
            ],
            "rules": [], "caveats": ["Registrations get reused when aircraft change hands; the date window limits but does not remove that risk.",
                                     "Best practice adds a deterministic key ladder and a human review band with a measured false-merge rate."],
        },
        {
            "id": "lbl", "fam": None, "name": "Labels and predictions", "prefix": "lbl_*, p_*, pred_*",
            "purpose": "The targets the model learns from and the calibrated category it predicts.",
            "source": "features.make_labels, labeling.LFS / combine, classify.OccurrenceClassifier, evaluate.evaluate",
            "steps": [
                "NTSB label: from 2008 the defining event mapped through the crosswalk; before 2008 the first coded occurrence, refined by cause findings when the title is coarse (lbl_source records which).",
                f"Weak labels for media reports: {len(labeling.LFS)} labeling rules vote; each rule's weight is the log-odds of its accuracy on NTSB-labeled reports.",
                "Training labels: NTSB first, then linked NTSB labels, then weak labels with confidence of 0.6 or more.",
                "Model: word 1–2-gram and character 3–5-gram TF-IDF plus the evidence-side numeric features, class-balanced logistic regression, Platt-calibrated.",
                "A report is flagged for review when confidence is under 0.5 or the top two categories are within 0.15.",
                "Evaluation trains on earlier years and tests on later ones, keeping linked reports of one event on the same side, and compares with keyword and majority baselines.",
            ],
            "rules": [{"name": "Labeling rules", "patterns": [f.__name__ for f in labeling.LFS]}],
            "caveats": ["Categories with a single labeled example are dropped from training, so rare categories cannot be predicted until more data arrives.",
                        "Scores on the fictional test data only show the code runs; they say nothing about real performance."],
        },
    ]
