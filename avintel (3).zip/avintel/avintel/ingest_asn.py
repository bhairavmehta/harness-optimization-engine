"""Aviation Safety Network (aviation-safety.net, Flight Safety Foundation) ingestion.

ASN occurrence pages (database + wikibase) are a key/value fact table followed
by a narrative. As with AvHerald, confirm data-use permission with FSF/ASN
before bulk collection; this module parses saved HTML or a CSV/JSONL export.

Typical fact keys: Date, Time, Type, Owner/operator, Registration, MSN,
Year of manufacture, Total airframe hrs, Cycles, Engine model, Fatalities,
Other fatalities, Aircraft damage, Category, Location, Phase, Nature,
Departure airport, Destination airport, Investigating agency, Confidence Rating.
"""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

import pandas as pd
from bs4 import BeautifulSoup

from .schema import CANONICAL_COLUMNS, empty_record

KEY_ALIASES = {
    "date": "date", "time": "time", "type": "type", "owner/operator": "operator",
    "operator": "operator", "registration": "registration", "msn": "msn",
    "year of manufacture": "yom", "total airframe hrs": "airframe_hrs", "cycles": "cycles",
    "engine model": "engine_model", "engines": "engine_model", "fatalities": "fatalities",
    "other fatalities": "other_fatalities", "aircraft damage": "damage", "category": "category",
    "location": "location", "phase": "phase", "nature": "nature",
    "departure airport": "dep_airport", "destination airport": "dest_airport",
    "investigating agency": "investigating_agency", "confidence rating": "confidence",
}
DAMAGE_MAP = {"destroyed": "DEST", "written off": "DEST", "substantial": "SUBS",
              "minor": "MINR", "none": "NONE", "unknown": None}


def _facts_from_soup(soup: BeautifulSoup) -> dict:
    facts = {}
    for tr in soup.find_all("tr"):
        cells = [c.get_text(" ", strip=True) for c in tr.find_all(["td", "th"])]
        if len(cells) >= 2 and cells[0].endswith(":"):
            k = KEY_ALIASES.get(cells[0].rstrip(":").strip().lower())
            if k:
                facts[k] = cells[1]
    return facts


def parse_fatalities(s: str | None) -> tuple[int | None, int | None]:
    """'Fatalities: 2 / Occupants: 150' -> (2, 150)."""
    if not s:
        return None, None
    f = re.search(r"Fatalities:\s*(\d+)", s, re.I) or re.match(r"\s*(\d+)", s)
    o = re.search(r"Occupants:\s*(\d+)", s, re.I)
    return (int(f.group(1)) if f else None, int(o.group(1)) if o else None)


def facts_to_record(facts: dict, narrative: str, url: str | None) -> dict:
    rec = empty_record()
    rid = hashlib.sha1((url or json.dumps(facts, sort_keys=True)).encode()).hexdigest()[:12]
    typ = facts.get("type") or ""
    make = typ.split()[0].upper() if typ else None
    model = " ".join(typ.split()[1:]) or None
    fat, occ = parse_fatalities(facts.get("fatalities"))
    dmg = (facts.get("damage") or "").lower()
    d = pd.to_datetime(re.sub(r"^\w+day\s+", "", facts.get("date") or ""), errors="coerce", dayfirst=True)
    rec.update(
        report_id=f"ASN:{rid}", source="ASN", url=url,
        event_date=None if pd.isna(d) else str(d.date()),
        event_type=facts.get("category"), operator=facts.get("operator"),
        registration=(facts.get("registration") or "").upper() or None,
        aircraft_make=make, aircraft_model=model, location=facts.get("location"),
        damage=next((v for k, v in DAMAGE_MAP.items() if k in dmg), None),
        highest_injury="FATL" if (fat or 0) > 0 else None,
        narrative=narrative,
        title=f"ASN {facts.get('category') or ''} {typ} {facts.get('registration') or ''} "
              f"{facts.get('location') or ''} - {facts.get('phase') or ''}".strip(),
    )
    # ASN-specific structured extras ride along in `findings` as key=value tags
    extras = {k: facts.get(k) for k in ("phase", "nature", "dep_airport", "dest_airport",
                                       "yom", "airframe_hrs", "cycles", "engine_model",
                                       "investigating_agency", "confidence", "msn")}
    extras.update(fatalities=fat, occupants=occ)
    rec["findings"] = [f"asn_{k}={v}" for k, v in extras.items() if v not in (None, "")]
    return rec


def parse_asn_html(html: str, url: str | None = None) -> dict:
    soup = BeautifulSoup(html, "html.parser")
    facts = _facts_from_soup(soup)
    # narrative: text after a "Narrative:" label, else longest paragraph block
    txt = soup.get_text("\n", strip=True)
    m = re.search(r"Narrative:\s*\n?(.*?)(?:\n(?:Sources?|Revision history|Location|Images?):|\Z)", txt, re.S | re.I)
    narrative = m.group(1).strip() if m else max((p.get_text(" ", strip=True) for p in soup.find_all("p")), key=len, default="")
    return facts_to_record(facts, narrative, url)


def load_saved_html_dir(path: str | Path) -> pd.DataFrame:
    rows = [parse_asn_html(f.read_text(errors="ignore"), url=f.name) for f in sorted(Path(path).glob("*.htm*"))]
    return pd.DataFrame(rows, columns=CANONICAL_COLUMNS)


def load_table(path: str | Path) -> pd.DataFrame:
    """CSV/JSONL export whose columns are ASN fact keys + `narrative` (+ optional `url`)."""
    p = Path(path)
    items = (pd.read_csv(p, dtype=str).fillna("").to_dict("records") if p.suffix == ".csv"
             else [json.loads(l) for l in p.read_text().splitlines() if l.strip()])
    rows = []
    for it in items:
        facts = {KEY_ALIASES.get(k.lower().rstrip(":"), k.lower()): v for k, v in it.items() if v}
        rows.append(facts_to_record(facts, it.get("narrative", ""), it.get("url")))
    return pd.DataFrame(rows, columns=CANONICAL_COLUMNS)
