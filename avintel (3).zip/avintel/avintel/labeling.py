"""Weak supervision for sources without ground-truth codes (AvHerald, ASN).

Labeling functions (LFs) vote a CICTT category or abstain. Votes are combined
with accuracy weights estimated on NTSB records, where the defining event gives
a ground-truth label. This is a lightweight stand-in for Snorkel's label model;
swap in snorkel.labeling.model.LabelModel if you want the full generative model.
"""
from __future__ import annotations

from collections import defaultdict

import numpy as np
import pandas as pd

ABSTAIN = None


def _code(feature_key: str) -> str:
    """Feature-key form (SCF_NP, TURB_WAKE) -> CICTT code (SCF-NP, TURB-WAKE)."""
    return feature_key.replace("_", "-")


def lf_lexicon_top(row):
    return _code(row["occ_top"]) if row.get("occ_n_categories", 0) and row.get("occ_top") else ABSTAIN


def lf_title_keywords(row):
    t = (row.get("_text") or "")[:300].lower()
    for kw, lab in [("bird strike", "BIRD"), ("runway excursion", "RE"), ("overran", "RE"), ("veered off", "RE"),
                    ("tail strike", "ARC"), ("hard landing", "ARC"), ("engine shut down", "SCF-PP"),
                    ("engine failure", "SCF-PP"), ("smoke", "F-NI"), ("fire", "F-NI"), ("turbulence", "TURB"),
                    ("loss of separation", "MAC"), ("tcas", "MAC"), ("runway incursion", "RI"),
                    ("hydraulic", "SCF-NP"), ("gear", "SCF-NP"), ("pressuri", "SCF-NP"), ("windshear", "WSTRW"),
                    ("laser", "SEC"), ("drone", "UAS"), ("medical", "MED"), ("fuel", "FUEL")]:
        if kw in t:
            return lab
    return ABSTAIN


def lf_ata_to_cictt(row):
    if row.get("ata_71_POWERPLANT", 0) + row.get("ata_72_ENGINE", 0) >= 2 and row.get("out_diversion", 0) + row.get("out_return", 0):
        return "SCF-PP"
    if row.get("ata_32_LANDING_GEAR", 0) + row.get("ata_29_HYDRAULIC", 0) + row.get("ata_21_AIR_COND_PRESS", 0) >= 2:
        return "SCF-NP"
    return ABSTAIN


def lf_phase_runway(row):
    if row.get("ph_last") == "LANDING" and row.get("occ_RE", 0) > 0:
        return "RE"
    if row.get("ph_first") in ("LANDING", "TAKEOFF") and (row.get("q_g_max") or 0) >= 2.0:
        return "ARC"
    return ABSTAIN


def lf_fatal_loc(row):
    if (row.get("meta_inj_ord") == 3 or row.get("out_fatality", 0)) and row.get("ph_first") in ("MANEUVERING", "ENROUTE", "INITIAL_CLIMB") and row.get("occ_LOC_I", 0):
        return "LOC-I"
    return ABSTAIN


def lf_cfit(row):
    if row.get("occ_CFIT", 0) and row.get("meta_imc") == 1:
        return "CFIT"
    return ABSTAIN


LFS = [lf_lexicon_top, lf_title_keywords, lf_ata_to_cictt, lf_phase_runway, lf_fatal_loc, lf_cfit]


def apply_lfs(df: pd.DataFrame) -> pd.DataFrame:
    recs = df.to_dict("records")
    return pd.DataFrame({lf.__name__: [lf(r) for r in recs] for lf in LFS}, index=df.index)


def lf_report(votes: pd.DataFrame, gold: pd.Series) -> pd.DataFrame:
    rows = []
    for c in votes:
        v = votes[c]
        cov = v.notna().mean()
        m = v.notna() & gold.notna()
        acc = (v[m] == gold[m]).mean() if m.any() else np.nan
        rows.append({"lf": c, "coverage": round(cov, 3), "n_gold_overlap": int(m.sum()), "accuracy": acc})
    return pd.DataFrame(rows)


def lf_weight(accuracy: float | None, floor: float = 0.1) -> float:
    """Log-odds weight from an estimated LF accuracy; LFs no better than chance get a small floor weight."""
    if accuracy is None or (isinstance(accuracy, float) and np.isnan(accuracy)):
        return 1.0
    a = min(max(float(accuracy), 0.01), 0.99)
    return max(np.log(a / (1 - a)), floor)


def combine(votes: pd.DataFrame, accuracies: dict[str, float] | None = None) -> pd.DataFrame:
    """Accuracy-weighted vote -> (weak_label, weak_conf in [0, 1], n_votes)."""
    accuracies = accuracies or {}
    w = {c: lf_weight(accuracies.get(c)) for c in votes}
    labels, confs, nv = [], [], []
    for _, r in votes.iterrows():
        score = defaultdict(float)
        for c, v in r.items():
            if v is not None and not (isinstance(v, float) and np.isnan(v)):
                score[v] += w[c]
        if not score:
            labels.append(None); confs.append(0.0); nv.append(0); continue
        lab = max(score, key=score.get)
        labels.append(lab); confs.append(round(score[lab] / sum(score.values()), 3)); nv.append(len(score))
    return pd.DataFrame({"weak_label": labels, "weak_conf": confs, "weak_n_labels": nv}, index=votes.index)
