"""avintel — feature engineering for NTSB, Aviation Herald and ASN occurrence reports."""
__version__ = "0.6.0"
