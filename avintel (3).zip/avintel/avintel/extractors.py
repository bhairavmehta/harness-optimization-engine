"""Rule-based entity / quantity extraction from narratives.

Each extractor returns plain python values so they can go straight into a
feature row. Everything is regex-only (no network, no model) so it is cheap,
deterministic and auditable — a good first layer before any LLM extraction.
"""
from __future__ import annotations

import re
import statistics as st

NUM = r"(\d{1,3}(?:,\d{3})+|\d+(?:\.\d+)?)"


def _n(s: str) -> float:
    return float(s.replace(",", ""))


ALT_RE = re.compile(rf"{NUM}\s*(?:feet|foot)\s*(above ground level|mean sea level|AGL|MSL)?", re.I)
FL_RE = re.compile(r"\b(?:flight level|FL)\s?(\d{2,3})\b", re.I)
SPD_RE = re.compile(rf"{NUM}\s*(?:knots|KIAS|KCAS|KTAS)\b", re.I)
VSPD_RE = re.compile(rf"{NUM}\s*(?:feet|ft) per minute|{NUM}\s*fpm", re.I)
NM_RE = re.compile(rf"{NUM}\s*nautical miles", re.I)
ICAO_APT_RE = re.compile(r"\b([KCEPLROVYZSFUW][A-Z]{3})\b")
RWY_RE = re.compile(r"\brunway\s+(\d{1,2}[LRC]?)\b", re.I)
HOURS_RE = re.compile(rf"{NUM}\s*(?:total )?(?:flight )?hours?(?: of)?(?: total)?(?: flight)?(?: experience)?", re.I)
TYPE_HRS_RE = re.compile(rf"{NUM}\s*hours?\s*(?:in|on) (?:the )?(?:make and model|type|airplane make)", re.I)
AGE_RE = re.compile(r"\b(\d{2})-year-old\b", re.I)
POB_RE = re.compile(rf"{NUM}\s*(?:passengers|pax)(?:\s*and\s*{NUM}\s*crew)?", re.I)
INJ_RE = re.compile(rf"{NUM}\s*(?:people|persons|passengers|occupants|crew( members)?)\s*(?:were |was )?(?:seriously |minor(ly)? |fatally )?(injured|killed|died|hurt)", re.I)
G_RE = re.compile(rf"{NUM}\s*G\b")
WIND_RE = re.compile(r"\b(\d{3})(\d{2,3})(?:G(\d{2,3}))?KT\b")             # METAR wind
VIS_RE = re.compile(r"\b(\d{1,2}(?:/\d)?)\s?SM\b")
CEIL_RE = re.compile(r"\b(BKN|OVC|VV)(\d{3})\b")
METAR_WX_RE = re.compile(r"\s(\+|-)?(TS|RA|SN|FG|BR|FZRA|FZDZ|GR|SH|DZ)(?=\s)")
DELAY_RE = re.compile(rf"(?:about|approximately)?\s*{NUM}\s*hours?\s*(?:after|later|delay)", re.I)
REG_N_RE = re.compile(r"\bN\d{1,5}[A-Z]{0,2}\b")
REG_INTL_RE = re.compile(r"\b(?:[A-Z]{1,2}-[A-Z0-9]{3,5})\b")
FLIGHT_NO_RE = re.compile(r"\bflight\s+([A-Z0-9]{2}-?\d{1,4}[A-Z]?)\b", re.I)


def _stats(vals, prefix):
    if not vals:
        return {f"{prefix}_n": 0, f"{prefix}_max": None, f"{prefix}_min": None}
    return {f"{prefix}_n": len(vals), f"{prefix}_max": max(vals), f"{prefix}_min": min(vals)}


def extract(text: str) -> dict:
    t = text or ""
    f: dict = {}
    alts = [_n(m.group(1)) for m in ALT_RE.finditer(t) if _n(m.group(1)) < 60000]
    alts += [int(m.group(1)) * 100 for m in FL_RE.finditer(t)]
    f.update(_stats(alts, "q_alt_ft"))
    f.update(_stats([_n(m.group(1)) for m in SPD_RE.finditer(t) if _n(m.group(1)) < 700], "q_speed_kt"))
    vs = [_n(m.group(1) or m.group(2)) for m in VSPD_RE.finditer(t)]
    f["q_vs_fpm_max"] = max(vs) if vs else None
    f["q_dist_nm_max"] = max((_n(m.group(1)) for m in NM_RE.finditer(t)), default=None)
    f["q_g_max"] = max((_n(m.group(1)) for m in G_RE.finditer(t) if _n(m.group(1)) < 10), default=None)

    hrs = [_n(m.group(1)) for m in HOURS_RE.finditer(t) if _n(m.group(1)) >= 20]
    f["crew_total_hours_max"] = max(hrs) if hrs else None
    f["crew_total_hours_min"] = min(hrs) if hrs else None
    th = [_n(m.group(1)) for m in TYPE_HRS_RE.finditer(t)]
    f["crew_type_hours_min"] = min(th) if th else None
    ages = [int(m.group(1)) for m in AGE_RE.finditer(t) if 16 <= int(m.group(1)) <= 90]
    f["crew_age_max"] = max(ages) if ages else None

    pob = [_n(m.group(1)) for m in POB_RE.finditer(t)]
    f["pob_pax"] = max(pob) if pob else None
    inj = [(_n(m.group(1)), m.group(m.lastindex).lower()) for m in INJ_RE.finditer(t)]
    f["n_injured_text"] = sum(n for n, k in inj if k in ("injured", "hurt")) or None
    f["n_killed_text"] = sum(n for n, k in inj if k in ("killed", "died")) or None

    winds = [(int(m.group(2)), int(m.group(3)) if m.group(3) else None) for m in WIND_RE.finditer(t)]
    f["wx_wind_kt_max"] = max((w for w, _ in winds), default=None)
    f["wx_gust_kt_max"] = max((g for _, g in winds if g), default=None)
    vis = []
    for m in VIS_RE.finditer(t):
        s = m.group(1)
        vis.append(_n(s.split("/")[0]) / _n(s.split("/")[1]) if "/" in s else _n(s))
    f["wx_vis_sm_min"] = min(vis) if vis else None
    ceil = [int(m.group(2)) * 100 for m in CEIL_RE.finditer(t)]
    f["wx_ceiling_ft_min"] = min(ceil) if ceil else None
    f["wx_metar_phenomena"] = "|".join(sorted({m.group(2) for m in METAR_WX_RE.finditer(" " + t + " ")})) or None

    f["ent_airports"] = "|".join(sorted(set(ICAO_APT_RE.findall(t)))) or None
    f["ent_runways"] = "|".join(sorted(set(m.group(1).upper() for m in RWY_RE.finditer(t)))) or None
    flights = {m.group(1).upper() for m in FLIGHT_NO_RE.finditer(t)}
    regs = (set(REG_N_RE.findall(t)) | set(REG_INTL_RE.findall(t))) - flights
    f["ent_registrations"] = "|".join(sorted(regs)) or None
    f["ent_flight_numbers"] = "|".join(sorted(flights)) or None
    f["delay_hours_max"] = max((_n(m.group(1)) for m in DELAY_RE.finditer(t)), default=None)
    return f
