"""Occurrence-category classifier with a strict fit/predict split.

Vectorizers, scaler and model are fitted on training rows only, so the same
object can be used for honest temporal evaluation and for production scoring.
Inputs: word + char TF-IDF of the evidence text + evidence-side numeric block
(+ optional sentence embeddings). Answer-side columns are excluded by
features.numeric_columns().
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.sparse import csr_matrix, hstack
from sklearn.calibration import CalibratedClassifierCV
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import MaxAbsScaler

from .features import numeric_block, numeric_columns


class OccurrenceClassifier:
    def __init__(self, max_features: int = 20000, C: float = 4.0, embed_model: str | None = None,
                 min_class_count: int = 2, calibrate: bool = True, seed: int = 7):
        self.max_features, self.C, self.embed_model = max_features, C, embed_model
        self.min_class_count, self.calibrate, self.seed = min_class_count, calibrate, seed

    # ---- design matrix ----
    def _embed(self, texts):
        if not self.embed_model:
            return None
        from sentence_transformers import SentenceTransformer  # optional dependency
        if not hasattr(self, "_st"):
            self._st = SentenceTransformer(self.embed_model)
        return self._st.encode(list(texts), normalize_embeddings=True, show_progress_bar=False)

    def _matrix(self, df: pd.DataFrame, fit: bool):
        if fit:
            self.w_ = TfidfVectorizer(ngram_range=(1, 2), min_df=1, max_features=self.max_features,
                                      sublinear_tf=True, stop_words="english")
            self.c_ = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5), min_df=1,
                                      max_features=self.max_features // 2, sublinear_tf=True)
            self.num_cols_ = numeric_columns(df)
            self.scaler_ = MaxAbsScaler()
            Xw, Xc = self.w_.fit_transform(df["_text"]), self.c_.fit_transform(df["_text"])
            Xn = self.scaler_.fit_transform(numeric_block(df, self.num_cols_)[0])
        else:
            Xw, Xc = self.w_.transform(df["_text"]), self.c_.transform(df["_text"])
            Xn = self.scaler_.transform(numeric_block(df, self.num_cols_)[0])
        blocks = [Xw, Xc, csr_matrix(Xn)]
        E = self._embed(df["_text"])
        if E is not None:
            blocks.append(csr_matrix(E))
        return hstack(blocks).tocsr()

    # ---- API ----
    def fit(self, df: pd.DataFrame, y: pd.Series):
        y = pd.Series(y, index=df.index)
        counts = y.value_counts()
        keep = counts[counts >= self.min_class_count].index
        m = y.isin(keep)
        if m.sum() == 0 or len(keep) < 2:
            raise ValueError("need at least two classes with enough examples to train")
        d, yy = df[m], y[m]
        X = self._matrix(d, fit=True)
        base = LogisticRegression(max_iter=3000, C=self.C, class_weight="balanced")
        n_min = int(yy.value_counts().min())
        if self.calibrate and n_min >= 3:
            self.model_ = CalibratedClassifierCV(base, method="sigmoid", cv=min(3, n_min)).fit(X, yy)  # Platt
        else:
            self.model_ = base.fit(X, yy)
        self.classes_ = np.array(self.model_.classes_)
        self.dropped_classes_ = sorted(set(counts.index) - set(keep))
        return self

    def predict_proba(self, df: pd.DataFrame) -> pd.DataFrame:
        P = self.model_.predict_proba(self._matrix(df, fit=False))
        out = pd.DataFrame(P, columns=[f"p_{c}" for c in self.classes_], index=df.index)
        out["pred_cictt"] = self.classes_[P.argmax(1)]
        out["pred_conf"] = P.max(1)
        srt = np.sort(P, axis=1)
        out["pred_margin"] = srt[:, -1] - (srt[:, -2] if P.shape[1] > 1 else 0)
        out["needs_review"] = (out["pred_conf"] < 0.5) | (out["pred_margin"] < 0.15)
        return out

    def top_terms(self, k: int = 15) -> dict:
        """Most positive word n-grams per class (explainability for analysts)."""
        est = self.model_
        if isinstance(est, CalibratedClassifierCV):
            coefs = np.mean([c.estimator.coef_ for c in est.calibrated_classifiers_], axis=0)
        else:
            coefs = est.coef_
        vocab = self.w_.get_feature_names_out()
        nw = len(vocab)
        if coefs.shape[0] == 1:  # binary
            coefs = np.vstack([-coefs, coefs])
        return {c: vocab[np.argsort(coefs[i, :nw])[::-1][:k]].tolist() for i, c in enumerate(self.classes_)}


def training_labels(feats: pd.DataFrame, weak: pd.DataFrame | None = None, min_weak_conf: float = 0.6):
    """Gold (NTSB) first, then linked-gold, then confident weak labels. Returns (y, origin)."""
    y = feats["lbl_cictt"].copy()
    origin = pd.Series(np.where(y.notna(), "gold", None), index=feats.index, dtype=object)
    if "lbl_linked" in feats:
        m = y.isna() & feats["lbl_linked"].notna()
        y[m], origin[m] = feats.loc[m, "lbl_linked"], "linked"
    if weak is not None:
        m = y.isna() & weak["weak_label"].notna() & (weak["weak_conf"] >= min_weak_conf)
        y[m], origin[m] = weak.loc[m, "weak_label"], "weak"
    return y, origin
