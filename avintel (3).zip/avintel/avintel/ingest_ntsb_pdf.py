"""NTSB report PDFs (CAROL "Aviation Investigation Final / Preliminary Report") -> canonical records.

Handles the three layouts seen in practice:
* post-2008 final reports: Analysis, Probable Cause and Findings (category/finding table),
  Factual Information with a History-of-Flight event table "(Defining event)" + narrative;
* pre-2008 final reports re-rendered by CAROL: "Occurrence #n: ... / Phase of Operation: ..."
  plus numbered "(C)/(F)" findings, and a free-text factual narrative;
* preliminary / foreign (WA) stubs: header and data tables only, often no narrative.

Text is extracted with `pdftotext -layout` (poppler) when present, else pypdf.
Every PDF also yields a dict of ~40 structured fields (`pdf_fields`) parsed from the
two-column key/value tables (aircraft, engines, weather, injuries, crew, admin).
"""
from __future__ import annotations

import re
import shutil
import subprocess
from pathlib import Path

import pandas as pd

from .schema import CANONICAL_COLUMNS, empty_record

TABLE_HEADINGS = {
    "History of Flight", "Pilot Information", "Co-pilot Information", "Flight Engineer Information",
    "Aircraft and Owner/Operator Information", "Meteorological Information and Flight Plan",
    "Airport Information", "Wreckage and Impact Information", "Administrative Information",
    "Flight recorders", "Tests and Research", "Medical and Pathological Information",
}
SECTION_HEADINGS = {"Analysis", "Probable Cause and Findings", "Factual Information"}
FOOTER_RE = re.compile(r"^\s*(Page \d+ of \d+.*|This information is preliminary and subject to change\.?)\s*$")
KNOWN_KEYS = [
    "Location", "Accident Number", "Incident Number", "Date & Time", "Registration", "Aircraft", "Aircraft Damage",
    "Defining Event", "Injuries", "Flight Conducted Under", "Certificate", "Age", "Airplane Rating(s)",
    "Seat Occupied", "Other Aircraft Rating(s)", "Restraint Used", "Instrument Rating(s)", "Second Pilot Present",
    "Instructor Rating(s)", "Toxicology Performed", "Medical Certification", "Last FAA Medical Exam",
    "Occupational Pilot", "Last Flight Review or Equivalent", "Flight Time", "Aircraft Make", "Model/Series",
    "Aircraft Category", "Year of Manufacture", "Amateur Built", "Airworthiness Certificate", "Serial Number",
    "Landing Gear Type", "Seats", "Date/Type of Last Inspection", "Certified Max Gross Wt.",
    "Time Since Last Inspection", "Engines", "Airframe Total Time", "Engine Manufacturer", "ELT",
    "Engine Model/Series", "Registered Owner", "Rated Power", "Operator", "Operating Certificate(s)", "Held",
    "Operator Does Business As", "Operator Designator Code", "Conditions at Accident Site", "Condition of Light",
    "Observation Facility, Elevation", "Distance from Accident Site", "Observation Time",
    "Direction from Accident Site", "Lowest Cloud Condition", "Lowest Ceiling", "Visibility", "Visibility (RVR)",
    "Wind Speed/Gusts", "Wind Speed/Gusts, Direction", "Turbulence Type", "Forecast/Actual", "Wind Direction",
    "Turbulence Severity", "Altimeter Setting", "Temperature/Dew Point", "Precipitation and Obscuration",
    "Departure Point", "Type of Flight Plan Filed", "Destination", "Type of Clearance", "Departure Time",
    "Type of Airspace", "Airport", "Runway Surface Type", "Airport Elevation", "Runway Surface Condition",
    "Runway Used", "IFR Approach", "Runway Length/Width", "VFR Approach/Landing", "Crew Injuries",
    "Passenger Injuries", "Ground Injuries", "Total Injuries", "Aircraft Fire", "Aircraft Explosion",
    "Latitude, Longitude", "Investigator In Charge (IIC)", "Additional Participating Persons",
    "Additional Participating", "Original Publish Date", "Last Revision Date", "Investigation Class", "Note",
    "Investigation Docket",
]
NO_COLON_KEYS = {"Visibility", "Turbulence Type", "Turbulence Severity", "Operating Certificate(s)"}  # rendered without ':' in some layouts
_KEYS_ALT = "|".join(re.escape(k) for k in sorted(KNOWN_KEYS, key=len, reverse=True))
KV_RE = re.compile(rf"(?:^|(?<=\s))({_KEYS_ALT})(?::(?=\s|$)|(?=\s{{2,}}\S))")
INJ_MAP = {"fatal": "FATL", "serious": "SERS", "minor": "MINR", "none": "NONE"}
DMG_MAP = {"destroyed": "DEST", "substantial": "SUBS", "minor": "MINR", "none": "NONE"}


# ---------------------------------------------------------------- text extraction
def pdf_text(path: str | Path) -> str:
    path = str(path)
    if shutil.which("pdftotext"):
        return subprocess.run(["pdftotext", "-layout", path, "-"], capture_output=True, text=True, check=True).stdout
    from pypdf import PdfReader  # fallback
    return "\n".join(p.extract_text(extraction_mode="layout") or "" for p in PdfReader(path).pages)


def _clean_lines(text: str, report_no: str | None) -> list[str]:
    out = []
    for ln in text.replace("\f", "\n").splitlines():
        s = ln.rstrip()
        if FOOTER_RE.match(s) or (report_no and s.strip() == report_no):
            continue
        out.append(s)
    return out


# ---------------------------------------------------------------- key/value tables
def parse_kv(lines: list[str]) -> dict:
    """Two-column 'Key:   value   Key:   value' tables -> dict (first occurrence wins).
    Continuation lines (no key, aligned under a value) are appended to the nearest value."""
    kv: dict[str, str] = {}
    last: list[tuple[str, int]] = []           # (key, value start column) for the previous kv line
    for ln in lines:
        ms = [m for m in KV_RE.finditer(ln)
              if ln[m.end(1):m.end(1) + 1] == ":" or m.group(1) in NO_COLON_KEYS]
        # a key must start the line or follow a 2+ space gap (column boundary)
        ms = [m for m in ms if m.start(1) == len(ln) - len(ln.lstrip()) or ln[max(0, m.start(1) - 2):m.start(1)] == "  "]
        if not ms:
            if last and ln.strip() and ln.startswith(" " * 10):
                # continuation: attach each chunk to the column it sits under
                for chunk in re.finditer(r"\S(?:.*?\S)?(?=\s{2,}|$)", ln):
                    col = chunk.start()
                    key = min(last, key=lambda kc: abs(kc[1] - col) if kc[1] <= col + 2 else 1e9)[0]
                    if key in kv and kv[key] is not None:
                        kv[key] = (kv[key] + " " + chunk.group(0)).strip()
            continue
        last = []
        for i, m in enumerate(ms):
            key = m.group(1).strip()
            end = ms[i + 1].start() if i + 1 < len(ms) else len(ln)
            vbeg = m.end(1) + (1 if ln[m.end(1):m.end(1) + 1] == ":" else 0)
            val = ln[vbeg:end].strip() or None
            vstart = vbeg + (len(ln[vbeg:end]) - len(ln[vbeg:end].lstrip()))
            if key not in kv:
                kv[key] = val
            last.append((key, vstart))
    return kv


# ---------------------------------------------------------------- sections
def _find(lines, pred, start=0):
    for i in range(start, len(lines)):
        if pred(lines[i]):
            return i
    return None


def _para(lines: list[str]) -> str:
    """Join wrapped lines into paragraphs (blank line = paragraph break)."""
    paras, cur = [], []
    for ln in lines:
        if ln.strip():
            cur.append(ln.strip())
        elif cur:
            paras.append(" ".join(cur)); cur = []
    if cur:
        paras.append(" ".join(cur))
    return "\n\n".join(paras).strip()


def split_sections(lines: list[str]) -> dict:
    idx = {}
    for i, ln in enumerate(lines):
        s = ln.strip()
        if ln and not ln.startswith(" ") and s in SECTION_HEADINGS and s not in idx:
            idx[s] = i
        elif ln.startswith(" ") and s in TABLE_HEADINGS and s not in idx:
            idx[s] = i
    return idx


def parse_history_table(block: list[str]):
    """Rows '  <phase>   <event>[ (Defining event)]' -> occurrences; other text -> narrative."""
    events, narrative = [], []
    defining = None
    for ln in block:
        if not ln.strip():
            narrative.append("")
            continue
        parts = re.split(r"\s{3,}", ln.strip())
        if any(p.rstrip().endswith(":") for p in parts) or KV_RE.match(ln.strip() + "  "):
            continue  # a key/value table row that leaked into the block, not an event
        if ln.startswith(" ") and len(parts) == 2 and len(parts[0]) < 40 and not parts[0].endswith("."):
            phase, ev = parts
            is_def = "(Defining event)" in ev
            ev = ev.replace("(Defining event)", "").strip()
            desc = f"{phase}-{ev}"
            events.append(desc)
            if is_def:
                defining = desc
        else:
            narrative.append(ln)
    return events, defining, narrative


def parse_findings(block: list[str]):
    """Returns (findings, occurrences) for both new (category/finding) and pre-2008 formats."""
    findings, occs = [], []
    cur_occ = None
    for ln in block:
        s = ln.strip()
        if not s or s == "Findings":
            continue
        m = re.match(r"Occurrence #\d+:\s*(.+)", s)
        if m:
            cur_occ = m.group(1).strip().title()
            continue
        m = re.match(r"Phase of Operation:\s*(.+)", s)
        if m and cur_occ:
            occs.append(f"{m.group(1).strip().title()}-{cur_occ}")
            cur_occ = None
            continue
        m = re.match(r"\d+\.\s*\((C|F)\)\s*(.+)", s)
        if m:
            findings.append(f"{'Cause' if m.group(1) == 'C' else 'Factor'}: {m.group(2).strip()}")
            continue
        m = re.match(r"\d+\.\s*(.+)", s)
        if m:
            findings.append(m.group(1).strip()); continue
        parts = re.split(r"\s{3,}", s)
        if len(parts) == 2:
            findings.append(f"{parts[0]}: {parts[1]}")
        elif findings:
            findings[-1] += " " + s
    if cur_occ:
        occs.append(cur_occ)
    return findings, occs


# ---------------------------------------------------------------- main parser
def _num(s):
    m = re.search(r"[\d,]+(?:\.\d+)?", s or "")
    return float(m.group(0).replace(",", "")) if m else None


def _injury_level(s: str | None):
    if not s:
        return None
    s = s.lower()
    for k in ("fatal", "serious", "minor", "none"):
        if re.search(rf"\d+\s+{k}", s):
            return INJ_MAP[k]
    return None


def parse_report_text(text: str, source_name: str | None = None) -> tuple[dict, dict]:
    raw_lines = text.replace("\f", "\n").splitlines()
    head = "\n".join(raw_lines[:20])
    m = re.search(r"(?:Accident|Incident) Number:\s+([A-Z]{3}\d{2}[A-Z]{2}\d{3,4}[A-Z]?)", head)
    report_no = m.group(1) if m else (Path(source_name).stem if source_name else None)
    kind = "Final" if "Final Report" in head else "Preliminary" if "Preliminary Report" in head else None
    lines = _clean_lines(text, report_no)
    kv = parse_kv(lines)
    sec = split_sections(lines)

    def block(name, stop_names=None):
        if name not in sec:
            return []
        start = sec[name] + 1
        later = [i for k, i in sec.items() if i > sec[name] and (stop_names is None or k in stop_names)]
        return lines[start: min(later) if later else len(lines)]

    analysis = _para(block("Analysis"))
    # probable cause + findings
    pcf = block("Probable Cause and Findings")
    pc_lines, fnd_lines, in_f = [], [], False
    for ln in pcf:
        if ln.strip() == "Findings":
            in_f = True; continue
        if "determines the probable cause" in ln:
            continue
        (fnd_lines if in_f else pc_lines).append(ln)
    # pre-2008 layout puts the findings table after a page break, before Factual Information
    probable_cause = _para(pc_lines) or None
    findings, old_occs = parse_findings(fnd_lines)

    # factual narrative: Factual Information + History of Flight block, minus the event table
    fact_lines = block("Factual Information", TABLE_HEADINGS | SECTION_HEADINGS)
    hist_lines = block("History of Flight", TABLE_HEADINGS | SECTION_HEADINGS)
    events, defining, hist_narr = parse_history_table(hist_lines)
    factual = _para([l for l in fact_lines if l.strip() != "History of Flight"] + hist_narr)
    occurrences = events or old_occs
    if not defining and kv.get("Defining Event"):
        de = kv["Defining Event"]
        defining = next((o for o in occurrences if o.split("-", 1)[-1].lower() == de.lower()), de)

    date_str = (kv.get("Date & Time") or "").split(",")
    date = pd.to_datetime(",".join(date_str[:2]), errors="coerce") if len(date_str) >= 2 else pd.NaT
    loc = (kv.get("Location") or "").rstrip(",")
    country = None
    if loc and "," in loc:
        tail = loc.split(",")[-1].strip()
        country = "USA" if tail in US_STATES else tail
    elif loc:
        country = None
    fcu = kv.get("Flight Conducted Under") or ""
    far = re.search(r"Part (\d+)", fcu)
    cond = (kv.get("Conditions at Accident Site") or "")
    light = kv.get("Condition of Light")

    rec = empty_record()
    rec.update(
        report_id=f"NTSB:{report_no}", source="NTSB",
        event_date=None if pd.isna(date) else str(date.date()),
        event_type="INC" if "Incident Number" in head else "ACC",
        operator=kv.get("Operator"), registration=kv.get("Registration"),
        aircraft_make=(kv.get("Aircraft Make") or "").upper() or None,
        aircraft_model=kv.get("Model/Series") or kv.get("Aircraft"),
        far_part=far.group(1) if far else ("NUSC" if "Non-U.S., commercial" in fcu else "NUSN" if "Non-U.S." in fcu else None),
        location=loc or None, country=country,
        highest_injury=_injury_level(kv.get("Injuries") or kv.get("Total Injuries")),
        damage=DMG_MAP.get((kv.get("Aircraft Damage") or "").strip().lower()),
        wx_cond="IMC" if "IMC" in cond else "VMC" if "VMC" in cond else None,
        light_cond=("NITE" if light and light.lower().startswith("night") else (light or "").upper()[:4] or None),
        narrative="\n\n".join(x for x in [factual, analysis if analysis and analysis not in factual else None] if x) or None,
        probable_cause=probable_cause, occurrences=occurrences, defining_event=defining,
        findings=findings, url=f"https://data.ntsb.gov/carol-main-public/basic-search?queryId={report_no}",
    )
    rec["title"] = " ".join(x for x in [rec["event_type"], kv.get("Aircraft") or "", f"at {loc}" if loc else "",
                                        f"on {rec['event_date']}" if rec["event_date"] else ""] if x)

    fields = {
        "report_no": report_no, "report_kind": kind, "source_file": source_name,
        "has_analysis": bool(analysis), "has_factual_narrative": bool(factual),
        "narrative_words": len((rec["narrative"] or "").split()),
        "flight_conducted_under": fcu or None, "defining_event_header": kv.get("Defining Event"),
        "injuries_header": kv.get("Injuries"),
        "pilot_age": _num(kv.get("Age")), "pilot_total_hours": _num(kv.get("Flight Time")),
        "pilot_certificate": kv.get("Certificate"),
        "year_of_manufacture": _num(kv.get("Year of Manufacture")),
        "airframe_total_hours": _num(kv.get("Airframe Total Time")),
        "engines": kv.get("Engines"), "engine_manufacturer": kv.get("Engine Manufacturer"),
        "engine_model": kv.get("Engine Model/Series"), "max_gross_wt_lbs": _num(kv.get("Certified Max Gross Wt.")),
        "operating_certificate": kv.get("Operating Certificate(s)"), "operator_code": kv.get("Operator Designator Code"),
        "conditions": cond or None, "light": light, "lowest_ceiling": kv.get("Lowest Ceiling"),
        "visibility": kv.get("Visibility"), "wind": kv.get("Wind Speed/Gusts") or kv.get("Wind Speed/Gusts, Direction"),
        "wind_direction": kv.get("Wind Direction"), "temp_dew": kv.get("Temperature/Dew Point"),
        "precipitation": kv.get("Precipitation and Obscuration"), "departure": kv.get("Departure Point"),
        "destination": kv.get("Destination"), "flight_plan": kv.get("Type of Flight Plan Filed"),
        "crew_injuries": kv.get("Crew Injuries"), "passenger_injuries": kv.get("Passenger Injuries"),
        "ground_injuries": kv.get("Ground Injuries"), "aircraft_fire": kv.get("Aircraft Fire"),
        "lat_lon": kv.get("Latitude, Longitude"), "investigation_class": kv.get("Investigation Class"),
        "iic": kv.get("Investigator In Charge (IIC)"), "docket": (kv.get("Investigation Docket") or "").split(" ")[0] or None, "publish_date": kv.get("Original Publish Date"),
        "n_occurrences": len(occurrences), "n_findings": len(findings),
    }
    return rec, fields


US_STATES = {"Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", "Delaware",
             "Florida", "Georgia", "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky",
             "Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota", "Mississippi", "Missouri",
             "Montana", "Nebraska", "Nevada", "New Hampshire", "New Jersey", "New Mexico", "New York",
             "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island",
             "South Carolina", "South Dakota", "Tennessee", "Texas", "Utah", "Vermont", "Virginia", "Washington",
             "West Virginia", "Wisconsin", "Wyoming", "District of Columbia", "Puerto Rico", "Guam"}


def load_pdf_dir(path: str | Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Returns (canonical records, per-report structured PDF fields)."""
    recs, fields = [], []
    for f in sorted(Path(path).glob("*.pdf")):
        r, fl = parse_report_text(pdf_text(f), f.name)
        recs.append(r); fields.append({"report_id": r["report_id"], **fl})
    return pd.DataFrame(recs, columns=CANONICAL_COLUMNS), pd.DataFrame(fields)
