"""Excel export of reports and engineered features.

python -m avintel.export_xlsx --out out/ --xlsx out/avintel_features.xlsx

Sheets
  Summary            counts and keyword-vs-NTSB agreement (live formulas)
  Reports            one row per report: metadata, labels, keyword/weak labels, match flag (formula)
  Features           the full wide feature table (one column per feature)
  Feature Values     long format: every non-zero feature value per report (filter / pivot friendly)
  Evidence Spans     the exact words in each narrative that produced each lexicon / quantity / entity hit
  Feature Dictionary every column: family, evidence vs answer side, coverage and non-zero counts (formulas)
  PDF Fields         structured fields parsed from NTSB PDFs (if pdf_fields.csv exists)
  Narratives         model-input text and the answer-side probable cause, side by side
"""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from openpyxl import Workbook
from openpyxl.comments import Comment
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import Table, TableStyleInfo

from .features import evidence_text, is_answer_column
from .normalize import clean
from .viz import featOf_py, spans_for

FONT = "Arial"
NAVY, ORANGE_SOFT, BLUE_SOFT, GREY = "14213D", "FBE1C4", "E3ECF3", "F3F1EC"
HDR = Font(name=FONT, bold=True, color="FFFFFF", size=10)
BODY = Font(name=FONT, size=10)
BOLD = Font(name=FONT, size=10, bold=True)
TITLE = Font(name=FONT, size=16, bold=True, color=NAVY)
NOTE = Font(name=FONT, size=9, italic=True, color="5B6372")
HFILL = PatternFill("solid", fgColor=NAVY)
ANSFILL = PatternFill("solid", fgColor="9A4F10")
THIN = Border(bottom=Side(style="thin", color="DDD8CC"))

FAMILY_NAMES = {
    "meta": "Report details", "txt": "Text statistics", "occ": "Occurrence categories (CICTT)",
    "ph": "Phase of flight", "ata": "Aircraft systems (ATA)", "hf": "Human factors (HFACS-style)",
    "wx": "Weather", "out": "Outcomes", "q": "Quantities", "crew": "Quantities", "pob": "Quantities",
    "n": "Quantities", "delay": "Quantities", "ent": "Entities", "seq": "Event sequence (NTSB)",
    "link": "Cross-source linkage", "lbl": "Labels",
}


def _v(x):
    if x is None:
        return None
    if isinstance(x, float) and np.isnan(x):
        return None
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, (np.floating,)):
        return float(x)
    if isinstance(x, (np.bool_, bool)):
        return bool(x)
    if isinstance(x, (list, tuple, np.ndarray)):
        return " | ".join(str(i) for i in x)
    if isinstance(x, pd.Timestamp):
        return x.date()
    return x


def _family(col: str) -> str:
    return col.split("_")[0]


def _header(ws, cols, row=1, answer_cols=()):
    for j, c in enumerate(cols, 1):
        cell = ws.cell(row=row, column=j, value=c)
        cell.font = HDR
        cell.fill = ANSFILL if c in answer_cols else HFILL
        cell.alignment = Alignment(vertical="center", wrap_text=True)
    ws.row_dimensions[row].height = 30


def _write_table(ws, df: pd.DataFrame, name: str, widths=None, wrap_cols=(), answer_cols=(), start_row=1):
    cols = list(df.columns)
    _header(ws, cols, start_row, answer_cols)
    for i, row in enumerate(df.itertuples(index=False), start_row + 1):
        for j, val in enumerate(row, 1):
            c = ws.cell(row=i, column=j, value=_v(val))
            c.font = BODY
            c.border = THIN
            if cols[j - 1] in wrap_cols:
                c.alignment = Alignment(wrap_text=True, vertical="top")
            else:
                c.alignment = Alignment(vertical="top")
    last = get_column_letter(len(cols)) + str(start_row + max(len(df), 1))
    if len(df):
        t = Table(displayName=name, ref=f"A{start_row}:{last}")
        t.tableStyleInfo = TableStyleInfo(name="TableStyleLight1", showRowStripes=True)
        ws.add_table(t)
    for j, c in enumerate(cols, 1):
        w = (widths or {}).get(c)
        if w is None:
            sample = [len(str(c))] + [len(str(_v(v) or "")) for v in df[c].head(50)]
            w = min(max(sample) + 2, 40)
        ws.column_dimensions[get_column_letter(j)].width = max(w, 8)
    ws.freeze_panes = ws.cell(row=start_row + 1, column=2)


def build_workbook(out_dir: Path, dest: Path, profile: str = "factual") -> Path:
    recs = pd.read_parquet(out_dir / "records.parquet")
    feats = pd.read_parquet(out_dir / "features.parquet")
    weak = pd.read_csv(out_dir / "weak_labels.csv") if (out_dir / "weak_labels.csv").exists() else None
    preds = pd.read_parquet(out_dir / "predictions.parquet") if (out_dir / "predictions.parquet").exists() else None
    pdf_fields = pd.read_csv(out_dir / "pdf_fields.csv") if (out_dir / "pdf_fields.csv").exists() else None

    df = recs.merge(feats, on=["report_id", "source"], how="left")
    if weak is not None:
        df = df.merge(weak[["report_id", "weak_label", "weak_conf"]], on="report_id", how="left")
    if preds is not None and "pred_cictt" in preds:
        df = df.merge(preds[["report_id", "pred_cictt", "pred_conf", "needs_review"]], on="report_id", how="left")
    if pdf_fields is not None:
        df = df.merge(pdf_fields[["report_id", "report_kind", "docket"]], on="report_id", how="left")
    n = len(df)

    wb = Workbook()
    # ------------------------------------------------------------------ Reports
    ws = wb.active
    ws.title = "Reports"
    rep_cols = [
        ("report_id", "Report ID"), ("report_kind", "Report kind"), ("event_date", "Event date"),
        ("meta_era", "NTSB coding era"), ("event_type", "Type"), ("registration", "Registration"),
        ("aircraft_make", "Make"), ("aircraft_model", "Model"), ("meta_family", "Aircraft family"),
        ("operator", "Operator"), ("far_part", "FAR part"), ("location", "Location"), ("country", "Country"),
        ("highest_injury", "Highest injury"), ("damage", "Damage"), ("wx_cond", "Weather cond."),
        ("light_cond", "Light"), ("ph_first", "First phase (text)"), ("ph_last", "Last phase (text)"),
        ("occ_top", "Top keyword category"), ("weak_label", "Weak label"), ("weak_conf", "Weak label confidence"),
        ("lbl_cictt", "NTSB CICTT label"), ("lbl_source", "Label rule"), ("lbl_cictt_all", "All coded categories"),
        ("defining_event", "NTSB defining event"), ("occurrences", "NTSB coded sequence"),
        ("findings", "NTSB findings"), ("probable_cause", "Probable cause"),
        ("pred_cictt", "Model prediction"), ("pred_conf", "Model confidence"), ("txt_words", "Words read by model"),
        ("docket", "NTSB docket"),
    ]
    rep_cols = [(k, h) for k, h in rep_cols if k in df.columns]
    R = df[[k for k, _ in rep_cols]].copy()
    R["occ_top"] = R["occ_top"].map(lambda s: s.replace("_", "-") if isinstance(s, str) else s)
    R.columns = [h for _, h in rep_cols]
    answer_hdrs = {"NTSB CICTT label", "Label rule", "All coded categories", "NTSB defining event",
                   "NTSB coded sequence", "NTSB findings", "Probable cause"}
    _write_table(ws, R, "Reports", widths={"Probable cause": 60, "NTSB findings": 50, "NTSB coded sequence": 40,
                                            "Location": 24, "Operator": 22, "NTSB docket": 30},
                 wrap_cols={"Probable cause", "NTSB findings", "NTSB coded sequence", "All coded categories"},
                 answer_cols=answer_hdrs)
    # formula column: does the weak (keyword) label agree with NTSB?
    hdr = [c.value for c in ws[1]]
    if "Weak label" in hdr and "NTSB CICTT label" in hdr:
        wcol = get_column_letter(hdr.index("Weak label") + 1)
        lcol = get_column_letter(hdr.index("NTSB CICTT label") + 1)
        mcol_i = len(hdr) + 1
        mc = ws.cell(row=1, column=mcol_i, value="Weak label = NTSB?")
        mc.font, mc.fill = HDR, HFILL
        mc.alignment = Alignment(wrap_text=True, vertical="center")
        for i in range(2, n + 2):
            c = ws.cell(row=i, column=mcol_i, value=f'=IF({lcol}{i}="","",IF({wcol}{i}={lcol}{i},"Yes","No"))')
            c.font, c.border = BODY, THIN
        ws.column_dimensions[get_column_letter(mcol_i)].width = 14
        ws.tables["Reports"].ref = f"A1:{get_column_letter(mcol_i)}{n + 1}"
    if "Weak label confidence" in hdr:
        col = get_column_letter(hdr.index("Weak label confidence") + 1)
        for i in range(2, n + 2):
            ws[f"{col}{i}"].number_format = "0.00"
    if "Model confidence" in hdr:
        col = get_column_letter(hdr.index("Model confidence") + 1)
        for i in range(2, n + 2):
            ws[f"{col}{i}"].number_format = "0.00"
    if "Event date" in hdr:
        col = get_column_letter(hdr.index("Event date") + 1)
        for i in range(2, n + 2):
            v = ws[f"{col}{i}"].value
            if isinstance(v, str):
                ws[f"{col}{i}"].value = pd.to_datetime(v).date()
            ws[f"{col}{i}"].number_format = "yyyy-mm-dd"
    rep_hdr = [c.value for c in ws[1]]

    # ------------------------------------------------------------------ Features (wide)
    wf = wb.create_sheet("Features")
    F = feats.copy()
    for c in F.columns:
        if F[c].dtype == object:
            F[c] = F[c].map(_v)
    ans = {c for c in F.columns if is_answer_column(c)}
    _write_table(wf, F, "Features", answer_cols=ans)
    for j in range(2, F.shape[1] + 1):
        wf.column_dimensions[get_column_letter(j)].width = 14
    wf.column_dimensions["A"].width = 22

    # ------------------------------------------------------------------ Feature Values (long, non-zero)
    rows = []
    for r in feats.to_dict("records"):
        for k, v in r.items():
            if k in ("report_id", "source"):
                continue
            v = _v(v)
            if v in (None, 0, "", False) or (isinstance(v, float) and v == 0.0):
                continue
            fam = _family(k)
            rows.append({"report_id": r["report_id"], "family": FAMILY_NAMES.get(fam, fam), "feature": k,
                         "value": v, "side": "answer" if is_answer_column(k) else "evidence"})
    FV = pd.DataFrame(rows)
    wv = wb.create_sheet("Feature Values")
    _write_table(wv, FV, "FeatureValues", widths={"report_id": 22, "family": 28, "feature": 32, "value": 40, "side": 10})

    # ------------------------------------------------------------------ Evidence spans
    sp_rows = []
    for rec in recs.to_dict("records"):
        for k in ("occurrences", "findings"):
            v = rec.get(k)
            rec[k] = list(v) if v is not None and not isinstance(v, float) else []
        rec = {k: (None if isinstance(v, float) and np.isnan(v) else v) for k, v in rec.items()}
        text = clean(evidence_text(rec, profile))
        for s in spans_for(text):
            for x in [s] + s.get("also", []):
                sp_rows.append({
                    "report_id": rec["report_id"], "family": {"q": "Quantities", "ent": "Entities"}.get(x["fam"], FAMILY_NAMES.get(x["fam"], x["fam"])),
                    "category": x["cat"], "scope": {"aff": "affirmed", "neg": "negated", "unc": "uncertain"}[x["tag"]],
                    "matched_text": text[s["s"]:s["e"]], "feeds_feature": featOf_py(x) or None,
                    "context": text[max(0, s["s"] - 60):s["e"] + 60].replace("\n", " "), "char_offset": s["s"]})
    SP = pd.DataFrame(sp_rows)
    wsp = wb.create_sheet("Evidence Spans")
    _write_table(wsp, SP, "EvidenceSpans", widths={"report_id": 22, "family": 26, "category": 20, "scope": 11,
                                                    "matched_text": 26, "feeds_feature": 28, "context": 80, "char_offset": 11},
                 wrap_cols={"context"})

    # ------------------------------------------------------------------ Feature dictionary (formulas)
    wd = wb.create_sheet("Feature Dictionary")
    cols = [c for c in feats.columns if c not in ("report_id",)]
    D = pd.DataFrame({"feature": cols, "family": [FAMILY_NAMES.get(_family(c), _family(c)) for c in cols],
                      "side": ["answer" if is_answer_column(c) else "evidence" for c in cols],
                      "dtype": [str(feats[c].dtype) for c in cols]})
    _write_table(wd, D, "FeatureDictionary", widths={"feature": 32, "family": 30, "side": 10, "dtype": 10})
    feat_hdr = list(F.columns)
    base = D.shape[1]
    for j, h in enumerate(["Reports with a value", "Reports non-zero", "Coverage"], base + 1):
        c = wd.cell(row=1, column=j, value=h)
        c.font, c.fill = HDR, HFILL
        c.alignment = Alignment(wrap_text=True, vertical="center")
        wd.column_dimensions[get_column_letter(j)].width = 14
    for i, f in enumerate(cols, 2):
        L = get_column_letter(feat_hdr.index(f) + 1)
        rng = f"Features!${L}$2:${L}${n + 1}"
        wd.cell(row=i, column=base + 1, value=f"=COUNTA({rng})").font = BODY
        wd.cell(row=i, column=base + 2, value=f'=COUNTIFS({rng},"<>0",{rng},"<>")').font = BODY
        cc = wd.cell(row=i, column=base + 3, value=f"={get_column_letter(base + 1)}{i}/{n}")
        cc.font, cc.number_format = BODY, "0%"
    wd.tables["FeatureDictionary"].ref = f"A1:{get_column_letter(base + 3)}{len(cols) + 1}"
    wd.cell(row=len(cols) + 3, column=1,
            value="Answer-side features come from investigator conclusions (labels, coded sequence, findings, links) "
                  "and are never model inputs. Orange headers on Features mark them.").font = NOTE

    # ------------------------------------------------------------------ PDF fields
    if pdf_fields is not None:
        wpf = wb.create_sheet("PDF Fields")
        _write_table(wpf, pdf_fields, "PDFFields", widths={"source_file": 28, "docket": 40, "flight_conducted_under": 30})

    # ------------------------------------------------------------------ Narratives
    wn = wb.create_sheet("Narratives")
    N = pd.DataFrame([{"report_id": r["report_id"], "title": r["title"],
                       "model_input_text": clean(evidence_text({k: (None if isinstance(v, float) and np.isnan(v) else v) for k, v in r.items()}, profile)),
                       "probable_cause": r.get("probable_cause")} for r in recs.to_dict("records")])
    _write_table(wn, N, "Narratives", widths={"report_id": 20, "title": 40, "model_input_text": 110, "probable_cause": 50},
                 wrap_cols={"title", "model_input_text", "probable_cause"}, answer_cols={"probable_cause"})

    # ------------------------------------------------------------------ Summary (first sheet)
    s = wb.create_sheet("Summary", 0)
    s.sheet_view.showGridLines = False
    s.column_dimensions["A"].width = 46
    s.column_dimensions["B"].width = 16
    s.column_dimensions["C"].width = 70
    s["A1"] = "avintel — reports and engineered features"
    s["A1"].font = TITLE
    s["A2"] = f"Source: pipeline output in {out_dir.name}/ · text profile '{profile}' (title + factual narrative; probable cause excluded)"
    s["A2"].font = NOTE

    def col_of(h):
        return get_column_letter(rep_hdr.index(h) + 1) if h in rep_hdr else None

    rng = lambda h: f"Reports!${col_of(h)}$2:${col_of(h)}${n + 1}"
    lines = [("Reports", f"=COUNTA({rng('Report ID')})", "One row per report on the Reports sheet")]
    if col_of("Report kind"):
        lines += [("Final reports", f'=COUNTIF({rng("Report kind")},"Final")', "Have analysis, probable cause and findings"),
                  ("Preliminary reports", f'=COUNTIF({rng("Report kind")},"Preliminary")', "Header and data tables only; usually no narrative")]
    lines += [
        ("Reports with an NTSB CICTT label", f"=COUNTA({rng('NTSB CICTT label')})", "Post-2008: defining event; pre-2008: first occurrence refined by findings"),
        ("Reports with a weak (keyword) label", f"=COUNTA({rng('Weak label')})", "From the six labeling functions"),
        ("Weak label agrees with NTSB", f'=COUNTIF(Reports!${get_column_letter(len(rep_hdr))}$2:${get_column_letter(len(rep_hdr))}${n + 1},"Yes")', "Counted only where NTSB gave a label"),
        ("Agreement rate", "=IFERROR(B8/B6,0)" if col_of("Report kind") else "=IFERROR(B6/B4,0)", "Weak label = NTSB ÷ reports with an NTSB label"),
        ("Feature columns", f"=COUNTA('Feature Dictionary'!$A$2:$A${len(cols) + 1})", "See the Feature Dictionary sheet"),
        ("Evidence-side features", f"=COUNTIF('Feature Dictionary'!$C$2:$C${len(cols) + 1},\"evidence\")", "Usable as model inputs"),
        ("Answer-side features", f"=COUNTIF('Feature Dictionary'!$C$2:$C${len(cols) + 1},\"answer\")", "Derived from investigator conclusions; never model inputs"),
        ("Non-zero feature values", f"=COUNTA('Feature Values'!$A$2:$A${len(FV) + 1})", "Long format on the Feature Values sheet"),
        ("Evidence spans", f"=COUNTA('Evidence Spans'!$A$2:$A${len(SP) + 1})", "Exact words behind each lexicon, quantity and entity hit"),
    ]
    s["A4"], s["B4"], s["C4"] = "Measure", "Value", "Note"
    for c in ("A4", "B4", "C4"):
        s[c].font, s[c].fill = HDR, HFILL
    for i, (a, b, c) in enumerate(lines, 5):
        s.cell(row=i, column=1, value=a).font = BODY
        cell = s.cell(row=i, column=2, value=b)
        cell.font = BOLD
        if a == "Agreement rate":
            cell.number_format = "0%"
        s.cell(row=i, column=3, value=c).font = NOTE
        for j in (1, 2, 3):
            s.cell(row=i, column=j).border = THIN
    # fix agreement-rate references to the actual rows
    labels = {a: i for i, (a, _, _) in enumerate(lines, 5)}
    s.cell(row=labels["Agreement rate"], column=2,
           value=f"=IFERROR(B{labels['Weak label agrees with NTSB']}/B{labels['Reports with an NTSB CICTT label']},0)")
    r0 = 5 + len(lines) + 1
    notes = [
        "How to read this workbook",
        "Reports: orange headers are answer-side (NTSB conclusions); the model never reads them. 'Weak label = NTSB?' is a live formula.",
        "Features: the full wide table, one column per feature. Feature Values: the same data, non-zero only, one row per value.",
        "Evidence Spans: every highlighted phrase, its scope (affirmed / negated / uncertain) and the feature it feeds.",
        "Feature Dictionary: family, evidence vs answer side, and live coverage counts computed from the Features sheet.",
        "Model prediction is blank when there were too few labeled reports per category to train a classifier.",
    ]
    for i, t in enumerate(notes):
        c = s.cell(row=r0 + i, column=1, value=t)
        c.font = BOLD if i == 0 else BODY
    wb.save(dest)
    return dest


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument("--out", default="out")
    p.add_argument("--xlsx", default=None)
    p.add_argument("--profile", default="factual")
    a = p.parse_args(argv)
    out = Path(a.out)
    dest = Path(a.xlsx) if a.xlsx else out / "avintel_features.xlsx"
    build_workbook(out, dest, a.profile)
    print("workbook ->", dest)


if __name__ == "__main__":
    main()
