"""Canonical record schema shared by every source (NTSB, Aviation Herald, ...).

Every ingester emits rows with exactly these columns so that downstream
feature engineering never needs to know where a report came from.
"""
from __future__ import annotations

CANONICAL_COLUMNS = [
    "report_id",        # source-prefixed unique id, e.g. "NTSB:20230105106538" / "AVH:4f1a2b3c"
    "source",           # "NTSB" | "AVHERALD"
    "event_date",       # ISO date string (YYYY-MM-DD) or None
    "event_type",       # NTSB: ACC/INC ; AvHerald: Accident/Incident/Crash/Report
    "operator",
    "registration",
    "aircraft_make",
    "aircraft_model",
    "far_part",         # NTSB only (121/135/91...), None otherwise
    "location",         # free-text city / airport
    "country",
    "highest_injury",   # FATL/SERS/MINR/NONE or None
    "damage",           # DEST/SUBS/MINR/NONE or None
    "wx_cond",          # VMC/IMC or None
    "light_cond",
    "title",            # AvHerald headline; NTSB synthesized summary
    "narrative",        # full factual narrative text
    "probable_cause",   # NTSB cause statement; empty for AvHerald
    "occurrences",      # list[str]  NTSB events_sequence descriptions (ordered)
    "defining_event",   # str NTSB defining occurrence description or None
    "findings",         # list[str]  NTSB findings descriptions
    "url",
]


def empty_record() -> dict:
    rec = {c: None for c in CANONICAL_COLUMNS}
    rec["occurrences"] = []
    rec["findings"] = []
    return rec
