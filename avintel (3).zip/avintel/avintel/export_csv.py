"""One flat CSV: a row per report with every field, feature, label, prediction and link.

python -m avintel.export_csv --run out_pdf="Real NTSB PDFs" --run out_test="Fictional test data" \
       [--families B737MAX,B737NG/CL,B777,B787 --families-for "Fictional test data"] --csv reports_features.csv

Column order: dataset and identity -> report fields -> model input text -> NTSB conclusions
(answer side) -> engineered features (293) -> weak label -> prediction and probabilities -> links -> PDF fields.
Lists are joined with " | ". Written as UTF-8 with BOM so Excel opens it cleanly.
"""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from .features import evidence_text, is_answer_column
from .normalize import clean

REPORT_COLS = ["report_id", "source", "title", "event_date", "event_type", "operator", "registration",
               "aircraft_make", "aircraft_model", "location", "country", "far_part", "highest_injury",
               "damage", "wx_cond", "light_cond", "url"]


def _none(v):
    return None if isinstance(v, float) and np.isnan(v) else v


def _join(v):
    if v is None or (isinstance(v, float) and np.isnan(v)):
        return None
    if isinstance(v, (list, tuple, np.ndarray)):
        return " | ".join(str(x) for x in v) or None
    return v


def build_frame(out_dir: Path, dataset: str, families: list[str] | None = None, profile: str = "factual") -> pd.DataFrame:
    recs = pd.read_parquet(out_dir / "records.parquet")
    feats = pd.read_parquet(out_dir / "features.parquet")
    if families:
        feats = feats[feats["meta_family"].isin(families)]
        recs = recs[recs["report_id"].isin(feats["report_id"])]

    base = recs[REPORT_COLS].copy()
    base.insert(0, "dataset", dataset)
    base["model_input_text"] = [clean(evidence_text({k: _none(v) for k, v in r.items()}, profile))
                                for r in recs.to_dict("records")]
    # answer side: investigator conclusions, never model inputs
    base["ntsb_probable_cause"] = recs["probable_cause"].values
    base["ntsb_defining_event"] = recs["defining_event"].values
    base["ntsb_coded_sequence"] = recs["occurrences"].map(_join).values
    base["ntsb_findings"] = recs["findings"].map(lambda f: _join([x for x in (f if f is not None else []) if not str(x).startswith("asn_")])).values

    fcols = [c for c in feats.columns if c not in ("report_id", "source")]
    df = base.merge(feats[["report_id"] + fcols], on="report_id", how="left")

    if (out_dir / "weak_labels.csv").exists():
        w = pd.read_csv(out_dir / "weak_labels.csv")
        keep = ["report_id", "weak_label", "weak_conf"] + [c for c in w.columns if c.startswith("lf_")]
        w = w[keep].rename(columns={c: f"vote_{c}" for c in keep if c.startswith("lf_")})
        df = df.merge(w, on="report_id", how="left")
    if (out_dir / "predictions.parquet").exists():
        p = pd.read_parquet(out_dir / "predictions.parquet")
        pc = [c for c in p.columns if c.startswith(("pred_", "p_")) or c == "needs_review"]
        if pc:
            df = df.merge(p[["report_id"] + pc], on="report_id", how="left")
    if (out_dir / "links.csv").exists():
        L = pd.read_csv(out_dir / "links.csv")
        if len(L):
            both = pd.concat([L.rename(columns={"id_a": "rid", "id_b": "other"}), L.rename(columns={"id_b": "rid", "id_a": "other"})])
            agg = both.sort_values("score", ascending=False).groupby("rid").apply(
                lambda g: " | ".join(f"{o} ({s:.2f})" for o, s in zip(g["other"], g["score"])), include_groups=False)
            df["linked_reports"] = df["report_id"].map(agg)
    if (out_dir / "pdf_fields.csv").exists():
        pf = pd.read_csv(out_dir / "pdf_fields.csv")
        pf = pf.rename(columns={c: f"pdf_{c}" for c in pf.columns if c != "report_id"})
        df = df.merge(pf, on="report_id", how="left")
    for c in df.columns:
        if df[c].dtype == object:
            df[c] = df[c].map(_join)
    return df


FEATURE_PREFIX_ORDER = ["meta", "txt", "occ", "ph", "ata", "hf", "wx", "out", "q", "crew", "pob", "n", "delay", "ent", "seq", "link", "lbl"]


def order_columns(cols: list[str]) -> list[str]:
    """Stable grouping: report fields, text, NTSB conclusions, features by bucket, labels, predictions, links, PDF fields."""
    def rank(i_c):
        i, c = i_c
        if c == "dataset" or c in REPORT_COLS:
            return (0, (["dataset"] + REPORT_COLS).index(c), 0)
        if c == "model_input_text":
            return (1, 0, 0)
        if c.startswith("ntsb_"):
            return (2, 0, i)
        pre = c.split("_")[0]
        if pre in FEATURE_PREFIX_ORDER and not c.startswith(("pdf_",)):
            return (3, FEATURE_PREFIX_ORDER.index(pre), i)
        if c.startswith(("weak_", "vote_")):
            return (4, 0, i)
        if c.startswith(("pred_", "p_")) or c == "needs_review":
            return (5, 0 if c.startswith("pred_") or c == "needs_review" else 1, i)
        if c == "linked_reports":
            return (6, 0, i)
        return (7, 0, i)
    return [c for _, c in sorted(enumerate(cols), key=rank)]


def column_guide(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for c in df.columns:
        if c in ("dataset",) + tuple(REPORT_COLS):
            grp, side = "report", "evidence"
        elif c == "model_input_text":
            grp, side = "model input text", "evidence"
        elif c.startswith("ntsb_"):
            grp, side = "NTSB conclusions", "answer"
        elif c.startswith(("weak_", "vote_")):
            grp, side = "weak labels", "derived"
        elif c.startswith(("pred_", "p_")) or c == "needs_review":
            grp, side = "prediction", "output"
        elif c == "linked_reports":
            grp, side = "linkage", "answer"
        elif c.startswith("pdf_"):
            grp, side = "PDF fields", "evidence"
        else:
            grp, side = c.split("_")[0], "answer" if is_answer_column(c) else "evidence"
        rows.append({"column": c, "group": grp, "side": side,
                     "filled": int(df[c].notna().sum() - (df[c] == 0).sum() if pd.api.types.is_numeric_dtype(df[c]) else df[c].notna().sum())})
    return pd.DataFrame(rows)


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument("--run", action="append", required=True, help="DIR=Dataset label (repeatable)")
    p.add_argument("--families", default=None, help="meta_family filter, comma-separated")
    p.add_argument("--families-for", default=None, help="apply --families only to this dataset label")
    p.add_argument("--csv", default="reports_features.csv")
    a = p.parse_args(argv)
    fams = [x.strip() for x in a.families.split(",")] if a.families else None
    frames = []
    for spec in a.run:
        d, _, lab = spec.partition("=")
        lab = lab or Path(d).name
        use = fams if fams and (a.families_for is None or a.families_for == lab) else None
        frames.append(build_frame(Path(d), lab, use))
    df = pd.concat(frames, ignore_index=True, sort=False)
    df = df[order_columns(list(df.columns))]
    df.to_csv(a.csv, index=False, encoding="utf-8-sig")
    guide = column_guide(df)
    gpath = Path(a.csv).with_name(Path(a.csv).stem + "_columns.csv")
    guide.to_csv(gpath, index=False, encoding="utf-8-sig")
    print(f"{len(df)} reports x {df.shape[1]} columns -> {a.csv}; column guide -> {gpath}")


if __name__ == "__main__":
    main()
